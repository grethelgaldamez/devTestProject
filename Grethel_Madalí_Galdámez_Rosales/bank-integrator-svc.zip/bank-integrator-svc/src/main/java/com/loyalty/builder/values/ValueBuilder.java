package com.loyalty.builder.values;

import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;

public interface ValueBuilder<T extends Value> {
	public Field<T> build(Field<T> field, Object... params);
}
