package com.loyalty.builder.values.accmcv;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Attr;
import com.loyalty.pojo.fields.ComboBoxValue;
import com.loyalty.pojo.fields.Data;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.member.MemberDetail;

@Component("rdNotiEmail")
public class EmailNotifBuilder implements ValueBuilder<Value>{

	@Override
	public Field<Value> build(Field<Value> field, Object... params ) {
		ComboBoxValue values = new ComboBoxValue();
		MemberDetail  detail = (MemberDetail) params[1];
		
		String fieldMod = "field-mod";
		String status = "status-field";
		String value = "value-field";
		String required = "required-field";
		String format = "format-field";
		String fieldName = "txtEmailAccMcv";
		
		List<Data> data = new ArrayList<>();
		List<Attr> attrs = new ArrayList<>();
		attrs.add(new Attr(fieldMod, fieldName));
		attrs.add(new Attr(status, "readonly"));
		attrs.add(new Attr(required, "N"));

		if(detail.getEmail() != null && !detail.getEmail().isEmpty()){
			attrs.add(new Attr(value, detail.getEmail().substring(0, 1).toUpperCase()+"*******@********"));
		}
		data.add(new Data("01", "Deseo enviar la notificación al correo del perfil del cliente", attrs));
		
		attrs = new ArrayList<>();
		attrs.add(new Attr(fieldMod, fieldName));
		attrs.add(new Attr(status, "visible"));
		attrs.add(new Attr(value, ""));
		attrs.add(new Attr(required, "Y"));
		attrs.add(new Attr(format, "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)+$"));
		data.add(new Data("02", "Deseo digitar el correo para enviar la notificación", attrs));

		attrs = new ArrayList<>();
		attrs.add(new Attr(fieldMod, fieldName));
		attrs.add(new Attr(status, "readonly"));
		attrs.add(new Attr(value, ""));
		attrs.add(new Attr(required, "N"));
		data.add(new Data("03", "No deseo enviar notificación", attrs));
		values.setItems(data);
		field.setValues(values);
		field.setDefaultValue("01");
		
		return field;
	}

}
