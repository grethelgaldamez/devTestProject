package com.loyalty.builder.values.accmcv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.member.MemberDetail;

@Component("txtEmailAccMcv")
public class MemberEmailBuilder implements ValueBuilder<Value>{
	private Logger log;
	
	public MemberEmailBuilder() {
		this.log = LoggerFactory.getLogger("com.loyalty.logger");
	}
	
	@Override
	public Field<Value> build(Field<Value> field, Object... params ) {
		MemberDetail  detail = (MemberDetail) params[1];
		
		if(detail.getEmail() != null && !detail.getEmail().isEmpty()) {
			field.setDefaultValue(detail.getEmail().substring(0, 1).toUpperCase()+"*******@********");
		} else {
			log.error("MemberEmailBuilder Can not retrieve user email");
		}
		field.setFormat(null);
		return field;
	}

}
