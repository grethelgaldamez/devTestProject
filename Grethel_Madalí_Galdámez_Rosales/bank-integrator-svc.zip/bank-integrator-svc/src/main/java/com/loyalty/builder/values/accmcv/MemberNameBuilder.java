package com.loyalty.builder.values.accmcv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.member.MemberDetail;

@Component("txtNombreAccMcv")
public class MemberNameBuilder implements ValueBuilder<Value>{
	private Logger log;
	
	public MemberNameBuilder() {
		this.log = LoggerFactory.getLogger("com.loyalty.logger");
	}
	
	@Override
	public Field<Value> build(Field<Value> field, Object... params ) {
		MemberDetail  detail = (MemberDetail) params[1];
		if(detail.getFirstName() != null) {
			field.setDefaultValue(detail.getFirstName()+" "+ detail.getLastName());
		} else {
			log.error("MemberNameBuilder Can not retrieve first or last name");
		}		
				
		return field;
	}

}
