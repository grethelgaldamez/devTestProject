package com.loyalty.builder.values.accmcv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.member.MemberDetail;

@Component("txtMun")
public class MunBuilder implements ValueBuilder<Value>{
	private Logger log;
	
	public MunBuilder() {
		this.log = LoggerFactory.getLogger("com.loyalty.logger");
	}
	
	@Override
	public Field<Value> build(Field<Value> field, Object... params ) {
		MemberDetail  detail = (MemberDetail) params[1];
		if(detail.getMemberNum() != null)
			field.setDefaultValue(detail.getMemberNum());
		else
			log.error("MunBuilder MEMBER MUN it's not defined");
		
		return field;
	}

}
