package com.loyalty.builder.values.cashier.info;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.cashier.Cashier;

@Component("chTxtDocumento")
public class DocumentCashierBuilder implements ValueBuilder<Value>{
	private Logger log;
	
	public DocumentCashierBuilder() {
		this.log =  LoggerFactory.getLogger("com.loyalty.logger");
	}
	@Override
	public Field<Value> build(Field<Value> field, Object... params) {
		Cashier cashier = (Cashier) params[1];
		if(cashier!=null){
			field.setDefaultValue(cashier.getDocumentNumber());
		}else log.error("Cashier Document number Builder Error: cashier is null");
		return field;
	}
}
