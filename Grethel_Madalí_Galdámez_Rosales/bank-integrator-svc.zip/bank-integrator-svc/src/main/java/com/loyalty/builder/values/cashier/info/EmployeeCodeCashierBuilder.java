package com.loyalty.builder.values.cashier.info;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.cashier.Cashier;

@Component("chTxtCodEmpleado")
public class EmployeeCodeCashierBuilder implements ValueBuilder<Value>{
	private Logger log;
	
	public EmployeeCodeCashierBuilder() {
		this.log =  LoggerFactory.getLogger("com.loyalty.logger");
	}
	@Override
	public Field<Value> build(Field<Value> field, Object... params) {
		Cashier cashier = (Cashier) params[1];
		if(cashier!=null){
			field.setDefaultValue(cashier.getEmployeeNumber());
		}
		return field;
	}
}
