package com.loyalty.builder.values.cashier.info;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.ComboBoxValue;
import com.loyalty.pojo.fields.Data;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.svc.cashier.Cashier;

@Component("pChEstado")
public class StatusCashierBuilder implements ValueBuilder<ComboBoxValue>{
private Logger log;
	
	public StatusCashierBuilder(){
		this.log = LoggerFactory.getLogger("com.loyalty.logger");
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public Field<ComboBoxValue> build(Field<ComboBoxValue> field, Object... params) {
		Cashier cashier = (Cashier) params[1];
		
		List<Data> data = new ArrayList<>();
		data.add(new Data("A", "Activo"));
		data.add(new Data("I", "Inactivo"));
		
		ComboBoxValue values = new ComboBoxValue();
		values.setItems(data);
		
		field.setValues(values);
		if(Character.toString(cashier.getStatus()) != null  || Character.toString(cashier.getStatus()) != "" ){
			field.setDefaultValue(Character.toString(cashier.getStatus()));
		}else{
			log.error("StateBuilder. State not found for partner " + cashier.getStatus());
		}
		return field;
	}
}
