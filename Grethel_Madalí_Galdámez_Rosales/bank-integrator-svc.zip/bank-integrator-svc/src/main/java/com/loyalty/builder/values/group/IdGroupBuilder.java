package com.loyalty.builder.values.group;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.partner.Partner;

@Component("txtGrpId")
public class IdGroupBuilder implements ValueBuilder<Value>{
	private Logger log;
	
	public IdGroupBuilder(){
		this.log =  LoggerFactory.getLogger("com.loyalty.logger");
		
	}

	@Override
	public Field<Value> build(Field<Value> field, Object... params) {
		Partner  detail = (Partner) params[1];
		
		String id = detail.getCode();
		if(id != null && !id.isEmpty()){
			field.setDefaultValue(id);
		}else{
			log.error("IdGroupBuilder. Id group not found for partner " + id);
		}
		return field;
	}

}
