package com.loyalty.builder.values.group;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.partner.Partner;

@Component("txtNomGrp")
public class NameGroupBuilder implements ValueBuilder<Value>{
	private Logger log;
	
	public NameGroupBuilder(){
		this.log =  LoggerFactory.getLogger("com.loyalty.logger");
		
	}

	@Override
	public Field<Value> build(Field<Value> field, Object... params) {
		Partner  detail = (Partner) params[1];
		
		String id = detail.getName();
		if(id != null && !id.isEmpty()){
			String[] array = id.split(" - ");
			field.setDefaultValue(array[1]);
		}else{
			log.error("NameGroupBuilder. Name group not found for partner " + id);
		}
		return field;
	}

}
