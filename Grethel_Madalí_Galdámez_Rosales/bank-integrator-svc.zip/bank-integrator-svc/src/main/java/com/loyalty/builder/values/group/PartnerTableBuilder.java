package com.loyalty.builder.values.group;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Column;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.TableValue;
import com.loyalty.pojo.fields.table.Language;
import com.loyalty.pojo.fields.table.Paginate;
import com.loyalty.pojo.svc.partner.Partner;

@Component("tblAliadosGrp")
public class PartnerTableBuilder implements ValueBuilder<TableValue> {

	private Logger log;

	public PartnerTableBuilder() {
		this.log =   LoggerFactory.getLogger("com.loyalty.logger");
	}

	@SuppressWarnings("unchecked")
	@Override
	public Field<TableValue> build(Field<TableValue> field, Object... params) {//dudas
		List<Partner> list = (List<Partner>) params[2];
		
		Language language = new Language();
		Paginate paginate = new Paginate();
		language.setInfo("");
		paginate.setFirst("Primero");
		paginate.setPrevious("Anterior");
		paginate.setNext("Siguiente");
		language.setPaginate(paginate);
		
		
		//Columns
		Column c1 = new Column();
		c1.setTitle("ID Aliado");
		Column c2 = new Column();
		c2.setTitle("Nombre");
		Column c3 = new Column();
		c3.setTitle("Estado");
		
		//arreglo de columnas
		List<Column> cl = new ArrayList<>();
		cl.add(c1);
		cl.add(c2);
		//cl.add(c3);

		//list de strings para rows
		List<String[]> rows = new ArrayList<>();
		
		if(list != null) {
			for(Partner item: list){
				String estado = item.getStatus()== 'A' ? "Activo" : "Inactivo";
				String[] row = new String[]{
						item.getCode(),
						item.getName()
						//estado
						};

				rows.add(row);
			}

			TableValue values = new TableValue();
			values.setColumns(cl);
			values.setData(rows);
			values.setLanguage(language);
			values.setLengthChange(false);
			values.setOrdering(true);
			values.setPagingType("simple_numbers");
			values.setPageLength(10);
			values.setPaging(true);
			values.setSearching(false);
			List<Object[]> order = new ArrayList<>();
			Object[] order2 = new Object[]{1, "asc"};
			order.add(order2);
			values.setOrder(order);
			field.setValues(values); 
		}
		else{
			field.setStatus("hidden");
			log.info("PartnerTableBuilder. Partner not found ");
			return null;
		}
		return field;

	}
}

