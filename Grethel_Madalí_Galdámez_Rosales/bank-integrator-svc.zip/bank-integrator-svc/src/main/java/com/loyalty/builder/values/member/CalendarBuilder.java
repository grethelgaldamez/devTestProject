package com.loyalty.builder.values.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.DateValue;
import com.loyalty.pojo.fields.Field;

@Component("txtBirthDate")
public class CalendarBuilder implements ValueBuilder<DateValue>{

	@Autowired
	private Environment env;
	
	@Override
	public Field<DateValue> build(Field<DateValue> field, Object... params) {
		
		DateValue values = new DateValue();
		values.setMaxDate("-730");	//este valor se sacara del servicio de settings mas adelante.	
		values.setDateFormat(env.getProperty("config.date-picker-format"));
		values.setChangeMonth(true);
		values.setChangeYear(true);
		values.setYearRange(env.getProperty("config.year-range"));
		field.setValues(values);
		
		return field;
	}

}
