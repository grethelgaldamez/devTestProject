package com.loyalty.builder.values.member;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.ComboBoxValue;
import com.loyalty.pojo.fields.Data;
import com.loyalty.pojo.fields.Field;

@Component("ddlDay")
public class DayCmbBuilder implements ValueBuilder<ComboBoxValue>{

	@Override
	public Field<ComboBoxValue> build(Field<ComboBoxValue> field, Object... params) {		
		
		List<Data> data = new ArrayList<>();
		for(int i = 0; i < 31; i++) {
			data.add(new Data(Integer.toString(i+1),Integer.toString(i+1)));
		}
		
		data.add(0, new Data("-", "Día"));
		field.setDefaultValue("-");
		ComboBoxValue values = new ComboBoxValue();
		values.setItems(data);
		
		field.setValues(values);
		
		return field;
	}

}
