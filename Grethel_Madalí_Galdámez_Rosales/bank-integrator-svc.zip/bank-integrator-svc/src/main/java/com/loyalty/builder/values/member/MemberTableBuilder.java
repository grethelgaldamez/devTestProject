package com.loyalty.builder.values.member;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.Column;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.TableValue;
import com.loyalty.pojo.fields.table.Language;
import com.loyalty.pojo.fields.table.Paginate;
import com.loyalty.pojo.svc.member.MemberDetail;

@Component("tableMember")
public class MemberTableBuilder implements ValueBuilder<TableValue>{
	private Logger log;
	
	public MemberTableBuilder() {
		this.log = LoggerFactory.getLogger("com.loyalty.logger");
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Field<TableValue> build(Field<TableValue> field, Object... params) {
		List<MemberDetail> lstMember = (List<MemberDetail>) params[0];			
		Language language = new Language();
		Paginate paginate = new Paginate();
		language.setInfo("");
		paginate.setFirst("Primero");
		paginate.setPrevious("Anterior");
		paginate.setNext("Siguiente");
		language.setPaginate(paginate);
		
		Column c1 = new Column();
		c1.setTitle("Número Lifemiles");
		Column c2 = new Column();
		c2.setTitle("Nombre");
		Column c3 = new Column();
		c3.setTitle("Apellido");
		Column c4 = new Column();
		c4.setTitle("Fecha Nacimiento");
		
		//arreglo de columnas
		List<Column> cl = new ArrayList<>();
		cl.add(c1);
		cl.add(c2);
		cl.add(c3);
		cl.add(c4);
		
		//List de strings para rows
		List<String[]> rows = new ArrayList<>();
		
		if (lstMember != null && !lstMember.isEmpty()) {
			for(MemberDetail mem: lstMember){
				String[] row = new String[]{"","","",""};
				row[0] = mem.getMemberNum();
				row[1] = mem.getFirstName();
				row[2] = mem.getLastName();
				row[3] = mem.getBirthDate();				
				rows.add(row);
			}			

			TableValue values = new TableValue();
			values.setColumns(cl);
			values.setData(rows);
			values.setLanguage(language);
			values.setLengthChange(false);
			values.setOrdering(true);
			values.setPagingType("simple_numbers");
			values.setSearching(false);
			values.setPageLength(10);
			values.setPaging(true);
			values.setOrder(new ArrayList<>());
			field.setValues(values);
		} else {
			field.setStatus("hidden");
			log.info("MemberTableBuilder No data Member Found");
		}
		return field;
	}

}
