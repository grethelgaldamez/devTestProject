package com.loyalty.builder.values.member;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.ComboBoxValue;
import com.loyalty.pojo.fields.Data;
import com.loyalty.pojo.fields.Field;

@Component("ddlMonth")
public class MonthCmbBuilder implements ValueBuilder<ComboBoxValue>{

	@Override
	public Field<ComboBoxValue> build(Field<ComboBoxValue> field, Object... params) {		
		
		List<Data> data = new ArrayList<>();
		data.add(new Data("Jan","Ene"));
		data.add(new Data("Feb","Feb"));
		data.add(new Data("Mar","Mar"));
		data.add(new Data("Apr","Abr"));
		data.add(new Data("May","May"));
		data.add(new Data("Jun","Jun"));
		data.add(new Data("Jul","Jul"));
		data.add(new Data("Aug","Ago"));
		data.add(new Data("Sep","Sep"));
		data.add(new Data("Oct","Oct"));
		data.add(new Data("Nov","Nov"));
		data.add(new Data("Dec","Dic"));

		
		data.add(0, new Data("-", "Mes"));
		field.setDefaultValue("-");
		ComboBoxValue values = new ComboBoxValue();
		values.setItems(data);
		
		field.setValues(values);
		
		return field;
	}

}
