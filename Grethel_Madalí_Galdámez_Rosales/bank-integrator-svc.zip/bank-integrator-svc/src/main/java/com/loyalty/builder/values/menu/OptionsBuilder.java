package com.loyalty.builder.values.menu;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.pojo.fields.ComboBoxValue;
import com.loyalty.pojo.fields.Data;
import com.loyalty.pojo.fields.Field;

@Component("ddlOpciones")
public class OptionsBuilder implements ValueBuilder<ComboBoxValue>{

	@Override
	public Field<ComboBoxValue> build(Field<ComboBoxValue> field, Object... params) {		
		
		List<Data> data = new ArrayList<>();
		data.add(new Data("PRDBANK","Consulta de estado de productos bancarios"));
		data.add(new Data("OWNBANK","Transferencia entre cuentas bancarias propias"));
		data.add(new Data("OTHERTRANS","Transferencia a terceros"));
		data.add(new Data("OWNCARD","Pago tarjeta de crédito propia"));
		data.add(new Data("OTHERCARD","Pago trajeta de crédito a terceros"));
		data.add(new Data("OWNPAY","Pago de préstamo bancario"));
		data.add(new Data("OTHERPAY","Pago de préstamo bancario a terceros"));
		data.add(new Data("ADMINBEN","Administrar beneficiarios (Agregar, modificar o eliminar)"));
		
		ComboBoxValue values = new ComboBoxValue();

		values.setItems(data);
		
		field.setValues(values);
		
		return field;
	}

}
