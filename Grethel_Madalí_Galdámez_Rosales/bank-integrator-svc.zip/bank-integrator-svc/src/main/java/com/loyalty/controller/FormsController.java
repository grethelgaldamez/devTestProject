package com.loyalty.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.loyalty.pojo.HeaderRequest;
import com.loyalty.pojo.envelope.Envelope;
import com.loyalty.pojo.envelope.Status;
import com.loyalty.pojo.fields.Form;
import com.loyalty.process.FormProcess;
import com.loyalty.process.IFormProcess;

@RestController
public class FormsController {

	private IFormProcess<Form> process;
	private HeaderRequest header;
	private Logger log;
	
	public FormsController(FormProcess process) {
		this.process = process;
		this.log = LoggerFactory.getLogger("com.loyalty.logger");
	}
	public void buildHeader(HttpHeaders headers){
		try{
			header = new HeaderRequest();
			header.setUser(headers.get("idClient").get(0));
		}
		catch(Exception ex){
			log.error(ex.getMessage(),ex);
			header = null;
		}
	}

	@GetMapping("${config.endpoints.login.form-page}")
	public Envelope<Status,Form> getLoginPage(
			@RequestHeader HttpHeaders  headers){
			buildHeader(headers);
		return process.retrieveLoginForm(header);
	}
	
	@GetMapping("${config.endpoints.menu.form-menu}")
	public Envelope<Status,Form> getMenuPage(
			@RequestHeader HttpHeaders  headers){
			buildHeader(headers);
		return process.retrieveMenuForm(header);
	}
	

}
