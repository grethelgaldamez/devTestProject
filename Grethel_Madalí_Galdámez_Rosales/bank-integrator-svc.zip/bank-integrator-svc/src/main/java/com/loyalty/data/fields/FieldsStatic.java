package com.loyalty.data.fields;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Form;
import com.loyalty.pojo.fields.Message;
import com.loyalty.pojo.fields.Section;
import com.loyalty.pojo.fields.Value;

@Service("FieldStatic")
public class FieldsStatic implements IFieldData<Form> {

	private List<String> groups = new ArrayList<>();

	private Environment env;
	String reqMe = "reqMe";
	String regEx = "regEx";
	String mgPes = "mgPes";
	String mgFmt = "mgFmt";
	String noSup = "noSup";
	String datAc = "datAc";
	String datIn = "datIn";
	String modMe = "modMe";
	String aprMe = "aprMe";
	String pndMe = "pndMe";
	String modPrRe= "modPrRe";
	String newPrAcc= "newPrAcc";
	String newPrRe = "newPrRe";
	String modPrAcc= "modPrAcc";	
	
	
	
	// errores de form.. hacer match con los de application.yml
	String dateFail = "401";
	String notFound = "404";
	String reverted = "402";
	String meNot = "403";
	String mailError = "408";
	String notMod ="407";
	String succ = "000";
	String actAlre = "410";
	String inputMis = "100";
	String errMe = "111";
	String parSave = "112";
	String minlenghtPas = "125";
	String pasReq = "126";
	String failPas = "127";
	String wrongPas = "128";
	String pasNotMatch = "129";
	String apprvExists = "200";
	String exists = "300";
	String notExists = "301";
	String usrBloc = "303";
	String approbers = "416";

	public FieldsStatic(Environment env) {
		groups.add("SUCO");
		this.env = env;
	}

	@Override
	public Form retrieveFormFields(String idForm, String usr) {
		Form form = new Form();
		List<Message> msg;
		
		if(env.getProperty("config.form-names.login-form").equals(idForm)) {
			form = retrieveLoginForm();
		}else if(env.getProperty("config.form-names.menu-form").equals(idForm)) {
			form = retrieveMenuForm();
		}
		return form;
	}
	
	public Form retrieveLoginForm() {
		Form formPojo = new Form();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();
		
		formPojo.setTitle("Plataforma Online LifeBank");
		msg.add(new Message(wrongPas, "Usuario y/o contraseña incorrecto"));
		msg.add(new Message(pasReq, "Por favor, proporciona tu información de ingreso"));
		msg.add(new Message(usrBloc, "Usuario se encuentra bloqueado"));
		msg.add(new Message(notExists, "Usuario no existe"));
		formPojo.setMessages(msg);
		Section section1 = new Section();
		section1.setIdSection("section1");
		
		Field<Value> user = new Field<>();
		user.setId("txtUser");
		user.setLabel("Usuario");
		user.setStatus("visible");
		user.setRequired("Y");
		user.setFormat("^[a-zA-Z0-9]*$");
		fields.add(user);
		
		Field<Value> password = new Field<>();
		password.setLabel("Contraseña");
		password.setId("txtPwd");
		password.setStatus("visible");
		password.setRequired("Y");
		password.setFormat("^[a-zA-Z0-9*@_\\-.#]*$");
		fields.add(password);
		
		Field<Value> btnLog = new Field<>();
		btnLog.setId("btnIngresar");
		btnLog.setLabel("Ingresar");
		btnLog.setStatus("visible");
		fields.add(btnLog);
		section1.setFields(fields);
		sections.add(section1);
		formPojo.setSections(sections);
		return formPojo;
	}
		
		
		
	private Form retrieveMenuForm() {
		Form formPojo = new Form();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		
		formPojo.setTitle("Menú Online LifeBank");
		Section section1 = new Section();
		section1.setIdSection("section1");
		
		
		Field<Value> field1 = new Field<>();
		field1.setAction(null);
		field1.setFormat(null);
		field1.setId("ddlOpciones");
		field1.setLabel("Opciones");
		field1.setRequired("Y");
		field1.setStatus("visible");

		fields.add(field1);
		
		section1.setFields(fields);
		sections.add(section1);
		formPojo.setSections(sections);
		return formPojo;
	}

		// si es aliado PALM o tipo GRUPO devuelve el mismo formulario inicial
		
/*		if (env.getProperty("config.form-names.partner-detail").equals(idForm)
				&& (userLM.equals(user)
						|| userGR.equals(user))) {
			form.setTitle("Información de aliados");						
			
			List<Section> sections = new ArrayList<>();
			Section section = new Section();
			section.setDescription("");
			section.setSubtitle("");
			section.setIdSection("section1");

			List<Field<Value>> fields = new ArrayList<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un aliado"));
			Field<Value> field1 = new Field<>();
			field1.setAction(null);
			field1.setFormat(null);
			field1.setId("ddlComercios");
			field1.setLabel("Aliado");
			field1.setMessages(msg);
			field1.setMaxLength(0);
			field1.setRequired("Y");
			field1.setStatus("visible");
			field1.setType("partnerCmb");

			fields.add(field1);

			Field<Value> field2 = new Field<>();
			field2.setAction(null);
			field2.setFormat(null);
			field2.setId("btnGetInfoCmr");
			field2.setLabel("Cargar Información");
			field2.setMaxLength(0);
			field2.setRequired(null);
			field2.setStatus("visible");
			field2.setType("empty");

			fields.add(field2);

			section.setFields(fields);

			sections.add(section);
			form.setSections(sections);
		} else if (env.getProperty("config.form-names.partner-retail").equals(idForm)
				|| env.getProperty("config.form-names.partner-mcv").equals(idForm)
				|| env.getProperty("config.form-names.partner-grl").equals(idForm)) { //
			if (env.getProperty("config.user-types.partner").equals(user)) {
				form.setTitle("Información de aliados");

				List<Section> sections = new ArrayList<>();
				Section section = new Section();
				section.setDescription("");
				section.setSubtitle("");
				section.setIdSection("section1");

				List<Field<Value>> fields = new ArrayList<>();

				Field<Value> field1 = new Field<>();
				field1.setAction(null);
				field1.setFormat(null);
				field1.setId("ddlComercios");
				field1.setLabel("Aliado");
				field1.setMaxLength(0);
				field1.setRequired("Y");
				field1.setStatus("readonly");
				field1.setType("partnerCmb");

				fields.add(field1);

				Field<Value> field2 = new Field<>();
				field2.setAction(null);
				field2.setFormat(null);
				field2.setId("btnGetInfoCmr");
				field2.setLabel("Cargar Información");
				field2.setMaxLength(0);
				field2.setRequired(null);
				field2.setStatus("hidden");
				field2.setType("");

				fields.add(field2);

				section.setFields(fields);

				sections.add(section);
				form.setSections(sections);

				Form details = retrieveFormPartnerDetailsFields(idForm);

				form.getSections().addAll(details.getSections());
			} else {
				form = retrieveFormPartnerDetailsFields(idForm);
			}
		} else if (env.getProperty("config.form-names.store-detail").equals(idForm)) {
			form = retrieveFormStoreDetailFields(idForm, user);

		} else if (env.getProperty("config.form-names.new-password").equals(idForm)) {
			form = retrieveFormNewPasswordFields(idForm);
		}

		// Formulario de Stores

		else if (env.getProperty("config.form-names.stores").equals(idForm)) {
			form.setTitle("Información de establecimiento");

			List<Section> sections = new ArrayList<>();
			Section section = new Section();
			section.setDescription("");
			section.setSubtitle("");
			section.setIdSection("section1");

			List<Field<Value>> fields = new ArrayList<>();

			Field<Value> field1 = new Field<>();
			field1.setAction(null);
			field1.setFormat(null);
			field1.setId("ddlComercios");
			field1.setLabel("Aliado");
			field1.setMaxLength(0);
			field1.setRequired("Y");
			if (env.getProperty("config.user-types.partner").equals(user)) {
				field1.setStatus("readonly");
			} else {
				field1.setStatus("visible");
			}
			field1.setType("partnerCmb");

			fields.add(field1);

			Field<Value> fieldStore = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione un establecimiento"));
			fieldStore.setAction(null);
			fieldStore.setFormat(null);
			fieldStore.setId("ddlStore");
			fieldStore.setLabel("Establecimiento");
			fieldStore.setMessages(msg);
			fieldStore.setMaxLength(100);
			fieldStore.setRequired("Y");
			fieldStore.setStatus("visible");
			fieldStore.setType("storeCmb");

			fields.add(fieldStore);

			Field<Value> field2 = new Field<>();
			field2.setAction(null);
			field2.setFormat(null);
			field2.setId("btnGetInfoStr");
			field2.setLabel("Cargar Información");
			field2.setMaxLength(0);
			field2.setRequired(null);
			field2.setStatus("visible");
			field2.setType("empty");

			fields.add(field2);

			section.setFields(fields);

			sections.add(section);
			form.setSections(sections);
		}
		// formulario de accumulacion de promociones

		else if (env.getProperty("config.form-names.prom-acc").equals(idForm)) {
			form = retrieveAccPromotionForm(user, env.getProperty("config.prom-types.accrual"));
		} else if (env.getProperty("config.form-names.prom-ret").equals(idForm)
				&& userLM.equals(user)) {
			form = retrieveAccPromotionForm(user, env.getProperty("config.prom-types.redemption"));
		}

		else if (env.getProperty("config.form-names.prom-hist").equals(idForm)) {
			form = retrieveHistoryForm(user);
		} else if (env.getProperty("config.form-names.info-prom-acc").equals(idForm)) {
			form = retrieveInfoPromotionForm(user, env.getProperty("config.prom-types.accrual"));
		} else if (env.getProperty("config.form-names.info-prom-red").equals(idForm)) {
			form = retrieveInfoPromotionForm(user, env.getProperty("config.prom-types.redemption"));
		} else if (env.getProperty("config.form-names.add-member").equals(idForm)) {
			form = retrieveAddMemberForm();
		} else if (env.getProperty("config.form-names.find-member").equals(idForm)) {
			form = retrieveFinderFormFields(user);
		} else if (env.getProperty("config.form-names.member-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("tableMember");
			sec.setIdSection("section3");
			sec.setSubtitle("Resultado de la búsqueda");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);

		} else if (env.getProperty("config.form-names.pos-member-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("tablePosMember");
			sec.setIdSection("tableSection");
			sec.setSubtitle("Resultado de la búsqueda");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);

		} else if (env.getProperty("config.form-names.mcv-member-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("tableMcvMember");
			sec.setIdSection("tableSection");
			sec.setSubtitle("Resultado de la búsqueda");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);

		} else if (env.getProperty("config.form-names.acc-mcv-search").equals(idForm)) {
			form = retrieveAccMcvSearch();
		} else if (env.getProperty("config.form-names.acc-mcv").equals(idForm)) {
			form = retrieveAccMcv();
		} else if (env.getProperty("config.form-names.acc-pos-web").equals(idForm)) {
			form = retrieveAccPosWeb();
		} else if (env.getProperty("config.form-names.password-reset").equals(idForm)) {
			form = retrievePasswordResetForm(user);
		} else if (env.getProperty("config.form-names.acc-pos-search").equals(idForm)) {
			form.setTitle("Acumulación POS WEB");
			List<Message> formMessages = new ArrayList<>();
			formMessages.add(new Message(meNot, "No se encontró información del socio con los parámetros enviados"));
			form.setMessages(formMessages);
			List<Section> sections = new ArrayList<>();
			Section section = new Section();
			section.setDescription(
					"Complete la siguiente <i>Información</i> para obtener los datos del <i>Socio LifeMiles</i>");
			section.setSubtitle("Acumulación POS WEB");
			section.setIdSection("section1");

			List<Field<Value>> fields = new ArrayList<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un ID"));
			msg.add(new Message(regEx, "Ingrese solamente numeros"));
			Field<Value> field1 = new Field<>();
			field1.setAction(null);
			field1.setFormat("^[0-9]*$");
			field1.setId("txtNumLM");
			field1.setLabel("ID LifeMiles:");
			field1.setMessages(msg);
			field1.setMaxLength(11);
			field1.setRequired("Y");
			field1.setStatus("visible");

			fields.add(field1);

			section.setFields(fields);
			sections.add(section);

			Section section2 = new Section();
			section2.setDescription(
					"Verifique los datos ingresados para el Socio y presione <i>Buscar</i> para obtener la información.");
			section2.setIdSection("section2");

			List<Field<Value>> fields2 = new ArrayList<>();
			Field<Value> btnGuardar = new Field<>();
			btnGuardar.setId("btnBuscar");
			btnGuardar.setLabel("Buscar");
			btnGuardar.setStatus("visible");

			fields2.add(btnGuardar);

			section2.setFields(fields2);

			sections.add(section2);

			form.setSections(sections);
		} else if (env.getProperty("config.form-names.rev-acc-form").equals(idForm)) {
			form.setTitle("Reversion de transacciones");

			List<Section> sections = new ArrayList<>();
			List<Field<Value>> fields = new ArrayList<>();
			List<Message> formMessages = new ArrayList<>();
			formMessages.add(new Message(dateFail,
					"No se puede procesar la reversión ya que han transcurrido más de 30 días desde la fecha en que se realizó la transacción"));
			formMessages.add(new Message(notFound, "No se encontró el código de autorización"));
			formMessages.add(new Message(reverted, "Transacción ya fue revertida"));
			form.setMessages(formMessages);

			Section section1 = new Section();
			section1.setDescription(
					"Para desplegar la información de la transacción, ingrese el número de autorización y luego presione <i>Cargar Información</i>");
			section1.setIdSection("section1");

			Field<Value> cmbPartner = new Field<>();
			cmbPartner.setId("ddlPartnerRev");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione una opción"));
			msg.add(new Message(regEx, "Seleccione una opción válida"));
			cmbPartner.setMessages(msg);
			cmbPartner.setLabel("Aliado:");
			cmbPartner.setRequired("Y");
			cmbPartner.setStatus("visible");
			cmbPartner.setPlaceholder("Aliado");

			fields.add(cmbPartner);

			Field<Value> autCode = new Field<>();
			autCode.setId("txtAutNum");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un número de autorización"));
			msg.add(new Message(regEx, "Ingrese valores numéricos"));
			autCode.setMessages(msg);
			autCode.setLabel("N. de Autorización");
			autCode.setStatus("visible");
			autCode.setFormat("^([0-9]*)$");
			autCode.setPlaceholder("Número de Autorización");
			autCode.setRequired("Y");

			fields.add(autCode);

			Field<Value> btnSearch = new Field<>();
			btnSearch.setId("btnGetInfoSoc");
			btnSearch.setLabel("Cargar Información");
			btnSearch.setStatus("visible");

			fields.add(btnSearch);

			section1.setFields(fields);
			sections.add(section1);
			form.setSections(sections);

		} else if (env.getProperty("config.form-names.rev-acc-info").equals(idForm)) {
			form = retrieveRevAccInfo();

		} else if (env.getProperty("config.form-names.gift-cards-act").equals(idForm)) {
			form = retrieveGiftCard();

		} else if (env.getProperty("config.form-names.hist-pre-purchase").equals(idForm)) {
			form.setTitle("Búsqueda de Pre-compras");

			List<Section> sections = new ArrayList<>();
			List<Field<Value>> fields = new ArrayList<>();
			List<Message> formMessages = new ArrayList<>();

			formMessages.add(new Message(notFound, "No se encontró precompras para el aliado"));
			form.setMessages(formMessages);

			Section section1 = new Section();

			section1.setDescription("Por favor complete los campos para realizar la búsqueda");
			section1.setIdSection("section1");

			Field<Value> partner = new Field<>();
			partner.setId("ddlPartnerPreHist");
			partner.setLabel("Aliado:");
			partner.setPlaceholder("Aliado");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Por favor seleccione una opción"));
			partner.setMessages(msg);
			partner.setStatus("visible");
			partner.setRequired("Y");

			fields.add(partner);
			section1.setFields(fields);
			sections.add(section1);

			Section section2 = new Section();

			section2.setDescription("Seleccione una pre-compra configurada para el aliado");
			section2.setSubtitle("Selección de Pre-Compra");
			section2.setIdSection("section2");

			fields = new ArrayList<>();
			Field<Value> prePurchase = new Field<>();
			prePurchase.setId("ddlPreCompraHist");
			prePurchase.setLabel("Pre-Compra:");
			prePurchase.setPlaceholder("Pre-Compra:");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Por favor seleccione una Pre-Compra "));
			prePurchase.setMessages(msg);
			prePurchase.setStatus("visible");
			prePurchase.setRequired("N");

			fields.add(prePurchase);

			section2.setFields(fields);
			sections.add(section2);

			Section section3 = new Section();

			section3.setDescription("Por favor, seleccione un rango de fecha para Inicio de Vigencia de Pre-Compra");
			section3.setIdSection("section3");
			section3.setSubtitle("Fecha de Inicio de Vigencia");
			fields = new ArrayList<>();

			Field<Value> firstStartDate = new Field<>();
			firstStartDate.setId("txtFechaDesdeVig");
			firstStartDate.setLabel("Fecha Desde:");
			firstStartDate.setPlaceholder("Fecha Desde Inicio Vigencia");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Por favor seleccione una fecha"));
			msg.add(new Message(regEx, "La fecha de inicio debe ser menor a la fecha de fin"));
			firstStartDate.setMessages(msg);
			firstStartDate.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");
			firstStartDate.setStatus("visible");
			firstStartDate.setRequired("N");

			fields.add(firstStartDate);

			Field<Value> lastStartDate = new Field<>();
			lastStartDate.setId("txtFechaHVigIni");
			lastStartDate.setLabel("Fecha Hasta:");
			lastStartDate.setPlaceholder("Fecha Hasta Inicio Vigencia");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Por favor seleccione una fecha"));
			msg.add(new Message(regEx, "La fecha de inicio debe ser menor a la fecha de fin"));
			lastStartDate.setMessages(msg);
			lastStartDate.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");
			lastStartDate.setStatus("visible");
			lastStartDate.setRequired("N");

			fields.add(lastStartDate);

			section3.setFields(fields);
			sections.add(section3);

			Section section4 = new Section();

			section4.setDescription("Por favor, seleccione un rango de fecha para Inicio de Vigencia de Pre-Compra");
			section4.setSubtitle("Fecha de Fin de Vigencia");
			section4.setIdSection("section4");
			fields = new ArrayList<>();

			Field<Value> firstEndDate = new Field<>();
			firstEndDate.setId("txtFechaDVigFin");
			firstEndDate.setLabel("Fecha Desde:");
			firstEndDate.setPlaceholder("Fecha Desde Fin Vigencia");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Por favor seleccione una fecha"));
			msg.add(new Message(regEx, "La fecha de inicio debe ser menor a la fecha de fin"));
			firstEndDate.setMessages(msg);
			firstEndDate.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");
			firstEndDate.setStatus("visible");
			firstEndDate.setRequired("N");

			fields.add(firstEndDate);

			Field<Value> lastEndDate = new Field<>();
			lastEndDate.setId("txtFechaHVigFin");
			lastEndDate.setLabel("Fecha Hasta:");
			lastEndDate.setPlaceholder("Fecha Hasta Fin Vigencia");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Por favor seleccione una fecha"));
			msg.add(new Message(regEx, "La fecha de inicio debe ser menor a la fecha de fin"));
			lastEndDate.setMessages(msg);
			lastEndDate.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");
			lastEndDate.setStatus("visible");
			lastEndDate.setRequired("N");

			fields.add(lastEndDate);

			section4.setFields(fields);
			sections.add(section4);

			Section section5 = new Section();
			section5.setDescription(
					"Para realizar la búsqueda de Pre-Compra, por favor seleccione el botón <i>Buscar</i>");
			section5.setIdSection("section5");
			fields = new ArrayList<>();
			Field<Value> btnSearch = new Field<>();
			btnSearch.setId("btnBuscarPre");
			btnSearch.setLabel("Buscar");
			btnSearch.setStatus("visible");

			fields.add(btnSearch);

			// fin de seccion
			section5.setFields(fields);
			sections.add(section5);

			// agregando secciones al form
			form.setSections(sections);

		} else if (env.getProperty("config.form-names.gift-cards-report").equals(idForm)) {
			form = retrieveGiftCardReport(user);
		} else if (env.getProperty("config.form-names.gift-cards-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("tableReportGiftCard");
			sec.setIdSection("tableSection");
			sec.setSubtitle("Listado de GiftCards");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);
		} else if (env.getProperty("config.form-names.red-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("tableReportWSRedemption");
			sec.setIdSection("tableSection");
			sec.setSubtitle("Listado de Redenciones");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);
		} else if (env.getProperty("config.form-names.mcv-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("tableReportMcv");
			sec.setIdSection("tableSection");
			sec.setSubtitle("Reporte de Transacciones WS MCV");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);
		} else if (env.getProperty("config.form-names.tra-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("tableReportTransaction");
			sec.setIdSection("tableSection");
			sec.setSubtitle("Listado de Transacciones");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);
		} else if (env.getProperty("config.form-names.cashier-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("tableReportCashier");
			sec.setIdSection("tableSection");
			sec.setSubtitle("Listado de Cajeros");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);
		} else if (env.getProperty("config.form-names.pre-purchase-mod").equals(idForm) ||
				env.getProperty("config.form-names.pre-purchase-ppal").equals(idForm)) {
			form = retrieveFormPrepurchaseFields(idForm);
		} else if (env.getProperty("config.form-names.pre-purchase-table").equals(idForm)) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f = new Field<>();
			f.setStatus("visible");
			f.setId("histPre");
			sec.setIdSection("section6");
			sec.setSubtitle("Resultado de la búsqueda");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form.setSections(sections);
		} else if (env.getProperty("config.form-names.red-report").equals(idForm)) {
			form = retrieveRedReportForm(user);
		} else if (env.getProperty("config.form-names.mcv-report").equals(idForm)) {
			form = retrieveMilesCVReportForm(user);
		} else if (env.getProperty("config.form-names.cashier-report").equals(idForm)) {
			form = retrieveCashierReportForm(user);
		} else if (env.getProperty("config.form-names.ppal-tra-report").equals(idForm)
				&& userLM.equals(user)) {
			form.setTitle("Reporte de transacciones");

			List<Section> sections = new ArrayList<>();
			List<Field<Value>> fields = new ArrayList<>();

			Section section1 = new Section();
			section1.setIdSection("section0");

			Field<Value> rbSearchType = new Field<>();
			rbSearchType.setId("rbSearchType");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione un tipo de busqueda"));
			rbSearchType.setMessages(msg);
			rbSearchType.setLabel("Seleccione:");
			rbSearchType.setRequired("Y");
			rbSearchType.setStatus("visible");

			fields.add(rbSearchType);

			Field<Value> btnSearch = new Field<>();
			btnSearch.setId("btnGetInfoSoc");
			btnSearch.setLabel("Cargar");
			btnSearch.setStatus("visible");

			fields.add(btnSearch);

			section1.setFields(fields);
			sections.add(section1);
			form.setSections(sections);

		} else if (env.getProperty("config.form-names.tra-cmr-report").equals(idForm)
				|| env.getProperty("config.form-names.tra-cou-report").equals(idForm)
				|| (env.getProperty("config.form-names.ppal-tra-report").equals(idForm)
						&& !userLM.equals(user))) {
			form = retrieveTransReport(idForm, user);
		} else if (env.getProperty("config.form-names.info-user-ppal-form").equals(idForm)) {
			form.setTitle("Información de usuario");

			List<Section> sections = new ArrayList<>();
			List<Field<Value>> fields = new ArrayList<>();
			msg = new ArrayList<>();
			Section section1 = new Section();
			section1.setIdSection("section1");

			Field<Value> groupCombo = new Field<>();
			groupCombo.setId("slt_conso");
			groupCombo.setLabel("Grupo:");
			msg.add(new Message(reqMe, "Debe seleccionar una opción"));
			groupCombo.setMessages(msg);
			groupCombo.setPlaceholder("Grupo");
			groupCombo.setRequired("Y");
			if (userGR.equals(user)
					|| userLM.equals(user)) {

				groupCombo.setStatus("visible");
				groupCombo.setRequired("Y");
			}

			fields.add(groupCombo);

			Field<Value> partnerCombo = new Field<>();
			partnerCombo.setId("slt_commmerce");
			partnerCombo.setLabel("Aliado:");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe seleccionar una aliado"));
			partnerCombo.setMessages(msg);
			partnerCombo.setPlaceholder("Aliados");
			if (env.getProperty("config.user-types.partner").equals(user)) {
				partnerCombo.setStatus("visible");
				partnerCombo.setRequired("Y");
				groupCombo.setStatus("hidden");
			} else {
				partnerCombo.setStatus("hidden");
				partnerCombo.setRequired("N");
			}

			fields.add(partnerCombo);

			Field<Value> userCombo = new Field<>();
			userCombo.setId("slt_usuario");
			userCombo.setLabel("Usuario:");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe seleccionar un aliado"));
			userCombo.setMessages(msg);
			userCombo.setPlaceholder("Usuarios asignados a Usuarios");
			// userCombo.setStatus("hidden"); //al inicio del formulario debe ir
			// oculto este combobox

			fields.add(userCombo);

			Field<Value> button = new Field<>();
			button.setId("btn_viewInfo");
			button.setLabel("Ver Información");
			button.setStatus("visible");
			fields.add(button);

			section1.setFields(fields);

			sections.add(section1);

			form.setSections(sections);

		} else */
		

/*	public Form retrievePasswordResetForm(String user) {
		Form formPass = new Form();
		formPass.setTitle("Restablecer Contraseña");
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg;

		msg = new ArrayList<>();
		msg.add(new Message(minlenghtPas, "La contraseña debe contener mínimo 8 caracteres."));
		msg.add(new Message(pasReq, "La contraseña debe contener al menos una mayúscula, una minúscula y un número"));
		msg.add(new Message(failPas, "La contraseña nueva no debe ser igual a la contraseña anterior"));
		msg.add(new Message(wrongPas, "La contraseña actual no coincide"));
		msg.add(new Message(pasNotMatch, "La contraseña nueva no coincide con la confirmación"));
		formPass.setMessages(msg);

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setDescription("");

		if (user.equals(userLM)
				|| user.equals(userGR)) {

			Field<Value> groupCombo = new Field<>();
			groupCombo.setId("slt_conso");
			groupCombo.setLabel("Grupo:");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe seleccionar un grupo"));
			groupCombo.setMessages(msg);
			groupCombo.setPlaceholder("Grupos disponibles");
			groupCombo.setStatus("visible");

			fields.add(groupCombo);
		}
		if (user.equals(userLM)
				|| user.equals(env.getProperty("config.user-types.partner"))) {

			Field<Value> partnerCombo = new Field<>();
			partnerCombo.setId("slt_commmerce");
			partnerCombo.setLabel("Aliado:");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe seleccionar un aliado"));
			partnerCombo.setMessages(msg);
			partnerCombo.setPlaceholder("Aliados disponibles");
			partnerCombo.setStatus("hidden");

			fields.add(partnerCombo);
		}

		Field<Value> userCombo = new Field<>();
		userCombo.setId("slt_usuario");
		userCombo.setLabel("Usuario:");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar un usuario"));
		userCombo.setMessages(msg);
		userCombo.setPlaceholder("Usuarios disponibles");
		userCombo.setStatus("visible");

		fields.add(userCombo);

		section1.setFields(fields);
		sections.add(section1);

		fields = new ArrayList<>();

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setDescription(
				"En caso de que el usuario seleccionado no recuerde su contraseña, ingrese una contraseña nueva para él.");

		Field<Value> field = new Field<>();
		field.setId("txtPassNew");
		field.setPlaceholder("Nueva contraseña");
		field.setLabel("Nueva contraseña:");
		field.setFormat("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d.-_*$]{8,}$");
		msg = new ArrayList<>();
		msg.add(new com.loyalty.pojo.fields.Message(regEx,
				"Debe tener longitud mínima de 8 y contener al menos una mayúscula, una minúscula y un número"));
		msg.add(new com.loyalty.pojo.fields.Message(reqMe, "Ingrese la contraseña nueva"));
		field.setMessages(msg);
		field.setRequired("Y");
		field.setStatus("visible");

		fields.add(field);

		Field<Value> field3 = new Field<>();
		field3.setId("txtPassNewConfirm");
		field3.setPlaceholder("Confirmar contraseña");
		field3.setLabel("Confirmar contraseña:");
		field3.setFormat("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d.-_*$]{8,}$");
		msg = new ArrayList<>();
		msg.add(new com.loyalty.pojo.fields.Message(regEx,
				"Debe tener longitud mínima de 8 y contener al menos una mayúscula, una minúscula y un número"));
		msg.add(new com.loyalty.pojo.fields.Message(reqMe, "Las contraseñas deben de coincidir"));
		field3.setMessages(msg);
		field3.setRequired("Y");
		field3.setStatus("visible");

		fields.add(field3);

		field = new Field<>();
		field.setId("btt_Guardar");
		field.setStatus("visible");
		field.setLabel("Guardar");
		fields.add(field);

		section2.setFields(fields);
		sections.add(section2);
		formPass.setSections(sections);

		return formPass;

	}

	public Form retrieveFormNewPasswordFields(String idForm) {
		Form formPass = new Form();
		formPass.setTitle("Cambio de Contraseña");
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg =  new ArrayList<>();
		msg.add(new Message(minlenghtPas, "La contraseña debe contener mínimo 8 caracteres."));
		msg.add(new Message(pasReq, "La contraseña debe contener al menos una mayúscula, una minúscula y un número"));
		msg.add(new Message(failPas, "La contraseña nueva no debe ser igual a la contraseña anterior"));
		msg.add(new Message(wrongPas, "La contraseña actual no coincide"));
		msg.add(new Message(pasNotMatch, "La contraseña nueva no coincide con la confirmación"));
		formPass.setMessages(msg);

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setDescription("Ingrese la contraseña actual y la nueva que desee utilizar.");

		Field<Value> field = new Field<>();
		field.setId("txtPassAct");
		field.setPlaceholder("Contraseña actual");
		field.setLabel("Contraseña actual:");
		field.setFormat("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d.-_*$]{8,}$");
		msg = new ArrayList<>();
		msg.add(new com.loyalty.pojo.fields.Message(regEx,
				"Debe tener longitud mínima de 8 y contener al menos una mayúscula, una minúscula y un número"));
		msg.add(new com.loyalty.pojo.fields.Message(reqMe, "Ingrese su contraseña actual"));
		field.setMessages(msg);
		field.setRequired("Y");
		field.setStatus("visible");

		fields.add(field);

		Field<Value> field2 = new Field<>();
		field2.setId("txtPassNew");
		field2.setPlaceholder("Nueva contraseña");
		field2.setLabel("Nueva contraseña:");
		field2.setFormat("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d.-_*$]{8,}$");
		msg = new ArrayList<>();
		msg.add(new com.loyalty.pojo.fields.Message(regEx,
				"Debe tener longitud mínima de 8 y contener al menos una mayúscula, una minúscula y un número"));
		msg.add(new com.loyalty.pojo.fields.Message(reqMe, "Ingrese su contraseña nueva"));
		field2.setMessages(msg);
		field2.setRequired("Y");
		field2.setStatus("visible");

		fields.add(field2);

		Field<Value> field3 = new Field<>();
		field3.setId("txtPassNewConfirm");
		field3.setPlaceholder("Confirmar contraseña");
		field3.setLabel("Confirmar contraseña:");
		field3.setFormat("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d.-_*$]{8,}$");
		msg = new ArrayList<>();
		msg.add(new com.loyalty.pojo.fields.Message(regEx,
				"Debe tener longitud mínima de 8 y contener al menos una mayúscula, una minúscula y un número"));
		msg.add(new com.loyalty.pojo.fields.Message(reqMe, "Las contraseñas deben de coincidir"));
		field3.setMessages(msg);
		field3.setRequired("Y");
		field3.setStatus("visible");

		fields.add(field3);

		field = new Field<>();
		field.setId("btt_Guardar");
		field.setStatus("visible");
		field.setLabel("Guardar");
		fields.add(field);

		section1.setFields(fields);
		sections.add(section1);
		formPass.setSections(sections);

		return formPass;

	}

	// FORMULARIO DE PRE-COMPRAS
	public Form retrieveFormPrepurchaseFields(String idForm) {
		Form form = new Form();
		form.setTitle("Información General");
		List<Message> messagesForm = new ArrayList<>();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> messages;
		messagesForm.add(new Message(meNot, "No se encontró información asociada"));
		messagesForm.add(new Message(notMod, "{0}"));
		form.setMessages(messagesForm);

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setSubtitle("Individual");
		section1.setDescription("");

		Field<Value> field1 = new Field<>();
		messages = new ArrayList<>();
		messages.add(new Message(reqMe, "Seleccione un aliado"));
		field1.setAction(null);
		field1.setFormat(null);
		field1.setId("ddlAliado");
		field1.setLabel("Aliado");
		field1.setMessages(messages);
		field1.setMaxLength(0);
		field1.setRequired("Y");
		field1.setStatus("visible");
		field1.setType("partnerCmb");

		fields.add(field1);

		Field<Value> field2 = new Field<>();
		messages = new ArrayList<>();
		messages.add(new Message(reqMe, "Seleccione uno"));
		field2.setAction(null);
		field2.setFormat(null);
		field2.setId("ddlPreCompras");
		field2.setLabel("Bono");
		field2.setMessages(messages);
		field2.setMaxLength(0);
		field2.setRequired("Y");
		field2.setStatus("visible");
		field2.setType("precompraCmb");

		fields.add(field2);

		Field<Value> field3 = new Field<>();
		messages = new ArrayList<>();
		messages.add(new Message(reqMe, "Cantidad"));
		messages.add(new Message(regEx, "Ingrese un valor correcto"));
		field3.setMessages(messages);
		field3.setAction(null);
		field3.setFormat("^[0-9]{1,3}((,[0-9]{3})*)?$");
		field3.setId("txtValorLM");
		field3.setLabel("Cantidad");
		field3.setMaxLength(20);
		field3.setRequired("Y");
		field3.setStatus("visible");
		field3.setType("empty");

		fields.add(field3);

		Field<Value> inicioDate = new Field<>();
		inicioDate.setId("txtInicioPP");
		inicioDate.setLabel("Fecha de inicio:");
		inicioDate.setStatus("visible");
		inicioDate.setRequired("Y");
		inicioDate.setPlaceholder("Fecha de Inicio");
		inicioDate.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");// pendiente
		List<Message> inicioDateMessage = new ArrayList<>();
		inicioDateMessage.add(new Message(reqMe, "Ingrese la Fecha de inicio"));
		inicioDateMessage.add(new Message(regEx, "Ingrese la fecha en formato dd/MM/yyyy"));
		inicioDateMessage.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		inicioDate.setMessages(inicioDateMessage);

		fields.add(inicioDate);

		Field<Value> finDate = new Field<>();
		finDate.setId("txtFinPP");
		finDate.setLabel("Fecha de fin:");
		finDate.setStatus("visible");
		finDate.setRequired("Y");
		finDate.setPlaceholder("Fecha de fin");
		finDate.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");// pendiente
		List<Message> finDateMessage = new ArrayList<>();
		finDateMessage.add(new Message(reqMe, "Ingrese la Fecha de fin"));
		finDateMessage.add(new Message(regEx, "Ingrese la fecha en formato dd/MM/yyyy"));
		finDateMessage.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		finDate.setMessages(finDateMessage);
		fields.add(finDate);

		Field<Value> status = new Field<>();
		status.setId("hStatus");
		status.setStatus("hidden");

		fields.add(status);

		section1.setFields(fields);
		sections.add(section1);

		// seccion 2: sección del botón
		fields = new ArrayList<>();
		Section section2 = new Section();
		section2.setIdSection("section2");

		section2.setDescription("");
		Field<Value> btnGuardar = new Field<>();
		btnGuardar.setAction(null);
		btnGuardar.setFormat(null);
		btnGuardar.setId("btnGuardar");
		btnGuardar.setLabel("Guardar");
		btnGuardar.setMaxLength(null);
		btnGuardar.setStatus("visible");
		btnGuardar.setType("");

		fields.add(btnGuardar);
		section2.setFields(fields);
		sections.add(section2);

		form.setSections(sections);
		return form;

	}

	public Form retrieveFormPartnerDetailsFields(String idForm) {
		Form form = new Form();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();
		
		msg.add(new Message(succ, "La solicitud ha sido creada exitosamente. Su código es: {0}"));
		msg.add(new Message(mailError, "No ha sido posible enviar el correo al aprobador <br />"
				+ "La solicitud ha sido creada. Su código es: {0}"));
		msg.add(new Message(approbers, "La solicitud no ha sido ingresada debido a falta de configuración de aprobadores"));
		form.setMessages(msg);
		
		Section section = new Section();
		section.setDescription("");
		section.setSubtitle("");
		section.setIdSection("section2");

		List<Field<Value>> fields = new ArrayList<>();

		Field<Value> field1 = new Field<>();
		field1.setAction(null);
		field1.setFormat(null);
		field1.setId("imgLogo");
		field1.setLabel(null);
		field1.setMaxLength(null);
		field1.setRequired("N");
		field1.setStatus("visible");
		field1.setType("empty");

		fields.add(field1);

		Field<Value> field2 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(mgPes, "La imagen debe de tener un peso menor o igual a 1MB"));
		msg.add(new Message(mgFmt, "La imagen tiene debe de estar en formato PNG"));
		msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
		field2.setMessages(msg);
		field2.setAction(null);
		field2.setFormat(null);
		field2.setId("fileImage");
		field2.setLabel("Logo...");
		field2.setMaxLength(null);
		field2.setRequired(null);
		field2.setStatus("visible");
		field2.setType("empty");
		field2.setDefaultValue("No ha seleccionado ningún archivo");

		fields.add(field2);

		Field<Value> field3 = new Field<>();
		msg.add(new Message(reqMe, "Ingrese un ID"));
		field3.setAction(null);
		field3.setFormat(null);
		field3.setId("txtID");
		field3.setLabel("ID Aliado:");
		field3.setPlaceholder("ID Aliado");
		field3.setMessages(msg);
		field3.setMaxLength(5);
		field3.setRequired(null);
		field3.setStatus("readonly");
		field3.setType("empty");

		fields.add(field3);

		Field<Value> field4 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un grupo"));
		field4.setAction(null);
		field4.setFormat(null);
		field4.setId("ddlConso");
		field4.setLabel("Grupo:");
		field4.setMessages(msg);
		field4.setMaxLength(null);
		field4.setRequired("N");
		field4.setStatus("visible");
		field4.setType("partnerDetailCmb");

		fields.add(field4);

		Field<Value> field5 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una razón Social"));
		field5.setAction(null);
		field5.setFormat(null);
		field5.setId("txtRazons");
		field5.setLabel("Razón Social:");
		field5.setPlaceholder("Razón social del aliado");
		field5.setMessages(msg);
		field5.setMaxLength(50);
		field5.setRequired("Y");
		field5.setStatus("visible");
		field5.setType("empty");

		fields.add(field5);

		Field<Value> field6 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un numero de telefono"));
		msg.add(new Message(regEx, "Ingrese un numero de telefono con un formato correcto"));
		field6.setAction(null);
		field6.setFormat("^([0-9\\(\\)\\/\\+ \\-]*)$");
		field6.setId("txtTel");
		field6.setLabel("Teléfono:");
		field6.setPlaceholder("Número telefónico de contacto");
		field6.setMessages(msg);
		field6.setMaxLength(15);
		field6.setRequired("Y");
		field6.setStatus("visible");
		field6.setType("empty");

		fields.add(field6);

		Field<Value> field7 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una dirección de correo correcta"));
		msg.add(new Message(regEx, "Ingrese una dirección de correo correcta"));
		field7.setAction(null);
		field7.setFormat("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)+$");
		field7.setId("txtEmail");
		field7.setLabel("Email:");
		field7.setPlaceholder("Correo electrónico de contacto");
		field7.setMessages(msg);
		field7.setMaxLength(40);
		field7.setRequired("N");
		field7.setStatus("visible");
		field7.setType("empty");

		fields.add(field7);

		Field<Value> field8 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una direccion de página web"));
		msg.add(new Message(regEx, "Ingrese una direccion de página web valida"));
		field8.setAction(null);
		field8.setFormat("^(www?.)?([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([\\/\\w \\?=.-]*)*\\/?$");
		field8.setId("txtWebPage");
		field8.setLabel("Página Web:");
		field8.setPlaceholder("Ingrese dirección de su sitio web");
		field8.setMessages(msg);
		field8.setMaxLength(40);
		field8.setRequired("N");
		field8.setStatus("visible");
		field8.setType("empty");

		fields.add(field8);

		Field<Value> field9 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese el Nombre Comercial"));
		field9.setAction(null);
		field9.setFormat(null);
		field9.setId("txtNombrec");
		field9.setLabel("Nombre Comercial:");
		field9.setPlaceholder("Nombre comercial del aliado");
		field9.setMessages(msg);
		field9.setMaxLength(30);
		field9.setRequired("Y");
		field9.setStatus("readonly");
		field9.setType("empty");

		fields.add(field9);

		Field<Value> field10 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Seleccione una categoria"));
		field10.setAction(null);
		field10.setFormat(null);
		field10.setId("ddlCategoria");
		field10.setLabel("Categoría:");
		field10.setMessages(msg);
		field10.setMaxLength(null);
		field10.setRequired("Y");
		field10.setStatus("readonly");
		field10.setType("partnerDetailCmb");

		fields.add(field10);

		Field<Value> field11 = new Field<>();
		field11.setAction(null);
		field11.setFormat(null);
		field11.setId("areaDescrip");
		field11.setLabel("Descripción del aliado");
		field11.setMaxLength(200);
		field11.setRequired("N");
		field11.setStatus("visible");
		field11.setType("empty");

		fields.add(field11);

		Field<Value> field12 = new Field<>();
		field12.setAction(null);
		field12.setFormat(null);
		field12.setId("pCmrEstado");
		field12.setLabel("Estado");
		field12.setMaxLength(null);
		field12.setRequired("Y");
		field12.setStatus("visible");
		field12.setType("partnerRadio");

		fields.add(field12);

		section.setFields(fields);

		sections.add(section);

		// Sección Configuraciones y MCV
		if (env.getProperty("config.form-names.partner-retail").equals(idForm)) {

			Section section2 = new Section();
			section2.setDescription(
					"Para agregar establecimientos al comercio seleccionado, presione <i>Adjuntar</i> y seleccione el archivo de Excel con la <a id='ClbSuc' class='Colorbox cboxElement' href='#divClbSuc'>estructura definida</a>. <a href='Filestmp/Layout_Sucursales.xls' target='_blank'>Descargar Layout</a>");
			section2.setSubtitle("Administrar establecimientos");
			section2.setIdSection("section3");
			List<Field<Value>> fields2 = new ArrayList<>();

			Field<Value> fileSuc = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe seleccionar un archivo excel"));
			msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
			fileSuc.setMessages(msg);
			fileSuc.setAction(null);
			fileSuc.setFormat(null);
			fileSuc.setId("FileSuc");
			fileSuc.setLabel("Adjuntar...");
			fileSuc.setDefaultValue("No ha seleccionado ningún archivo");
			fileSuc.setMaxLength(null);
			fileSuc.setRequired("N");
			fileSuc.setStatus("visible");
			fileSuc.setType("");

			fields2.add(fileSuc);

			section2.setFields(fields2);

			sections.add(section2);

			// Seccion configuraciones

			Section section3 = new Section();
			section3.setDescription(
					"Para agregar configuraciones al comercio, presione <i>Adjuntar</i> y seleccione el archivo de Excel con la <a id='ClbCnf' class='Colorbox cboxElement' href='#divClbCnf'>estructura definida</a>. <a href='Filestmp/Layout_Configuraciones.xls' target='_blank'>Descargar Layout</a>");
			section3.setSubtitle("Administrar configuraciones");
			section3.setIdSection("section4");
			List<Field<Value>> fields3 = new ArrayList<>();

			Field<Value> fileCnf = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe seleccionar un archivo excel"));
			msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
			fileCnf.setMessages(msg);
			fileCnf.setAction(null);
			fileCnf.setFormat(null);
			fileCnf.setId("FileCnf");
			fileCnf.setLabel("Adjuntar...");
			fileCnf.setDefaultValue("No ha seleccionado ningún archivo");
			fileCnf.setMaxLength(null);
			fileCnf.setRequired("N");
			fileCnf.setStatus("visible");
			fileCnf.setType("");

			fields3.add(fileCnf);

			section3.setFields(fields3);

			sections.add(section3);

			// Stores
			Section sectionStr = new Section();
			sectionStr.setDescription("");
			sectionStr.setSubtitle("Establecimientos activos");
			sectionStr.setIdSection("divTabla");
			List<Field<Value>> fieldsStr = new ArrayList<>();

			Field<Value> fileStore = new Field<>();
			fileStore.setAction(null);
			fileStore.setFormat(null);
			fileStore.setId("fileStore");
			fileStore.setLabel("");
			fileStore.setDefaultValue("");
			fileStore.setMaxLength(null);
			fileStore.setRequired("N");
			fileStore.setStatus("visible");
			fileStore.setType("");

			fieldsStr.add(fileStore);

			sectionStr.setFields(fieldsStr);

			sections.add(sectionStr);

			// Seccion Configuracion WebServices
			Section retailSection = new Section();
			retailSection.setDescription(
					"Seleccione un código de transacción para cada uno de los siguientes tipos de transacción");
			retailSection.setSubtitle("Configuraciones de WebService");
			retailSection.setIdSection("section5");
			List<Field<Value>> fields4 = new ArrayList<>();

			Field<Value> confAcu = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de acumulación"));
			confAcu.setAction(null);
			confAcu.setFormat(null);
			confAcu.setId("selAcu");
			confAcu.setLabel("Acumulación:");
			confAcu.setMessages(msg);
			confAcu.setDefaultValue(null);// pendiente
			confAcu.setMaxLength(null);
			confAcu.setRequired("Y");
			confAcu.setStatus("readonly");
			confAcu.setType("");
			fields4.add(confAcu);

			Field<Value> confRed = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de redención"));
			confRed.setMessages(msg);
			confRed.setAction(null);
			confRed.setFormat(null);
			confRed.setId("selRed");
			confRed.setLabel("Redención:");
			confRed.setDefaultValue(null);// pendiente
			confRed.setMaxLength(null);
			confRed.setRequired("Y");
			confRed.setStatus("readonly");
			confRed.setType("");
			fields4.add(confRed);

			Field<Value> confRevAcu = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de reversión de acumulación"));
			confRevAcu.setAction(null);
			confRevAcu.setFormat(null);
			confRevAcu.setId("selRevAcu");
			confRevAcu.setLabel("Reversión Acumulación:");
			confRevAcu.setMessages(msg);
			confRevAcu.setDefaultValue(null);// pendiente
			confRevAcu.setMaxLength(null);
			confRevAcu.setRequired("Y");
			confRevAcu.setStatus("readonly");
			confRevAcu.setType("");
			fields4.add(confRevAcu);

			Field<Value> confRevRed = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de reversión de acumulación"));
			confRevRed.setAction(null);
			confRevRed.setFormat(null);
			confRevRed.setId("selRevRed");
			confRevRed.setLabel("Reversión Redención:");
			confRevRed.setMessages(msg);
			confRevRed.setDefaultValue(null);// pendiente
			confRevRed.setMaxLength(null);
			confRevRed.setRequired("Y");
			confRevRed.setStatus("readonly");
			confRevRed.setType("");
			fields4.add(confRevRed);
			form.setSections(sections);

			Field<Value> confAnuAcu = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de anulación de acumulación"));
			confAnuAcu.setAction(null);
			confAnuAcu.setFormat(null);
			confAnuAcu.setId("selAnuAcu");
			confAnuAcu.setLabel("Anulación Acumulación:");
			confAnuAcu.setMessages(msg);
			confAnuAcu.setDefaultValue(null);// pendiente
			confAnuAcu.setMaxLength(null);
			confAnuAcu.setRequired("Y");
			confAnuAcu.setStatus("readonly");
			confAnuAcu.setType("");
			fields4.add(confAnuAcu);

			Field<Value> confAnuRed = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de anulación de redención"));
			confAnuRed.setAction(null);
			confAnuRed.setFormat(null);
			confAnuRed.setId("selAnuRed");
			confAnuRed.setLabel("Anulación Redención:");
			confAnuRed.setMessages(msg);
			confAnuRed.setDefaultValue(null);// pendiente
			confAnuRed.setMaxLength(null);
			confAnuRed.setRequired("Y");
			confAnuRed.setStatus("readonly");
			confAnuRed.setType("");
			fields4.add(confAnuRed);

			retailSection.setFields(fields4);
			sections.add(retailSection);

		} else if (env.getProperty("config.form-names.partner-mcv").equals(idForm)) {
			Section mcvSection = new Section();
			mcvSection.setDescription(
					"Seleccione un código de transacción para cada uno de los siguientes tipos de transacción");
			mcvSection.setSubtitle("Configuraciones de Aliados Miles Conversion");
			mcvSection.setIdSection("divCnfWsMC");
			List<Field<Value>> mvcFields = new ArrayList<>();

			Field<Value> cmbAcc = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de acumulación miles conversion"));
			cmbAcc.setAction(null);
			cmbAcc.setFormat(null);
			cmbAcc.setId("selAcuMC");
			cmbAcc.setLabel("Acumulación:");
			cmbAcc.setMessages(msg);
			cmbAcc.setMaxLength(null);
			cmbAcc.setRequired("Y");
			cmbAcc.setStatus("visible");
			cmbAcc.setType("");

			mvcFields.add(cmbAcc);

			Field<Value> cmbAccProm = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de acumulación de promoción"));
			cmbAccProm.setAction(null);
			cmbAccProm.setFormat(null);
			cmbAccProm.setId("selAcuPr");
			cmbAccProm.setLabel("Acumulación Promo:");
			cmbAccProm.setMessages(msg);
			cmbAccProm.setMaxLength(null);
			cmbAccProm.setRequired("Y");
			cmbAccProm.setStatus("visible");
			cmbAccProm.setType("");

			mvcFields.add(cmbAccProm);

			Field<Value> txtMaxAcum = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de acumulación maximo"));
			txtMaxAcum.setAction(null);
			txtMaxAcum.setFormat("^[0-9]+$");
			txtMaxAcum.setId("txtMaxAcu");
			txtMaxAcum.setLabel("Máximo a Acumular:");
			txtMaxAcum.setMessages(msg);
			txtMaxAcum.setMaxLength(null);
			txtMaxAcum.setRequired("N");
			txtMaxAcum.setStatus("visible");
			txtMaxAcum.setType("");

			mvcFields.add(txtMaxAcum);

			Field<Value> txtMaxAcumPr = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de acumulación de promoción máximo"));
			txtMaxAcumPr.setAction(null);
			txtMaxAcumPr.setFormat("^[0-9]+$");
			txtMaxAcumPr.setId("txtMaxAcuPr");
			txtMaxAcumPr.setLabel("Máximo a Acumular:");
			txtMaxAcumPr.setMaxLength(null);
			txtMaxAcumPr.setRequired("N");
			txtMaxAcumPr.setStatus("visible");
			txtMaxAcumPr.setType("");

			mvcFields.add(txtMaxAcumPr);

			Field<Value> cmbPreCom = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese un valor de precompra"));
			cmbPreCom.setAction(null);
			cmbPreCom.setFormat(null);
			cmbPreCom.setId("ddlPreCom");
			cmbPreCom.setLabel("Pre-Compra:");
			cmbPreCom.setMessages(msg);
			cmbPreCom.setMaxLength(null);
			cmbPreCom.setRequired("Y");
			cmbPreCom.setStatus("visible");
			cmbPreCom.setType("");

			mvcFields.add(cmbPreCom);

			Field<Value> lsPreCom = new Field<>();
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Ingrese al menos un valor para precompras activas"));
			lsPreCom.setAction(null);
			lsPreCom.setFormat(null);
			lsPreCom.setId("ddlPreComVal");
			lsPreCom.setLabel(null);
			lsPreCom.setMessages(msg);
			lsPreCom.setMaxLength(null);
			lsPreCom.setRequired("Y");
			lsPreCom.setStatus("visible");
			lsPreCom.setType("");

			mvcFields.add(lsPreCom);

			mcvSection.setFields(mvcFields);

			sections.add(mcvSection);
		}

		Section saveSection = new Section();
		saveSection.setDescription("");
		saveSection
				.setSubtitle("Verifique los datos cargados para el aliado y presione Guardar para que sean efectivos.");
		saveSection.setIdSection("section6");

		List<Field<Value>> fieldsSave = new ArrayList<>();

		Field<Value> fieldSaveButton = new Field<>();
		fieldSaveButton.setAction(null);
		fieldSaveButton.setFormat(null);
		fieldSaveButton.setId("btnSave");
		fieldSaveButton.setLabel("Guardar");
		fieldSaveButton.setMaxLength(0);
		fieldSaveButton.setRequired(null);
		fieldSaveButton.setStatus("visible");
		fieldSaveButton.setType("empty");

		fieldsSave.add(fieldSaveButton);

		saveSection.setFields(fieldsSave);

		sections.add(saveSection);

		form.setSections(sections);

		return form;
	}

	public Form retrieveFormStoreDetailFields(String idForm, String partner) {
		Form form = new Form();
		List<Section> sections = new ArrayList<>();
		List<Message> msg;
		Section section1 = new Section();
		section1.setDescription("");
		section1.setSubtitle("Datos generales de establecimiento");
		section1.setIdSection("section1");

		List<Field<Value>> fields = new ArrayList<>();
		// id establecimiento
		Field<Value> txtidEstablecimiento = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un ID"));
		txtidEstablecimiento.setAction(null);
		txtidEstablecimiento.setFormat(null);
		txtidEstablecimiento.setId("txtIDSuc");
		txtidEstablecimiento.setLabel("ID Establecimiento:");
		txtidEstablecimiento.setMessages(msg);
		txtidEstablecimiento.setMessages(msg);
		txtidEstablecimiento.setMaxLength(null);
		txtidEstablecimiento.setRequired("Y");
		txtidEstablecimiento.setStatus("readonly");
		txtidEstablecimiento.setType("");

		fields.add(txtidEstablecimiento);

		Field<Value> txtNombreEstablecimiento = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un nombre"));
		txtNombreEstablecimiento.setAction(null);
		txtNombreEstablecimiento.setFormat(null);
		txtNombreEstablecimiento.setId("txtNombre");
		txtNombreEstablecimiento.setLabel("Nombre:");
		txtNombreEstablecimiento.setMessages(msg);
		txtNombreEstablecimiento.setMaxLength(null);
		txtNombreEstablecimiento.setRequired("Y");
		txtNombreEstablecimiento.setStatus("visible");
		txtNombreEstablecimiento.setType("");

		fields.add(txtNombreEstablecimiento);

		Field<Value> txtTelefono = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un numero de telefono"));
		msg.add(new Message(regEx, "Ingrese un numero de telefono con un formato correcto"));
		txtTelefono.setAction(null);
		txtTelefono.setFormat("^([0-9\\(\\)\\/\\+ \\-]*)$");
		txtTelefono.setId("txtTelefono");
		txtTelefono.setLabel("Número de Teléfono:");
		txtTelefono.setMessages(msg);
		txtTelefono.setMaxLength(20); //
		txtTelefono.setRequired("Y");
		txtTelefono.setStatus("visible");
		txtTelefono.setType("");

		fields.add(txtTelefono);

		Field<Value> moneda = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una moneda válida"));
		moneda.setAction(null);
		moneda.setFormat(null);
		moneda.setId("ddlMoneda");
		moneda.setLabel("Moneda:");
		moneda.setMessages(msg);
		moneda.setMessages(msg);
		moneda.setMaxLength(null);
		moneda.setRequired("Y");
		moneda.setStatus("visible");
		moneda.setType("MoneyCmb"); // pendiente

		fields.add(moneda);

		Field<Value> estadoRadio = new Field<>();
		estadoRadio.setAction(null);
		estadoRadio.setFormat(null);
		estadoRadio.setId("pSucEstado");
		estadoRadio.setLabel("Estado:");
		estadoRadio.setMaxLength(null);
		estadoRadio.setRequired("Y");
		estadoRadio.setStatus("visible");
		estadoRadio.setType("");

		fields.add(estadoRadio);

		section1.setFields(fields);
		sections.add(section1);

		// sección de ubicación geografica

		Section section2 = new Section();
		section2.setSubtitle("Ubicación geográfica");
		section2.setIdSection("section2");

		List<Field<Value>> fields2 = new ArrayList<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un país"));
		Field<Value> pais = new Field<>();
		pais.setAction(null);
		pais.setFormat(null);
		pais.setId("ddlPais");
		pais.setLabel("País");
		pais.setMessages(msg);
		pais.setMaxLength(null);
		pais.setRequired("Y");
		pais.setStatus("visible");
		pais.setType("countryCmb");

		fields2.add(pais);

		Field<Value> estado = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un estado"));
		estado.setAction(null);
		estado.setFormat(null);
		estado.setId("ddlEstado");
		estado.setLabel("Estado:");
		estado.setMessages(msg);
		estado.setMaxLength(null);
		estado.setRequired("Y");
		estado.setStatus("visible");
		estado.setType("stateCmb");

		fields2.add(estado);

		Field<Value> ciudad = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una ciudad"));
		ciudad.setAction(null);
		ciudad.setFormat(null);
		ciudad.setId("ddlCiudad");
		ciudad.setLabel("Ciudad:");
		ciudad.setMessages(msg);
		ciudad.setMaxLength(null);
		ciudad.setRequired("Y");
		ciudad.setStatus("visible");
		ciudad.setType("cityCmb");

		fields2.add(ciudad);

		Field<Value> direccion = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una dirección"));
		direccion.setAction(null);
		direccion.setFormat(null);
		direccion.setId("txtAreaDir");
		direccion.setLabel("Dirección de establecimiento:");
		direccion.setMessages(msg);
		direccion.setMaxLength(null);
		direccion.setRequired("Y");
		direccion.setStatus("visible");
		direccion.setType("");

		fields2.add(direccion);

		Field<Value> map = new Field<>();
		map.setAction(null);
		map.setFormat(null);
		map.setId("map_canvas");
		map.setLabel("");
		map.setMaxLength(null);
		map.setRequired("Y");
		map.setStatus("visible");
		map.setType("map");

		fields2.add(map);

		Field<Value> chkUbicacion = new Field<>();
		chkUbicacion.setAction(null);
		chkUbicacion.setFormat(null);
		chkUbicacion.setId("ChbxUbicacion");
		chkUbicacion.setLabel("Confirmo que la ubicación de mi establecimiento es la correcta.");
		chkUbicacion.setMaxLength(null);
		chkUbicacion.setType("");

		fields2.add(chkUbicacion);

		Field<Value> latitud = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese la latitud"));
		msg.add(new Message(regEx, "Ingrese un formato correcto para la latitud"));
		latitud.setAction(null);
		latitud.setFormat("^-?[0-9]{1,3}(?:\\.[0-9]{1,10})?$");
		latitud.setId("txtLat");
		latitud.setLabel("Latitud");
		latitud.setMessages(msg);
		latitud.setMaxLength(null);
		latitud.setStatus("visible");
		latitud.setType("");

		fields2.add(latitud);

		Field<Value> longitud = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese la longitud"));
		msg.add(new Message(regEx, "Ingrese un formato correcto para la longitud"));
		longitud.setAction(null);
		longitud.setFormat("^-?[0-9]{1,3}(?:\\.[0-9]{1,10})?$");
		longitud.setId("txtLon");
		longitud.setLabel("Longitud");
		longitud.setMessages(msg);
		longitud.setMaxLength(null);
		longitud.setStatus("visible");
		longitud.setType("");

		fields2.add(longitud);

		section2.setFields(fields2);

		sections.add(section2);

		// if("storeDetailRetail".equals(idForm)){
		// sección de configuraciones de establecimiento

		Section section3 = new Section();
		section3.setSubtitle("Configuración de establecimiento");
		section3.setIdSection("section3");

		List<Field<Value>> fields3 = new ArrayList<>();

		Field<Value> confId = new Field<>();
		confId.setId("confId");
		confId.setRequired("Y");
		confId.setStatus("hidden");
		fields3.add(confId);

		// sender
		Field<Value> sender = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un sender"));
		sender.setAction(null);
		sender.setFormat(null);
		sender.setId("ddlSender");
		sender.setLabel("Sender:");
		sender.setMessages(msg);
		sender.setMaxLength(null);
		sender.setRequired(null);
		sender.setStatus("readonly");
		sender.setType(""); // pendiente

		fields3.add(sender);

		// billing partner
		Field<Value> billingPartner = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una factura"));
		billingPartner.setAction(null);
		billingPartner.setFormat(null);
		billingPartner.setId("ddlFactura");
		billingPartner.setLabel("Facturar a:");
		billingPartner.setMessages(msg);
		billingPartner.setMaxLength(null);
		billingPartner.setRequired(null);
		billingPartner.setStatus("readonly");
		billingPartner.setType(""); // pendiente

		fields3.add(billingPartner);

		// millas otorgadas
		Field<Value> millasOtorgadas = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un valor de millas para acumulación"));
		msg.add(new Message(regEx, "Ingrese un valor de millas valido"));
		millasOtorgadas.setAction(null);
		millasOtorgadas.setFormat("^[0-9]+(\\.)?([0-9])*$");
		millasOtorgadas.setId("txtMUsd");
		millasOtorgadas.setLabel("Millas Otorgadas por USD:");
		millasOtorgadas.setMessages(msg);
		millasOtorgadas.setMaxLength(null);
		millasOtorgadas.setRequired(null);
		millasOtorgadas.setStatus("readonly");
		millasOtorgadas.setType("");

		fields3.add(millasOtorgadas);

		// millas redimida
		Field<Value> millasRedimir = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un valor de millas para redención"));
		msg.add(new Message(regEx, "Ingrese un valor de millas valido"));
		millasRedimir.setAction(null);
		millasRedimir.setFormat("^[0-9]+(\\.)?([0-9])*$");
		millasRedimir.setId("txtVMillaR");
		millasRedimir.setLabel("Valor por Milla Redimida (COP):");
		millasRedimir.setMessages(msg);
		millasRedimir.setMaxLength(null);
		millasRedimir.setRequired(null);
		millasRedimir.setStatus("readonly");
		millasRedimir.setType("");

		fields3.add(millasRedimir);

		// minimo acumulacion
		Field<Value> minimoAcumulacion = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un valor mínimo millas para acumulación"));
		msg.add(new Message(regEx, "Ingrese un valor de millas valido"));
		minimoAcumulacion.setAction(null);
		minimoAcumulacion.setFormat("^[0-9]+(\\.)?([0-9])*$");
		minimoAcumulacion.setId("txtMontoAcu");
		minimoAcumulacion.setMessages(msg);
		minimoAcumulacion.setLabel("Monto Minimo Acumulacion:");
		minimoAcumulacion.setMaxLength(null);
		minimoAcumulacion.setStatus("readonly");
		minimoAcumulacion.setType("");

		fields3.add(minimoAcumulacion);

		// minimo redencion
		Field<Value> minimoRedencion = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un valor mínimo millas para redención"));
		msg.add(new Message(regEx, "Ingrese un valor de millas valido"));
		minimoRedencion.setAction(null);
		minimoRedencion.setFormat("^[0-9]+(\\.)?([0-9])*$");
		minimoRedencion.setId("txtMontoRed");
		minimoRedencion.setLabel("Monto Minimo Redencion (COP):");
		minimoRedencion.setMessages(msg);
		minimoRedencion.setMaxLength(null);
		minimoRedencion.setStatus("readonly");
		minimoRedencion.setType("");

		fields3.add(minimoRedencion);

		// fecha de inicio
		Field<Value> fechaInicio = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una fecha de inicio"));
		msg.add(new Message(datAc, "Por favor seleccionar una fecha mayor a la fecha actual"));
		fechaInicio.setAction(null);
		fechaInicio.setFormat("");
		fechaInicio.setId("dateFechaIni");
		fechaInicio.setLabel("Fecha Inicio:");
		fechaInicio.setMessages(msg);
		fechaInicio.setMaxLength(null);
		fechaInicio.setStatus("readonly");
		fechaInicio.setType("");

		fields3.add(fechaInicio);

		// fecha de fin

		Field<Value> fechaFin = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una fecha fin"));
		msg.add(new Message(datAc, "Por favor seleccionar una fecha mayor a la fecha actual"));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		fechaFin.setAction(null);
		fechaFin.setFormat("");
		fechaFin.setId("dateFechaFin");
		fechaFin.setLabel("Fecha Fin:");
		fechaFin.setMessages(msg);
		fechaFin.setMaxLength(null);
		fechaFin.setStatus("readonly");
		fechaFin.setType("");

		fields3.add(fechaFin);

		section3.setFields(fields3);

		sections.add(section3);
		// tabla de configuraciones

		Section section4 = new Section();
		section4.setSubtitle("Lista de configuraciones");
		section4.setIdSection("section4");
		List<Field<Value>> fields4 = new ArrayList<>();

		Field<Value> tablaConf = new Field<>();
		tablaConf.setAction(null);
		tablaConf.setFormat(null);
		tablaConf.setId("GridCnf");
		tablaConf.setLabel("");
		tablaConf.setMaxLength(null);
		tablaConf.setStatus("visible");
		tablaConf.setType(""); // pendiente de definir

		fields4.add(tablaConf);
		section4.setFields(fields4);
		sections.add(section4);

		// }
		// botón guardar

		Section section5 = new Section();
		section5.setDescription("");
		section5.setSubtitle("");
		section5.setIdSection("section5");
		List<Field<Value>> fields5 = new ArrayList<>();

		Field<Value> btnGuardar = new Field<>();
		btnGuardar.setAction(null);
		btnGuardar.setFormat(null);
		btnGuardar.setId("button");
		btnGuardar.setLabel("Guardar");
		btnGuardar.setMaxLength(null);
		btnGuardar.setStatus("visible");
		btnGuardar.setType("");

		fields5.add(btnGuardar);
		section5.setFields(fields5);
		sections.add(section5);

		form.setSections(sections);

		return form;

	}

	public Form retrieveAccPromotionForm(String user, String acumType) {				
		
		Form form = new Form();
		List<Message> messages = new ArrayList<>();
		messages.add(new Message(succ, "La solicitud ha sido creada exitosamente. Su código es: {0}"));
		messages.add(new Message(mailError, "No ha sido posible enviar el correo al aprobador <br />"
				+ "La solicitud ha sido creada. Su código es: {0}"));
		messages.add(new Message(approbers, "La solicitud no ha sido ingresada debido a falta de configuración de aprobadores"));
		form.setMessages(messages);
		if (env.getProperty("config.prom-types.accrual").equals(acumType))
			form.setTitle("Nueva Promoción de Acumulación");
		else
			form.setTitle("Nueva Promoción de Redención");
		List<Section> sections = new ArrayList<>();

		Section section1 = new Section();

		if (env.getProperty("config.prom-types.accrual").equals(acumType)) {
			section1.setDescription("Complete los campos para crear una nueva promoción de acumulación");
			// section1.setSubtitle("Datos generales de establecimiento");
			section1.setIdSection("section1");
		} else {
			section1.setDescription("Complete los campos para crear una nueva promoción de redención");
			// section1.setSubtitle("Datos generales de establecimiento");
			section1.setIdSection("section1");
		}

		List<Field<Value>> fields = new ArrayList<>();
		List<Message> msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un aliado"));
		Field<Value> cmbAliado = new Field<>();
		cmbAliado.setId("ddlComProm");
		cmbAliado.setLabel("Aliado:");
		cmbAliado.setMessages(msg);
		cmbAliado.setRequired("N");
		cmbAliado.setStatus("visible");
		fields.add(cmbAliado);

		Field<Value> btnPlus = new Field<>();
		btnPlus.setId("addCmr");

		if (env.getProperty("config.user-types.partner").equals(user)) {
			cmbAliado.setRequired("Y");
			cmbAliado.setStatus("readonly");
			btnPlus.setStatus("hidden");
		} else
			btnPlus.setStatus("visible");

		fields.add(btnPlus);

		Field<Value> cmbAliadoMulti = new Field<>();
		cmbAliadoMulti.setId("ddlCmr");
		cmbAliadoMulti.setRequired("Y");
		if (env.getProperty("config.user-types.partner").equals(user))
			cmbAliadoMulti.setStatus("hidden");
		else
			cmbAliadoMulti.setStatus("visible");
		List<Message> msgali = new ArrayList<>();
		msgali.add(new Message(reqMe, "Seleccione un aliado"));
		cmbAliadoMulti.setMessages(msgali);

		fields.add(cmbAliadoMulti);

		Field<Value> btnMinus = new Field<>();
		btnMinus.setId("remCmr");
		if (env.getProperty("config.user-types.partner").equals(user))
			btnMinus.setStatus("hidden");
		else
			btnMinus.setStatus("visible");

		fields.add(btnMinus);

		section1.setFields(fields);
		sections.add(section1);

		Section section2 = new Section();
		section2.setIdSection("section2");

		List<Field<Value>> fields2 = new ArrayList<>();

		if (userLM.equals(user)
				&& env.getProperty("config.prom-types.accrual").equals(acumType)) {

			Field<Value> cmbCCosto = new Field<>();
			cmbCCosto.setId("ddlCCosto");
			cmbCCosto.setLabel("Centro de costos:");
			cmbCCosto.setRequired("Y");
			cmbCCosto.setStatus("visible");
			List<Message> msg2 = new ArrayList<>();
			msg2.add(new Message(reqMe, "Seleccione un centro de costos"));
			cmbCCosto.setMessages(msg2);
			fields2.add(cmbCCosto);

			Field<Value> cmbTransAcu = new Field<>();
			cmbTransAcu.setId("ddlTransAcu");
			cmbTransAcu.setLabel("Trans. Acumulación:");
			cmbTransAcu.setRequired("Y");
			cmbTransAcu.setStatus("visible");
			List<Message> msg3 = new ArrayList<>();
			msg3.add(new Message(reqMe, "Seleccione un tipo de transaccion de acumulación"));
			cmbTransAcu.setMessages(msg3);
			fields2.add(cmbTransAcu);
		}

		Field<Value> cmbBonType = new Field<>();
		cmbBonType.setId("ddlTipoBono");
		cmbBonType.setRequired("Y");
		cmbBonType.setStatus("visible");
		List<Message> msg4 = new ArrayList<>();

		Field<Value> txtBono = new Field<>();
		txtBono.setId("txtBono");
		txtBono.setRequired("Y");
		txtBono.setFormat("^([0-9])+(.(([0-9])+))?$");
		txtBono.setStatus("visible");
		List<Message> msg5 = new ArrayList<>();

		if (env.getProperty("config.prom-types.accrual").equals(acumType)) {

			cmbBonType.setLabel("Tipo de Bono:");
			txtBono.setLabel("Bono:");
			msg4.add(new Message(reqMe, "Seleccione un tipo de bono"));
			cmbBonType.setMessages(msg4);
			fields2.add(cmbBonType);

			txtBono.setPlaceholder("Bono a otorgar");
			msg5.add(new Message(reqMe, "Ingrese el bono"));
			msg5.add(new Message(regEx, "Ingrese solo numeros"));
			txtBono.setMessages(msg5);
			fields2.add(txtBono);
		} else {

			cmbBonType.setLabel("Tipo de Descuento:");
			txtBono.setLabel("Descuento:");
			msg4.add(new Message(reqMe, "Seleccione un tipo de descuento"));
			cmbBonType.setMessages(msg4);
			fields2.add(cmbBonType);

			txtBono.setPlaceholder("Descuento a Otorgar");
			msg5.add(new Message(reqMe, "Ingrese el Descuento"));
			msg5.add(new Message(regEx, "Ingrese solo numeros"));
			txtBono.setMessages(msg5);
			fields2.add(txtBono);
		}

		Field<Value> txtFechadesde = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(datAc, "Por favor seleccionar una fecha mayor a la fecha actual"));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		msg.add(new Message(reqMe, "Ingrese la fecha de inicio"));
		msg.add(new Message(regEx, "Ingrese la fecha en formato dd/Mon/yyyy"));
		txtFechadesde.setId("txtFechadesde");
		txtFechadesde.setLabel("Fecha inicio solicitada:");
		txtFechadesde.setRequired("Y");
		txtFechadesde.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");
		txtFechadesde.setStatus("visible");
		// List<Message> msg6 = new ArrayList<>();
		txtFechadesde.setMessages(msg);

		fields2.add(txtFechadesde);

		Field<Value> txtFechaFin = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(datAc, "Por favor seleccionar una fecha mayor a la fecha actual"));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		msg.add(new Message(reqMe, "Ingrese la fecha fin"));
		msg.add(new Message(regEx, "Ingrese la fecha en formato dd/Mon/yyyy"));
		txtFechaFin.setId("txtFechahasta");
		txtFechaFin.setLabel("Fecha de fin:");
		txtFechaFin.setRequired("Y");
		txtFechaFin.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");
		txtFechaFin.setStatus("visible");
		// List<Message> msg7 = new ArrayList<>();
		txtFechaFin.setMessages(msg);

		fields2.add(txtFechaFin);

		Field<Value> txtHoraFin = new Field<>();
		txtHoraFin.setId("txtHoraFin");
		txtHoraFin.setLabel("Hora fin:");
		txtHoraFin.setRequired("N");
		txtHoraFin.setFormat(null); // pendiente
		txtHoraFin.setStatus("visible");
		fields2.add(txtHoraFin);
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese la hora fin"));
		msg.add(new Message(regEx, "Ingrese la hora en formato hh:mm a.m."));
		msg.add(new Message("horIn", "La hora fin es menor que la hora de Inicio"));
		txtHoraFin.setMessages(msg);

		Field<Value> txtHoraIni = new Field<>();
		txtHoraIni.setId("txtHoraIni");
		txtHoraIni.setLabel("Hora de inicio:");
		txtHoraIni.setRequired("N");
		txtHoraIni.setFormat(null); // pendiente
		txtHoraIni.setStatus("visible");
		List<Message> msg9 = new ArrayList<>();
		msg9.add(new Message(reqMe, "Ingrese la hora de inicio"));
		msg9.add(new Message(regEx, "Ingrese la hora en formato hh:mm a.m."));
		txtHoraIni.setMessages(msg9);
		fields2.add(txtHoraIni);

		Field<Value> txtDesc = new Field<>();
		txtDesc.setId("areaDescripPromo");
		txtDesc.setLabel("Descripción:");
		txtDesc.setRequired("N");
		txtDesc.setFormat(null); // pendiente
		txtDesc.setStatus("visible");
		txtDesc.setMaxLength(150);
		fields2.add(txtDesc);

		Field<Value> notaHorario = new Field<>();
		notaHorario.setId("notaHorario");
		notaHorario.setLabel("+ Los horarios deben ser establecidos en GMT-6");
		notaHorario.setStatus("visible");
		fields2.add(notaHorario);

		Field<Value> recurrencia = new Field<>();
		recurrencia.setId("weekdays");
		recurrencia.setRequired("N");
		recurrencia.setLabel("Recurrencia:");
		recurrencia.setStatus("visible");
		fields2.add(recurrencia);

		Field<Value> notaRecu = new Field<>();
		notaRecu.setId("notaRecu");
		notaRecu.setLabel("+ Puedes seleccionar los días en los que aplica la promoción");
		notaRecu.setStatus("visible");
		fields2.add(notaRecu);

		Field<Value> estado = new Field<>();
		estado.setId("estado");
		estado.setDefaultValue("A");
		estado.setRequired("Y");
		estado.setLabel("Estado");
		estado.setStatus("visible");
		fields2.add(estado);

		Field<Value> cbxMontoMin = new Field<>();
		cbxMontoMin.setId("cbxMontoMin");
		cbxMontoMin.setRequired("N");
		cbxMontoMin.setLabel("Aplica Monto Mínimo");
		cbxMontoMin.setStatus("visible");
		fields2.add(cbxMontoMin);

		Field<Value> txtMontoMin = new Field<>();
		List<Message> msgMonto = new ArrayList<>();
		msgMonto.add(new Message(reqMe, "Ingrese el monto mínimo"));
		msgMonto.add(new Message(regEx, "Ingrese solo numeros"));
		txtMontoMin.setMessages(msgMonto);
		txtMontoMin.setId("txtMontoMin");
		txtMontoMin.setFormat("^([0-9])+$");
		txtMontoMin.setRequired("N");
		txtMontoMin.setLabel("Monto Mínimo:");
		txtMontoMin.setPlaceholder("Monto minimo para aplicar la promocion (Moneda local)");
		msg5.add(new Message(reqMe, "Ingrese el bono"));
		msg5.add(new Message(regEx, "Ingrese solo numeros"));
		txtMontoMin.setStatus("hidden"); // para la opcion de modificar, ponerlo
											// visible. en el int de modificar
		fields2.add(txtMontoMin);

		section2.setFields(fields2);
		sections.add(section2);

		Section section3 = new Section();
		section3.setDescription(
				"Si esta promocion aplicará para todos los establecimientos no active la opción de <i>Segmentación por establecimientos</i>.");
		section3.setIdSection("section3");

		List<Field<Value>> fields3 = new ArrayList<>();

		Field<Value> cbxSuc = new Field<>();
		cbxSuc.setId("cbxSuc");
		cbxSuc.setLabel("Segmentación por establecimientos");
		cbxSuc.setRequired("N");
		cbxSuc.setStatus("visible");
		fields3.add(cbxSuc);

		Field<Value> lblEstable = new Field<>();
		lblEstable.setId("lblEstable");
		lblEstable.setLabel(
				"Para agregar los establecimientos a los cuales aplica la promoción, presione <i>Adjuntar</i> y seleccione el archivo de Excel con la  <a id='ClbSuc' class='Colorbox cboxElement' href='#divClbSuc'>estructura definida</a>.  <a href='Filestmp/Layout_Establecimientos.xls' target='_blank'>Descargar Layout </a>");
		lblEstable.setStatus("hidden");
		fields3.add(lblEstable);

		Field<Value> fileSuc = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar un archivo excel"));
		msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
		fileSuc.setMessages(msg);
		fileSuc.setId("FileSuc");
		fileSuc.setLabel("Adjuntar...");
		fileSuc.setDefaultValue("No ha seleccionado ningún archivo");
		fileSuc.setRequired("N");
		fileSuc.setStatus("hidden");
		fields3.add(fileSuc);

		section3.setFields(fields3);
		sections.add(section3);

		Section section4 = new Section();
		section4.setDescription(
				"Si esta promocion aplicará para todos los clientes no active la opción de <i>Segmentación por clientes</i>.");
		section4.setIdSection("section4");

		List<Field<Value>> fields4 = new ArrayList<>();

		Field<Value> cbxCli = new Field<>();
		cbxCli.setId("cbxCli");
		cbxCli.setLabel("Segmentación por clientes");
		cbxCli.setRequired("N");
		cbxCli.setStatus("visible");
		fields4.add(cbxCli);

		Field<Value> notaSegCli = new Field<>();
		notaSegCli.setId("notaSegCli");
		notaSegCli.setLabel(
				"Puedes seleccionar una de las segmentaciones predefinidas; en caso contrario, puedes segmentar por archivo de Excel.");
		notaSegCli.setStatus("hidden");
		fields4.add(notaSegCli);

		Field<Value> titSegPre = new Field<>();
		titSegPre.setId("titSegPre");
		titSegPre.setLabel("Segmentación predefinida");
		titSegPre.setStatus("hidden");
		fields4.add(titSegPre);

		Field<Value> cmbSeg = new Field<>();
		cmbSeg.setId("ddlTiposSeg");
		cmbSeg.setLabel("Segmentaciones:");
		cmbSeg.setRequired("N");
		cmbSeg.setStatus("hidden");
		fields4.add(cmbSeg);

		Field<Value> titSegArch = new Field<>();
		titSegArch.setId("titSegArch");
		titSegArch.setLabel("Segmentación por archivo");
		titSegArch.setStatus("hidden");
		fields4.add(titSegArch);

		Field<Value> notaSegArch = new Field<>();
		notaSegArch.setId("notaSegArch");
		notaSegArch.setLabel(
				"Para agregar el listado de clientes a los cuales aplica la promoción, presione <i>Adjuntar</i> y seleccione el archivo de Excel con la <a id='ClbCliente' class='Colorbox cboxElement' href='#divClbCliente'>estructura definida </a>. <a href='Filestmp/Layout_Clientes.xls' target='_blank'>Descargar Layout</a>");
		notaSegArch.setStatus("hidden");
		fields4.add(notaSegArch);

		Field<Value> fileClientes = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar un archivo excel"));
		msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
		fileClientes.setMessages(msg);
		fileClientes.setId("fileClientes");
		fileClientes.setLabel("Adjuntar...");
		fileClientes.setDefaultValue("No ha seleccionado ningún archivo");
		fileClientes.setRequired("N");
		fileClientes.setStatus("hidden");
		fields4.add(fileClientes);

		section4.setFields(fields4);
		sections.add(section4);

		Section section5 = new Section();
		section5.setDescription(
				"Promociones vigentes con 15 días de anterioridad y 15 días posteriores a las fechas seleccionadas");
		section5.setIdSection("section5");
		section5.setSubtitle("Otras promociones vigentes");

		List<Field<Value>> fields5 = new ArrayList<>();

		Field<Value> tbPromo = new Field<>();
		tbPromo.setId("gantt");
		tbPromo.setLabel("No hay promociones vigentes");
		tbPromo.setStatus("visible");
		fields5.add(tbPromo);

		section5.setFields(fields5);
		sections.add(section5);

		Section section6 = new Section();
		section6.setDescription("Verifique los datos y presione <i>Guardar</i> para que sean efectivos");
		section6.setIdSection("section6");

		List<Field<Value>> fields6 = new ArrayList<>();

		Field<Value> btnGuardar = new Field<>();
		btnGuardar.setId("btnSave");
		btnGuardar.setLabel("Guardar");
		btnGuardar.setStatus("visible");
		fields6.add(btnGuardar);

		section6.setFields(fields6);
		sections.add(section6);

		form.setSections(sections);

		return form;
	}

	// HISTORIAL DE PROMOCIONES
	public Form retrieveHistoryForm(String user) {

		Form form = new Form();
		form.setTitle("Historial de promociones");
		List<Section> sections = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");

		List<Field<Value>> fields = new ArrayList<>();
		// List<Message> msg = new ArrayList<>();

		Field<Value> tablaHist = new Field<>();
		tablaHist.setAction(null);
		tablaHist.setFormat(null);
		tablaHist.setId("promHist");
		tablaHist.setLabel("");
		tablaHist.setMaxLength(null);
		tablaHist.setType("");
		tablaHist.setStatus("visible");

		fields.add(tablaHist);
		section1.setFields(fields);
		sections.add(section1);

		form.setSections(sections);

		return form;
	}

	public Form retrieveInfoPromotionForm(String user, String acumType) {
		Form form = new Form();
		List<Message> msg = new ArrayList<>();		
		msg.add(new Message(succ, "La solicitud ha sido creada exitosamente. Su código es: {0}"));
		msg.add(new Message(mailError, "No ha sido posible enviar el correo al aprobador <br />"
				+ "La solicitud ha sido creada. Su código es: {0}"));
		msg.add(new Message(approbers, "La solicitud no ha sido ingresada debido a falta de configuración de aprobadores"));
		form.setMessages(msg);
		if (env.getProperty("config.prom-types.accrual").equals(acumType)) {
			form.setTitle("Información de promoción de acumulación aprobada");
		} else
			form.setTitle("Información de promoción de redención aprobada");

		List<Section> sections = new ArrayList<>();
		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setDescription("Complete los campos para actualizar la información de promoción");

		List<Field<Value>> fields1 = new ArrayList<>();
		Field<Value> codigo = new Field<>();
		codigo.setLabel("Código");
		codigo.setId("txtCodigo");
		codigo.setStatus("readonly");
		codigo.setRequired("Y");
		codigo.setPlaceholder("Código de la promoción");
		fields1.add(codigo);

		// campos copiados del formulario de agregar

		if (userLM.equals(user)
				&& env.getProperty("config.prom-types.accrual").equals(acumType)) {

			Field<Value> cmbCCosto = new Field<>();
			cmbCCosto.setId("ddlCCosto");
			cmbCCosto.setLabel("Centro de costos:");
			cmbCCosto.setRequired("Y");
			cmbCCosto.setStatus("visible");
			List<Message> msg2 = new ArrayList<>();
			msg2.add(new Message(reqMe, "Seleccione un centro de costos"));
			cmbCCosto.setMessages(msg2);
			fields1.add(cmbCCosto);

			Field<Value> cmbTransAcu = new Field<>();
			cmbTransAcu.setId("ddlTransAcu");
			cmbTransAcu.setLabel("Trans. Acumulación:");
			cmbTransAcu.setRequired("Y");
			cmbTransAcu.setStatus("visible");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione un tipo de transaccion de acumulación"));
			cmbTransAcu.setMessages(msg);
			fields1.add(cmbTransAcu);
		}

		Field<Value> cmbBonType = new Field<>();
		cmbBonType.setId("ddlTipoBono");
		cmbBonType.setRequired("Y");
		cmbBonType.setStatus("visible");
		List<Message> msg4 = new ArrayList<>();

		Field<Value> txtBono = new Field<>();
		txtBono.setId("txtBono");
		txtBono.setLabel("Bono:");
		txtBono.setRequired("Y");
		txtBono.setFormat("^([0-9])+(.(([0-9])+))?$");
		txtBono.setStatus("visible");
		List<Message> msg5 = new ArrayList<>();

		if (env.getProperty("config.prom-types.accrual").equals(acumType)) {

			cmbBonType.setLabel("Tipo de Bono:");
			msg4.add(new Message(reqMe, "Seleccione un tipo de bono"));
			cmbBonType.setMessages(msg4);
			fields1.add(cmbBonType);

			txtBono.setPlaceholder("Bono a otorgar");
			msg5.add(new Message(reqMe, "Ingrese el bono"));
			msg5.add(new Message(regEx, "Ingrese solo numeros"));
			txtBono.setMessages(msg5);
			fields1.add(txtBono);
		} else {

			cmbBonType.setLabel("Tipo de Descuento:");
			msg4.add(new Message(reqMe, "Seleccione un tipo de Descuento"));
			cmbBonType.setMessages(msg4);
			fields1.add(cmbBonType);

			txtBono.setPlaceholder("Descuento a Otorgar");
			msg5.add(new Message(reqMe, "Ingrese el Descuento"));
			msg5.add(new Message(regEx, "Ingrese solo numeros"));
			txtBono.setMessages(msg5);
			fields1.add(txtBono);
		}

		Field<Value> txtFechadesde = new Field<>();
		txtFechadesde.setId("txtFechadesde");
		txtFechadesde.setLabel("Fecha inicio solicitada:");
		txtFechadesde.setRequired("Y");
		txtFechadesde.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");
		txtFechadesde.setStatus("visible");
		List<Message> msg6 = new ArrayList<>();
		msg6.add(new Message(reqMe, "Ingrese la fecha de inicio"));
		msg6.add(new Message(regEx, "Ingrese la fecha en formato dd/Mon/yyyy"));
		msg6.add(new Message(datAc, "Por favor seleccionar una fecha mayor a la fecha actual"));
		msg6.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		txtFechadesde.setMessages(msg6);

		fields1.add(txtFechadesde);

		Field<Value> txtFechaFin = new Field<>();
		txtFechaFin.setId("txtFechahasta");
		txtFechaFin.setLabel("Fecha de fin:");
		txtFechaFin.setRequired("Y");
		txtFechaFin.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");
		txtFechaFin.setStatus("visible");
		List<Message> msg7 = new ArrayList<>();
		msg7.add(new Message(reqMe, "Ingrese la fecha fin"));
		msg7.add(new Message(regEx, "Ingrese la fecha en formato dd/Mon/yyyy"));
		msg7.add(new Message(datAc, "Por favor seleccionar una fecha mayor a la fecha actual"));
		msg7.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		txtFechaFin.setMessages(msg7);

		fields1.add(txtFechaFin);

		Field<Value> txtHoraFin = new Field<>();
		txtHoraFin.setId("txtHoraFin");
		txtHoraFin.setLabel("Hora fin:");
		txtHoraFin.setRequired("N");
		txtHoraFin.setFormat(null); // pendiente
		txtHoraFin.setStatus("visible");
		fields1.add(txtHoraFin);
		List<Message> msg8 = new ArrayList<>();
		msg8.add(new Message(reqMe, "Ingrese la hora fin"));
		msg8.add(new Message(regEx, "Ingrese la hora en formato hh:mm a.m."));
		txtHoraFin.setMessages(msg8);

		Field<Value> txtHoraIni = new Field<>();
		txtHoraIni.setId("txtHoraIni");
		txtHoraIni.setLabel("Hora de inicio:");
		txtHoraIni.setRequired("N");
		txtHoraIni.setFormat(null); // pendiente
		txtHoraIni.setStatus("visible");
		List<Message> msg9 = new ArrayList<>();
		msg9.add(new Message(reqMe, "Ingrese la hora de inicio"));
		msg9.add(new Message(regEx, "Ingrese la hora en formato hh:mm a.m."));
		txtHoraIni.setMessages(msg9);
		fields1.add(txtHoraIni);

		Field<Value> txtDesc = new Field<>();
		txtDesc.setId("areaDescripPromo");
		txtDesc.setLabel("Descripción:");
		txtDesc.setRequired("N");
		txtDesc.setFormat(null); // pendiente
		txtDesc.setStatus("visible");
		txtDesc.setMaxLength(150);
		fields1.add(txtDesc);

		Field<Value> notaHorario = new Field<>();
		notaHorario.setId("notaHorario");
		notaHorario.setLabel("+ Los horarios deben ser establecidos en GMT-6");
		notaHorario.setStatus("visible");
		fields1.add(notaHorario);

		Field<Value> recurrencia = new Field<>();
		recurrencia.setId("weekdays");
		recurrencia.setRequired("N");
		recurrencia.setLabel("Recurrencia:");
		recurrencia.setStatus("visible");
		fields1.add(recurrencia);

		Field<Value> notaRecu = new Field<>();
		notaRecu.setId("notaRecu");
		notaRecu.setLabel("+ Puedes seleccionar los días en los que aplica la promoción");
		notaRecu.setStatus("visible");
		fields1.add(notaRecu);

		Field<Value> estado = new Field<>();
		estado.setId("estado");
		estado.setRequired("Y");
		estado.setLabel("Estado");
		estado.setStatus("visible");
		fields1.add(estado);

		section1.setFields(fields1);
		sections.add(section1);

		// area aplica monto minimo
		Section section2 = new Section();
		section2.setIdSection("section2");
		List<Field<Value>> fields2 = new ArrayList<>();

		Field<Value> cbxMontoMin = new Field<>();
		cbxMontoMin.setId("cbxMontoMin");
		cbxMontoMin.setRequired("N");
		cbxMontoMin.setLabel("Aplica Monto Mínimo");
		cbxMontoMin.setStatus("visible");
		fields2.add(cbxMontoMin);

		Field<Value> txtMontoMin = new Field<>();
		List<Message> msgMonto = new ArrayList<>();
		msgMonto.add(new Message(reqMe, "Ingrese el monto mínimo"));
		msgMonto.add(new Message(regEx, "Ingrese solo numeros"));
		txtMontoMin.setMessages(msgMonto);
		txtMontoMin.setId("txtMontoMin");
		txtMontoMin.setFormat("^([0-9])+$");
		txtMontoMin.setRequired("N");
		txtMontoMin.setLabel("Monto Mínimo:");
		txtMontoMin.setPlaceholder("Monto minimo para aplicar la promocion (Moneda local)");
		msg5.add(new Message(reqMe, "Ingrese el bono"));
		msg5.add(new Message(regEx, "Ingrese solo numeros"));
		txtMontoMin.setStatus("hidden"); // para la opcion de modificar, ponerlo
											// visible. en el int de modificar
		fields2.add(txtMontoMin);

		section2.setFields(fields2);
		sections.add(section2);

		Section section3 = new Section();
		section3.setDescription(
				"Si esta promocion aplicará para todos los establecimientos no active la opción de <i>Segmentación por establecimientos</i>.");
		section3.setIdSection("section3");

		List<Field<Value>> fields3 = new ArrayList<>();

		Field<Value> cbxSuc = new Field<>();
		cbxSuc.setId("cbxSuc");
		cbxSuc.setLabel("Segmentación por establecimientos");
		cbxSuc.setRequired("N");
		cbxSuc.setStatus("visible");
		fields3.add(cbxSuc);

		Field<Value> lblEstable = new Field<>();
		lblEstable.setId("lblEstable");
		lblEstable.setLabel(
				"Para agregar los establecimientos a los cuales aplica la promoción, presione <i>Adjuntar</i> y seleccione el archivo de Excel con la  <a id='ClbSuc' class='Colorbox cboxElement' href='#divClbSuc'>estructura definida</a>.  <a href='Filestmp/Layout_Establecimientos.xls' target='_blank'>Descargar Layout </a>");
		lblEstable.setStatus("hidden");
		fields3.add(lblEstable);

		Field<Value> fileSuc = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar un archivo excel"));
		msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
		fileSuc.setMessages(msg);
		fileSuc.setId("FileSuc");
		fileSuc.setLabel("Adjuntar...");
		fileSuc.setDefaultValue("No ha seleccionado ningún archivo");
		fileSuc.setRequired("N");
		fileSuc.setStatus("hidden");
		fields3.add(fileSuc);

		section3.setFields(fields3);
		sections.add(section3);

		Section section4 = new Section();
		section4.setDescription(
				"Si esta promocion aplicará para todos los clientes no active la opción de <i>Segmentación por clientes</i>.");
		section4.setIdSection("section4");

		List<Field<Value>> fields4 = new ArrayList<>();

		Field<Value> cbxCli = new Field<>();
		cbxCli.setId("cbxCli");
		cbxCli.setLabel("Segmentación por clientes");
		cbxCli.setRequired("N");
		cbxCli.setStatus("visible");
		fields4.add(cbxCli);

		Field<Value> notaSegCli = new Field<>();
		notaSegCli.setId("notaSegCli");
		notaSegCli.setLabel(
				"Puedes seleccionar una de las segmentaciones predefinidas; en caso contrario, puedes segmentar por archivo de Excel.");
		notaSegCli.setStatus("hidden");
		fields4.add(notaSegCli);

		Field<Value> titSegPre = new Field<>();
		titSegPre.setId("titSegPre");
		titSegPre.setLabel("Segmentación predefinida");
		titSegPre.setStatus("hidden");
		fields4.add(titSegPre);

		Field<Value> cmbSeg = new Field<>();
		cmbSeg.setId("ddlTiposSeg");
		cmbSeg.setLabel("Segmentaciones:");
		cmbSeg.setRequired("N");
		cmbSeg.setStatus("hidden");
		fields4.add(cmbSeg);

		Field<Value> titSegArch = new Field<>();
		titSegArch.setId("titSegArch");
		titSegArch.setLabel("Segmentación por archivo");
		titSegArch.setStatus("hidden");
		fields4.add(titSegArch);

		Field<Value> notaSegArch = new Field<>();
		notaSegArch.setId("notaSegArch");
		notaSegArch.setLabel(
				"Para agregar el listado de clientes a los cuales aplica la promoción, presione <i>Adjuntar</i> y seleccione el archivo de Excel con la <a id='ClbCliente' class='Colorbox cboxElement' href='#divClbCliente'>estructura definida </a>. <a href='Filestmp/Layout_Clientes.xls' target='_blank'>Descargar Layout</a>");
		notaSegArch.setStatus("hidden");
		fields4.add(notaSegArch);

		Field<Value> fileClientes = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar un archivo excel"));
		msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
		fileClientes.setMessages(msg);
		fileClientes.setId("fileClientes");
		fileClientes.setLabel("Adjuntar...");
		fileClientes.setDefaultValue("No ha seleccionado ningún archivo");
		fileClientes.setRequired("N");
		fileClientes.setStatus("hidden");
		fields4.add(fileClientes);

		section4.setFields(fields4);
		sections.add(section4);

		Section section5 = new Section();
		section5.setDescription(
				"Promociones vigentes con 15 días de anterioridad y 15 días posteriores a las fechas seleccionadas");
		section5.setIdSection("section5");
		section5.setSubtitle("Otras promociones vigentes");

		List<Field<Value>> fields5 = new ArrayList<>();

		Field<Value> tbPromo = new Field<>();
		tbPromo.setId("gantt");
		tbPromo.setLabel("No hay promociones vigentes");
		tbPromo.setStatus("visible");
		fields5.add(tbPromo);

		section5.setFields(fields5);
		sections.add(section5);

		Section section6 = new Section();
		section6.setDescription("Verifique los datos y presione <i>Guardar</i> para que sean efectivos");
		section6.setIdSection("section6");

		List<Field<Value>> fields6 = new ArrayList<>();

		Field<Value> btnGuardar = new Field<>();
		btnGuardar.setId("btnSave");
		btnGuardar.setLabel("Guardar");
		btnGuardar.setStatus("visible");
		fields6.add(btnGuardar);

		section6.setFields(fields6);
		sections.add(section6);

		form.setSections(sections);

		return form;
	}

	public Form retrieveAddMemberForm() {
		Form form = new Form();
		form.setTitle("Agregar Socio");
		List<Section> sections = new ArrayList<>();
		List<Message> messageForm = new ArrayList<>();
		messageForm.add(new Message(errMe, "El aliado ya existe en la base de datos"));
		form.setMessages(messageForm);
		Section section1 = new Section();
		section1.setDescription("Completar la siguiente <i>Información</i>");
		section1.setIdSection("section1");
		List<Field<Value>> fields1 = new ArrayList<>();
		Field<Value> firstName = new Field<>();

		firstName.setId("txtPrimerNom");
		firstName.setLabel("Primer Nombre:");
		firstName.setStatus("visible");
		firstName.setRequired("Y");
		firstName.setPlaceholder("Primer Nombre");
		firstName.setMaxLength(50);
		firstName.setFormat("^[a-zA-Záéíóúñ ]*$");// pendiente
		List<Message> firstNameMessage = new ArrayList<>();
		firstNameMessage.add(new Message(reqMe, "Ingrese el primer Nombre"));
		firstNameMessage.add(new Message(regEx, "Ingrese un nombre válido"));
		firstName.setMessages(firstNameMessage);
		fields1.add(firstName);

		Field<Value> lastName = new Field<>();
		lastName.setId("txtPrimerApe");
		lastName.setLabel("Primer Apellido:");
		lastName.setStatus("visible");
		lastName.setRequired("Y");
		lastName.setPlaceholder("Primer Apellido");
		lastName.setMaxLength(50);
		lastName.setFormat("^[a-zA-Záéíóúñ ]*$");// pendiente
		List<Message> lastNameMessage = new ArrayList<>();
		lastNameMessage.add(new Message(reqMe, "Ingrese el primer Apellido"));
		lastNameMessage.add(new Message(regEx, "Ingrese un apellido válido"));
		lastName.setMessages(lastNameMessage);
		fields1.add(lastName);

		Field<Value> birthDate = new Field<>();
		birthDate.setId("txtBirthDate");
		birthDate.setLabel("Fecha de Nacimiento:");
		birthDate.setStatus("visible");
		birthDate.setRequired("Y");
		birthDate.setPlaceholder("Fecha de Nacimiento");
		birthDate.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");// pendiente
		List<Message> birthDateMessage = new ArrayList<>();
		birthDateMessage.add(new Message(reqMe, "Ingrese la Fecha de Nacimiento del socio"));
		birthDateMessage.add(new Message(regEx, "Ingrese la fecha en formato dd/Mon/yyyy"));
		birthDate.setMessages(birthDateMessage);
		fields1.add(birthDate);

		Field<Value> cmbBirthCou = new Field<>();
		cmbBirthCou.setId("ddlNationality");
		cmbBirthCou.setLabel("País de Nacimiento:");
		cmbBirthCou.setStatus("visible");
		cmbBirthCou.setRequired("Y");
		List<Message> message = new ArrayList<>();
		message.add(new Message(reqMe, "Ingrese el país de Nacimiento del socio"));
		cmbBirthCou.setMessages(message);
		fields1.add(cmbBirthCou);
		
		Field<Value> docType = new Field<>();
		docType.setId("ddlTipoDoc");
		docType.setLabel("Tipo de Documento:");
		docType.setStatus("visible");
		docType.setRequired("Y");
		docType.setPlaceholder("Tipo de Documento");
		docType.setFormat(null);// pendiente
		List<Message> docTypeMessage = new ArrayList<>();
		docTypeMessage.add(new Message(reqMe, "Seleccione un tipo de documento"));
		docType.setMessages(docTypeMessage);
		fields1.add(docType);

		Field<Value> docNumber = new Field<>();
		docNumber.setId("txtNumDoc");
		docNumber.setLabel("Numero Documento:");
		docNumber.setStatus("visible");
		docNumber.setRequired("Y");
		docNumber.setPlaceholder("Número de Documento");
		docNumber.setFormat("^[a-zA-Z0-9-áéíóúñ ]*$");// pendiente
		List<Message> docNumberMessage = new ArrayList<>();
		docNumberMessage.add(new Message(reqMe, "Ingrese el número de documento"));
		docNumberMessage.add(new Message(regEx, "Ingrese solo caracteres alfabeticos"));
		docNumber.setMessages(docNumberMessage);
		fields1.add(docNumber);

		Field<Value> docCountry = new Field<>();
		docCountry.setId("ddlPaisDoc");
		docCountry.setLabel("País de Emisión:");
		docCountry.setStatus("visible");
		docCountry.setRequired("Y");
		docCountry.setPlaceholder("País de Emisión");
		docCountry.setFormat(null);// pendiente
		List<Message> docCountryMessage = new ArrayList<>();
		docCountryMessage.add(new Message(reqMe, "Seleccione un páis de emisión"));
		docCountry.setMessages(docCountryMessage);
		fields1.add(docCountry);

		Field<Value> email = new Field<>();
		List<Message> emailMessages = new ArrayList<>();
		emailMessages.add(new Message(reqMe, "Ingrese una dirección de correo correcta"));
		emailMessages.add(new Message(regEx, "Ingrese una dirección de correo correcta"));
		email.setAction(null);
		email.setFormat("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)+$");
		email.setId("txtEmailMember");
		email.setLabel("Email:");
		email.setPlaceholder("Correo Electrónico");
		email.setMessages(emailMessages);
		email.setMaxLength(40);
		email.setRequired("Y");
		email.setStatus("visible");
		email.setType("empty");
		fields1.add(email);

		Field<Value> confirmEmail = new Field<>();
		List<Message> confirmEmailMessages = new ArrayList<>();
		confirmEmailMessages.add(new Message(reqMe, "Los correos Electrónicos deben coincidir"));
		confirmEmailMessages.add(new Message(regEx, "Ingrese una dirección de correo correcta"));
		confirmEmailMessages.add(new Message("conEm", "Favor verificar que los campos de correo coincidan"));
		confirmEmail.setAction(null);
		confirmEmail.setFormat("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)+$");
		confirmEmail.setId("txtConfEmail");
		confirmEmail.setLabel("Confirmar Email:");
		confirmEmail.setPlaceholder("Confirmar Correo Electrónico");
		confirmEmail.setMessages(confirmEmailMessages);
		confirmEmail.setMaxLength(40);
		confirmEmail.setRequired("Y");
		confirmEmail.setStatus("visible");
		confirmEmail.setType("empty");
		fields1.add(confirmEmail);

		section1.setFields(fields1);
		sections.add(section1);

		Section section2 = new Section();
		section2.setIdSection("section2");
		List<Field<Value>> fields2 = new ArrayList<>();
		section2.setDescription(
				"Verifique los datos cargados para el Socio y presione <i>Afiliar</i> para que sean efectivos.");

		Field<Value> btnAfiliar = new Field<>();
		btnAfiliar.setId("btnSaveInfo");
		btnAfiliar.setLabel("Afiliar");
		btnAfiliar.setStatus("visible");
		fields2.add(btnAfiliar);
		section2.setFields(fields2);
		sections.add(section2);
		form.setSections(sections);

		return form;

	}

	public Form retrieveAccMcv() {
		List<Message> msg = new ArrayList<>();
		Form form = new Form();
		form.setTitle("Acumulación de millas");

		msg.add(new Message(succ,
				"Transacción procesada con éxito, se acumularon {0} LifeMiles a la cuenta {1}.<br>El número de autorizacion de la transacción es: {2} "));
		form.setMessages(msg);
		List<Section> sections = new ArrayList<>();
		Section section1 = new Section();
		section1.setIdSection("section1");
		List<Field<Value>> fields1 = new ArrayList<>();
		Field<Value> cmbAliado = new Field<>();
		cmbAliado.setId("ddlAliado");
		cmbAliado.setLabel("Aliado:");
		cmbAliado.setStatus("visible");
		cmbAliado.setRequired("Y");
		fields1.add(cmbAliado);
		section1.setFields(fields1);
		sections.add(section1);

		Section section2 = new Section();
		section2.setDescription("Complete la siguiente <i>Información</i>");
		section2.setIdSection("section2");
		List<Field<Value>> fields2 = new ArrayList<>();
		Field<Value> txtCuenta = new Field<>();
		txtCuenta.setId("txtMun");
		txtCuenta.setLabel("Cuenta a Abonar:");
		txtCuenta.setStatus("readonly");
		txtCuenta.setRequired("Y");
		txtCuenta.setPlaceholder("Cuenta a Abonar");
		txtCuenta.setFormat("^[0-9]*$");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe existir una cuenta"));
		msg.add(new Message(regEx, "Ingrese un valor de cuenta válido"));
		txtCuenta.setMessages(msg);
		fields2.add(txtCuenta);

		Field<Value> txtNombre = new Field<>();
		txtNombre.setId("txtNombreAccMcv");
		txtNombre.setLabel("Nombre de la cuenta:");
		txtNombre.setStatus("readonly");
		txtNombre.setRequired("Y");
		txtNombre.setPlaceholder("Nombre Completo");
		txtNombre.setFormat("^[a-zA-Záéíóúñ ]*$");// pendiente
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese el nombre de la cuenta"));
		msg.add(new Message(regEx, "Ingrese un nombre válido"));
		txtNombre.setMessages(msg);
		fields2.add(txtNombre);

		Field<Value> txtNumCert = new Field<>();
		txtNumCert.setId("txtNumCerti");
		txtNumCert.setLabel("Número de Certificado:");
		txtNumCert.setStatus("visible");
		txtNumCert.setRequired("Y");
		txtNumCert.setPlaceholder("Número de Certificado");
		txtNumCert.setFormat("^[a-zA-Z0-9]*$");// pendiente
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un número de certificado"));
		msg.add(new Message(regEx, "Ingrese solo números"));
		txtNumCert.setMessages(msg);
		fields2.add(txtNumCert);

		Field<Value> txtMillas = new Field<>();
		txtMillas.setId("txtCantidad");
		txtMillas.setLabel("Cantidad de millas:");
		txtMillas.setStatus("visible");
		txtMillas.setRequired("Y");
		txtMillas.setPlaceholder("Cantidad de millas");
		txtMillas.setMaxLength(50);
		txtMillas.setFormat("^(([0-9]{1,3},)+[0-9]{3})$|^([0-9])*$");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una cantidad de millas"));
		msg.add(new Message(regEx, "Ingrese el formato correcto. Ej: 1000 ó 1,000"));
		txtMillas.setMessages(msg);
		fields2.add(txtMillas);

		Field<Value> cmbpointType = new Field<>();
		cmbpointType.setId("ddlTipoTra");
		cmbpointType.setLabel("Tipo de Transacción:");
		cmbpointType.setStatus("visible");
		cmbpointType.setRequired("Y");
		cmbpointType.setPlaceholder("Point type");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Seleccione un point type"));
		msg.add(new Message(regEx, "Ingrese solo números"));
		cmbpointType.setMessages(msg);
		fields2.add(cmbpointType);

		Field<Value> cmbBonType = new Field<>();
		cmbBonType.setId("ddlBono");
		cmbBonType.setLabel("Tipo de bono:");
		cmbBonType.setStatus("hidden");
		cmbBonType.setRequired("N");
		cmbBonType.setPlaceholder("tipo de bono");
		fields2.add(cmbBonType);

		Field<Value> txtEmail = new Field<>();

		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una dirección de correo"));
		msg.add(new Message(regEx, "Ingrese una dirección de correo correcta"));
		txtEmail.setMessages(msg);
		txtEmail.setId("txtEmailAccMcv");
		txtEmail.setLabel("Email:");
		txtEmail.setStatus("readonly"); // cambiara en base a lo que se
										// seleccione luego
		txtEmail.setRequired("N");
		txtEmail.setFormat("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)+$");
		txtEmail.setPlaceholder("Correo Electrónico");
		fields2.add(txtEmail);

		Field<Value> cmbBonTypeVal = new Field<>();
		cmbBonTypeVal.setId("ddlBonoVal");
		cmbBonTypeVal.setStatus("hidden");
		cmbBonTypeVal.setRequired("N");
		fields2.add(cmbBonTypeVal);

		Field<Value> rbNotif = new Field<>();
		rbNotif.setId("rdNotiEmail");
		rbNotif.setStatus("visible");
		rbNotif.setRequired("Y");
		fields2.add(rbNotif);

		Field<Value> lblEnca = new Field<>();
		lblEnca.setId("lblEnca");
		lblEnca.setLabel("Detalle de la transacción");
		lblEnca.setStatus("hidden");
		fields2.add(lblEnca);

		Field<Value> lblLM = new Field<>();
		lblLM.setId("lblLM");
		lblLM.setLabel("LifeMiles");
		lblLM.setStatus("hidden");
		fields2.add(lblLM);

		Field<Value> totAcre = new Field<>();
		totAcre.setId("totAcre");
		totAcre.setLabel("Total Acreditar");
		totAcre.setStatus("hidden");
		fields2.add(totAcre);

		section2.setFields(fields2);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		List<Field<Value>> fields3 = new ArrayList<>();

		Field<Value> cbConfirm = new Field<>();
		cbConfirm.setId("ChbxConfi");
		cbConfirm.setLabel(
				"Confirmo que el total de millas arriba detalladas serán acreditadas a la cuenta mostrada, presione Acumular para que sean acreditadas.");
		cbConfirm.setStatus("visible");
		cbConfirm.setRequired("Y");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe confirmar los datos"));
		cbConfirm.setMessages(msg);
		fields3.add(cbConfirm);

		Field<Value> btnAcum = new Field<>();
		btnAcum.setId("btnSaveInfo");
		btnAcum.setLabel("Acumular");
		btnAcum.setStatus("visible");
		fields3.add(btnAcum);

		section3.setFields(fields3);
		sections.add(section3);

		form.setSections(sections);
		return form;
	}

	// FORMULARIO ACUMULACION DE MILLAS POS WEB
	public Form retrieveAccPosWeb() {
		List<Message> msg = new ArrayList<>();
		Form form = new Form();
		form.setTitle("Acumulación de Millas POS WEB");
		List<Section> sections = new ArrayList<>();

		msg.add(new Message(succ,
				"Transacción procesada con éxito, se acumularon {0} LifeMiles a la cuenta seleccionada.<br>El número de autorizacion de la transacción es: {1} "));
		form.setMessages(msg);
		Section section1 = new Section();
		section1.setIdSection("section1");
		List<Field<Value>> fields1 = new ArrayList<>();
		Field<Value> cmbAliado = new Field<>();
		cmbAliado.setId("ddlAliado");
		cmbAliado.setLabel("Aliado:");
		cmbAliado.setStatus("visible");
		cmbAliado.setRequired("Y");
		fields1.add(cmbAliado);
		section1.setFields(fields1);
		sections.add(section1);

		Section section2 = new Section();
		section2.setDescription("Complete la siguiente <i>Información</i>");
		section2.setIdSection("section2");
		List<Field<Value>> fields2 = new ArrayList<>();
		Field<Value> txtMun = new Field<>();
		txtMun.setId("txtMun");
		txtMun.setLabel("Cuenta a Abonar:");
		txtMun.setStatus("readonly");
		txtMun.setRequired("Y");
		txtMun.setPlaceholder("Cuenta a Abonar");
		txtMun.setFormat("^[0-9]*$");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe existir una cuenta"));
		msg.add(new Message(regEx, "Ingrese un valor de cuenta válido"));
		txtMun.setMessages(msg);
		fields2.add(txtMun);

		Field<Value> txtNombre = new Field<>();
		txtNombre.setId("txtNombreAccMcv");
		txtNombre.setLabel("Nombre de la Cuenta:");
		txtNombre.setStatus("readonly");
		txtNombre.setRequired("Y");
		txtNombre.setPlaceholder("Nombre de la Cuenta");
		txtNombre.setFormat("^[a-zA-Záéíóúñ ]*$");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese el nombre de la cuenta"));
		msg.add(new Message(regEx, "Ingrese un nombre válido"));
		txtNombre.setMessages(msg);
		fields2.add(txtNombre);

		Field<Value> cmbSucursal = new Field<>();
		cmbSucursal.setId("ddlSuc");
		cmbSucursal.setLabel("Sucursal:");
		cmbSucursal.setStatus("visible");
		cmbSucursal.setRequired("Y");
		cmbSucursal.setPlaceholder("Sucursal");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una sucursal"));
		msg.add(new Message(regEx, "Ingrese un nombre válido"));
		cmbSucursal.setMessages(msg);
		fields2.add(cmbSucursal);

		Field<Value> txtMonto = new Field<>();
		txtMonto.setId("txtMonto");
		txtMonto.setLabel("Monto Moneda Local:");
		txtMonto.setStatus("visible");
		txtMonto.setRequired("Y");
		txtMonto.setPlaceholder("Moneda Local");
		txtMonto.setFormat("^[0-9,\\.]*$");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un monto"));
		msg.add(new Message(regEx, "Ingrese solo numeros"));
		txtMonto.setMessages(msg);
		fields2.add(txtMonto);

		Field<Value> txtCodCaj = new Field<>();
		txtCodCaj.setId("txtCodCaj");
		txtCodCaj.setLabel("Código de Cajero:");
		txtCodCaj.setStatus("visible");
		txtCodCaj.setRequired("N");
		txtCodCaj.setPlaceholder("Código de Cajero");
		txtCodCaj.setFormat("^[a-zA-Z0-9]*$");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese un código de caja"));
		msg.add(new Message(regEx, "Ingrese solo alfanumerico"));
		txtCodCaj.setMessages(msg);
		fields2.add(txtCodCaj);
		section2.setFields(fields2);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		List<Field<Value>> fields3 = new ArrayList<>();

		Field<Value> chbxTipo = new Field<>();
		chbxTipo.setId("chbxTipo");
		chbxTipo.setLabel(
				"Confirmo que el total de millas arriba detalladas serán acreditadas a la cuenta mostrada, presione Acumular para que sean acreditadas.");
		chbxTipo.setStatus("visible");
		chbxTipo.setRequired("Y");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe confirmar los datos"));
		chbxTipo.setMessages(msg);
		fields3.add(chbxTipo);

		Field<Value> btnAcum = new Field<>();
		btnAcum.setId("btnSaveInfo");
		btnAcum.setLabel("Acumular");
		btnAcum.setStatus("visible");
		fields3.add(btnAcum);

		section3.setFields(fields3);
		sections.add(section3);

		form.setSections(sections);
		return form;
	}

	// FORMULARIO DE BÚSQUEDA DE MIEMBROS
	public Form retrieveFinderFormFields(String userType) {
		Form form = new Form();
		form.setTitle("B&uacute;squeda de socio");
		List<Section> sections = new ArrayList<>();
		List<Message> msg;
		List<Message> messagesForm = new ArrayList<>();
		messagesForm.add(new Message(meNot, "No se encontró información del socio con los parámetros enviados"));
		form.setMessages(messagesForm);
		Section section = new Section();
		section.setDescription(
				"Complete la siguiente <i>Información</i> para obtener los datos del Socio <i>LifeMiles</i>");
		section.setSubtitle("Individual"); // esto va aquí?? :O
		section.setIdSection("section1");

		List<Field<Value>> fields = new ArrayList<>();

		Field<Value> field1 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Ingrese un solamente números"));
		field1.setMessages(msg);
		field1.setAction(null);
		field1.setId("txtLM");
		field1.setLabel("ID LifeMiles:");
		field1.setMaxLength(11);
		field1.setRequired("N");
		field1.setStatus("visible");
		field1.setType("empty");
		field1.setFormat("^([0-9]*)$");

		fields.add(field1);

		Field<Value> field2 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Ingrese un nombre correcto"));
		field2.setMessages(msg);
		field2.setAction(null);
		field2.setFormat("^([A-Za-z]*)$");
		field2.setId("txtNombreMiembro");
		field2.setLabel("Nombre:");
		field2.setMaxLength(50);
		field2.setRequired("N");
		field2.setStatus("visible");
		field2.setType("empty");

		fields.add(field2);

		Field<Value> field3 = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Ingrese un apellido correcto"));
		field3.setMessages(msg);
		field3.setAction(null);
		field3.setFormat("^([A-Za-z]*)$");
		field3.setId("txtApel");
		field3.setLabel("Apellido:");
		field3.setMaxLength(50);
		field3.setRequired("N");
		field3.setStatus("visible");
		field3.setType("empty");

		fields.add(field3);

		Field<Value> field4 = new Field<>();
		field4.setId("txtBirthDate");
		field4.setLabel("Fecha de Nacimiento:");
		field4.setStatus("visible");
		field4.setRequired("N");
		field4.setPlaceholder("Fecha de Nacimiento");
		field4.setFormat("");// pendiente
		msg = new ArrayList<>();
		// msg.add(new Message(regEx, "Ingrese un apellido correcto"));
		msg.add(new Message(regEx, "Ingrese la fecha en formato dd/Mon/yyyy"));
		field4.setMessages(msg);
		field4.setMessages(msg);
		fields.add(field4);

		section.setFields(fields);
		sections.add(section);

		// BOTÓN DE BUSCAR
		Section section2 = new Section();
		section2.setDescription(
				"Verifique los datos ingresados para el Socio y presione <i>Buscar</i> para obtener la información.");
		section2.setSubtitle("");
		section2.setIdSection("section2");
		List<Field<Value>> fieldsB = new ArrayList<>();

		Field<Value> btnBuscar = new Field<>();
		btnBuscar.setAction(null);
		btnBuscar.setFormat(null);
		btnBuscar.setId("btnBuscarLM");
		btnBuscar.setLabel("Buscar");
		btnBuscar.setMaxLength(null);
		btnBuscar.setStatus("visible");
		btnBuscar.setType("");

		fieldsB.add(btnBuscar);
		section2.setFields(fieldsB);
		sections.add(section2);

		form.setSections(sections);

		return form;

	}

	public Form retrieveAccMcvSearch() {
		Form form = new Form();
		form.setTitle("Seleccione la opción para acumular LifeMiles");
		List<Message> messagesForm = new ArrayList<>();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> messages;
		messagesForm.add(new Message(meNot, "No se encontró información del socio con los parámetros enviados"));
		form.setMessages(messagesForm);

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setSubtitle("Individual");
		section1.setDescription(
				"Complete la siguiente <i>Información</i> para obtener los datos del Socio <i>LifeMiles</i>");

		Field<Value> field1 = new Field<>();
		messages = new ArrayList<>();
		messages.add(new Message(reqMe, "Número LifeMiles"));
		messages.add(new Message(regEx, "Ingrese un solamente números"));
		field1.setMessages(messages);
		field1.setAction(null);
		field1.setId("txtNumLM");
		field1.setLabel("ID LifeMiles:");
		field1.setMaxLength(11);
		field1.setRequired("N");
		field1.setStatus("visible");
		field1.setType("empty");
		field1.setFormat("^([0-9]*)$");

		fields.add(field1);

		Field<Value> field2 = new Field<>();
		messages = new ArrayList<>();
		messages.add(new Message(reqMe, "Nombre"));
		messages.add(new Message(regEx, "Ingrese un nombre correcto"));
		field2.setMessages(messages);
		field2.setAction(null);
		field2.setFormat("^([A-Za-z]*)$");
		field2.setId("txtNombreLM");
		field2.setLabel("Nombre:");
		field2.setMaxLength(50);
		field2.setRequired("N");
		field2.setStatus("visible");
		field2.setType("empty");

		fields.add(field2);

		Field<Value> field3 = new Field<>();
		messages = new ArrayList<>();
		messages.add(new Message(reqMe, "Apellido"));
		messages.add(new Message(regEx, "Ingrese un apellido correcto"));
		field3.setMessages(messages);
		field3.setAction(null);
		field3.setFormat("^([A-Za-z]*)$");
		field3.setId("txtApellidoLm");
		field3.setLabel("Apellido:");
		field3.setMaxLength(50);
		field3.setRequired("N");
		field3.setStatus("visible");
		field3.setType("empty");

		fields.add(field3);

		Field<Value> birthDate = new Field<>();
		birthDate.setId("txtBirthDateLM");
		birthDate.setLabel("Fecha de nacimiento:");
		birthDate.setStatus("visible");
		birthDate.setRequired("N");
		birthDate.setPlaceholder("Fecha de Nacimiento");
		birthDate.setFormat("^([0-9]){2}\\/([A-Z]){1}([a-z]){1,2}\\/([0-9]){1,4}$");// pendiente
		List<Message> birthDateMessage = new ArrayList<>();
		birthDateMessage.add(new Message(reqMe, "Ingrese la Fecha de Nacimiento del socio"));
		birthDateMessage.add(new Message(regEx, "Ingrese la fecha en formato dd/Mon/yyyy"));
		birthDate.setMessages(birthDateMessage);
		fields.add(birthDate);

		section1.setFields(fields);
		sections.add(section1);

		// seccion 2: sección del botón
		fields = new ArrayList<>();
		Section section2 = new Section();
		section2.setIdSection("section2");

		section2.setDescription(
				"Verifique los datos ingresados para el Socio y presione <i>Buscar</i> para obtener la información.");
		Field<Value> btnBuscar = new Field<>();
		btnBuscar.setAction(null);
		btnBuscar.setFormat(null);
		btnBuscar.setId("btnBuscar");
		btnBuscar.setLabel("Buscar");
		btnBuscar.setMaxLength(null);
		btnBuscar.setStatus("visible");
		btnBuscar.setType("");

		fields.add(btnBuscar);
		section2.setFields(fields);
		sections.add(section2);

		form.setSections(sections);
		return form;

	}

	public Form retrieveRevAccInfo() {
		Form form = new Form();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setDescription("Detalle de la transacción");

		Field<Value> transDate = new Field<Value>();
		transDate.setId("txtFechaTr");
		transDate.setLabel("Fecha Transacción:");
		transDate.setStatus("readonly");
		transDate.setPlaceholder("Fecha de Transacción");
		fields.add(transDate);

		Field<Value> lifeMilesNumber = new Field<Value>();
		lifeMilesNumber.setId("txtCodCli");
		lifeMilesNumber.setLabel("No LifeMiles:");
		lifeMilesNumber.setStatus("readonly");
		lifeMilesNumber.setPlaceholder("Número LifeMiles");
		lifeMilesNumber.setMaxLength(11);
		fields.add(lifeMilesNumber);

		Field<Value> clientName = new Field<Value>();
		clientName.setId("txtNomCliente");
		clientName.setLabel("Nombre Cliente:");
		clientName.setStatus("readonly");
		clientName.setPlaceholder("Nombre de Cliente");
		fields.add(clientName);

		Field<Value> partner = new Field<Value>();
		partner.setId("txtAliado");
		partner.setLabel("Aliado:");
		partner.setStatus("readonly");
		partner.setPlaceholder("Aliado");
		fields.add(partner);

		Field<Value> regularMiles = new Field<Value>();
		regularMiles.setId("txtMillasR");
		regularMiles.setLabel("Millas Regulares:");
		regularMiles.setStatus("readonly");
		regularMiles.setPlaceholder("Millas Regulares");
		fields.add(regularMiles);

		Field<Value> store = new Field<Value>();
		store.setId("txtSucursal");
		store.setLabel("Sucursal:");
		store.setStatus("readonly");
		store.setPlaceholder("Sucursal");
		fields.add(store);

		Field<Value> promotionalMiles = new Field<Value>();
		promotionalMiles.setId("txtMillasP");
		promotionalMiles.setLabel("Millas Promocionales:");
		promotionalMiles.setStatus("readonly");
		promotionalMiles.setPlaceholder("Millas Promocionales");
		fields.add(promotionalMiles);

		Field<Value> amount = new Field<Value>();
		amount.setId("txtMontoRev");
		amount.setLabel("Monto:");
		amount.setStatus("readonly");
		amount.setPlaceholder("Monto");
		fields.add(amount);

		Field<Value> totalMiles = new Field<Value>();
		totalMiles.setId("txtTotalMillas");
		totalMiles.setLabel("Total Millas:");
		totalMiles.setStatus("readonly");
		totalMiles.setPlaceholder("Total Millas");
		fields.add(totalMiles);

		Field<Value> transactionType = new Field<Value>();
		transactionType.setId("txtTipoTransaccion");
		transactionType.setLabel("Tipo Transacción:");
		transactionType.setStatus("readonly");
		transactionType.setPlaceholder("Tipo  de Transacción");
		fields.add(transactionType);

		Field<Value> storeCode = new Field<Value>();
		storeCode.setId("storeCode");
		storeCode.setStatus("hidden");
		fields.add(storeCode);

		Field<Value> transactionTypeCode = new Field<Value>();
		transactionTypeCode.setId("transactionType");
		transactionTypeCode.setStatus("hidden");

		fields.add(transactionTypeCode);

		Field<Value> pointTypeCode = new Field<Value>();
		pointTypeCode.setId("pointTypeCode");

		pointTypeCode.setStatus("hidden");

		fields.add(pointTypeCode);

		Field<Value> activityStatus = new Field<Value>();
		activityStatus.setId("activityStatus");

		activityStatus.setStatus("hidden");

		fields.add(activityStatus);

		section2.setFields(fields);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		fields = new ArrayList<>();
		Field<Value> btnSearch = new Field<>();
		btnSearch.setId("btnProcesar");
		btnSearch.setLabel("Revertir");
		btnSearch.setStatus("visible");

		fields.add(btnSearch);
		section3.setFields(fields);
		sections.add(section3);
		form.setSections(sections);

		return form;

	}

	public Form retrieveGiftCard() {
		Form form = new Form();
		form.setTitle("Activación de Gift Cards");
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();

		msg.add(new Message(notFound, "El serial digitado no existe"));
		msg.add(new Message(actAlre, "El serial digitado ya esta activo"));
		form.setMessages(msg);

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setSubtitle("Seleccione la opción para activar sus GiftCards");

		Field<Value> cmbAliado = new Field<>();
		cmbAliado.setId("ddlAliado");
		cmbAliado.setLabel("Aliado:");
		cmbAliado.setStatus("visible");
		cmbAliado.setRequired("Y");
		fields.add(cmbAliado);
		section1.setFields(fields);
		sections.add(section1);

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setSubtitle("Por Serial");
		section2.setDescription("Ingrese la información de los códigos a activar, luego presione <i>Activar</i>.");

		fields = new ArrayList<>();
		Field<Value> txtSerial = new Field<>();
		txtSerial.setId("txtSerial");
		txtSerial.setFormat("^[0-9a-zA-Z ]*$");

		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese el serial"));
		msg.add(new Message(regEx, "No puede colocar caracteres especiales"));
		txtSerial.setMessages(msg);
		txtSerial.setLabel("Serial:");
		txtSerial.setStatus("visible");
		txtSerial.setRequired("Y");
		fields.add(txtSerial);
		section2.setFields(fields);

		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		section3.setSubtitle("Por Archivo");
		section3.setDescription(
				"Para realizar la activación de GiftCards , presione <i>Adjuntar</i> y seleccione el archivo de Excel con la <a id='LotegGic' class='Colorbox cboxElement' href='#divLoteGic'>estructura definida</a>. <a href='Filestmp/Layout_Giftcard.xlsx' target='_blank'>Descargar Layout</a>");

		fields = new ArrayList<>();
		Field<Value> fileAct = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar un archivo excel"));
		msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
		fileAct.setMessages(msg);
		fileAct.setId("fileAct");
		fileAct.setLabel("Adjuntar...");
		fileAct.setDefaultValue("No ha seleccionado ningún archivo");
		fileAct.setRequired("N");
		fileAct.setStatus("visible");

		fields.add(fileAct);
		section3.setFields(fields);
		sections.add(section3);

		Section section4 = new Section();
		section4.setIdSection("section4");
		section4.setDescription("Verifique los datos y presione <i>Activar</i> para que sean efectivos.");

		fields = new ArrayList<>();
		Field<Value> btnSearch = new Field<>();
		btnSearch.setId("btnActivar");
		btnSearch.setLabel("Activar");
		btnSearch.setStatus("visible");

		fields.add(btnSearch);
		section4.setFields(fields);
		sections.add(section4);

		form.setSections(sections);
		return form;
	}

	public Form retrieveGiftCardReport(String user) {
		Form form = new Form();
		form.setTitle("Reportes");
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setSubtitle(
				"Seleccione los filtros que sean convenientes para su reporte, luego presione el botón Generar.");

		msg.add(new Message(reqMe, "Ingrese un aliado"));
		Field<Value> cmbAliado = new Field<>();
		cmbAliado.setId("slt_comercio2");
		cmbAliado.setLabel("Aliado:");
		cmbAliado.setMessages(msg);
		cmbAliado.setRequired("N");
		cmbAliado.setStatus("visible");
		fields.add(cmbAliado);

		Field<Value> btnPlus = new Field<>();
		btnPlus.setId("addCmr");

		if (env.getProperty("config.user-types.partner").equals(user)) {
			cmbAliado.setRequired("Y");
			cmbAliado.setStatus("readonly");
			btnPlus.setStatus("hidden");
		} else
			btnPlus.setStatus("visible");

		fields.add(btnPlus);

		Field<Value> cmbAliadoMulti = new Field<>();
		cmbAliadoMulti.setId("ddlCmrGift");
		cmbAliadoMulti.setRequired("Y");
		if (env.getProperty("config.user-types.partner").equals(user))
			cmbAliadoMulti.setStatus("hidden");
		else
			cmbAliadoMulti.setStatus("visible");
		List<Message> msgali = new ArrayList<>();
		msgali.add(new Message(reqMe, "Seleccione un aliado"));
		cmbAliadoMulti.setMessages(msgali);

		fields.add(cmbAliadoMulti);

		Field<Value> btnMinus = new Field<>();
		btnMinus.setId("remCmr");
		if (env.getProperty("config.user-types.partner").equals(user))
			btnMinus.setStatus("hidden");
		else
			btnMinus.setStatus("visible");

		fields.add(btnMinus);

		Field<Value> cmbYear = new Field<>();
		cmbYear.setId("ddlanio");
		cmbYear.setLabel("Año Calendario:");
		cmbYear.setRequired("Y");
		cmbYear.setStatus("visible");
		fields.add(cmbYear);

		section1.setFields(fields);
		sections.add(section1);

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setSubtitle("Filtrar por fecha de generación");

		fields = new ArrayList<>();
		Field<Value> fechaGenStart = new Field<>();
		msg = new ArrayList<>();
		fechaGenStart.setId("dtpfechagenini");
		fechaGenStart.setLabel("Fecha de generación inicial:");
		fechaGenStart.setRequired("N");
		fechaGenStart.setStatus("visible");
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha."));
		msg.add(new Message("calMs", "El reporte solo puede generarse dentro de un mismo año calendario."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		fechaGenStart.setMessages(msg);
		fields.add(fechaGenStart);

		Field<Value> fechaGenEnd = new Field<>();
		msg = new ArrayList<>();
		fechaGenEnd.setId("dtpfechagenfin");
		fechaGenEnd.setLabel("Fecha de generación final:");
		fechaGenEnd.setRequired("N");
		fechaGenEnd.setStatus("visible");
		msg.add(new Message(reqMe, "Debe seleccionar la fecha de fin de vigencia."));
		msg.add(new Message("calMs", "El reporte solo puede generarse dentro de un mismo año calendario."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		fechaGenEnd.setMessages(msg);
		fields.add(fechaGenEnd);

		section2.setFields(fields);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		section3.setSubtitle("Filtrar por fecha de activación");

		fields = new ArrayList<>();
		Field<Value> fechaActStart = new Field<>();
		msg = new ArrayList<>();
		fechaActStart.setId("dtpfechaactivini");
		fechaActStart.setLabel("Fecha de activación inicial:");
		fechaActStart.setRequired("N");
		fechaActStart.setStatus("visible");
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha."));
		msg.add(new Message("calMs", "El reporte solo puede generarse dentro de un mismo año calendario."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		fechaActStart.setMessages(msg);
		fields.add(fechaActStart);

		Field<Value> fechaActEnd = new Field<>();
		msg = new ArrayList<>();
		fechaActEnd.setId("dtpfechaactivfin");
		fechaActEnd.setLabel("Fecha de activación final:");
		fechaActEnd.setRequired("N");
		fechaActEnd.setStatus("visible");
		msg.add(new Message(reqMe, "Debe seleccionar la fecha de fin de vigencia."));
		msg.add(new Message("calMs", "El reporte solo puede generarse dentro de un mismo año calendario."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		fechaActEnd.setMessages(msg);
		fields.add(fechaActEnd);

		section3.setFields(fields);
		sections.add(section3);

		Section section4 = new Section();
		section4.setIdSection("section4");
		section4.setSubtitle("Filtrar por fecha de acumulación");

		fields = new ArrayList<>();
		Field<Value> fechaAcuStart = new Field<>();
		msg = new ArrayList<>();
		fechaAcuStart.setId("dtpfechaacumini");
		fechaAcuStart.setLabel("Fecha de acumulación inicial:");
		fechaAcuStart.setRequired("N");
		fechaAcuStart.setStatus("visible");
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha."));
		msg.add(new Message("calMs", "El reporte solo puede generarse dentro de un mismo año calendario."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		fechaAcuStart.setMessages(msg);
		fields.add(fechaAcuStart);

		Field<Value> fechaAcuEnd = new Field<>();
		msg = new ArrayList<>();
		fechaAcuEnd.setId("dtpfechaacumfin");
		fechaAcuEnd.setLabel("Fecha de acumulación final:");
		fechaAcuEnd.setRequired("N");
		fechaAcuEnd.setStatus("visible");
		msg.add(new Message(reqMe, "Debe seleccionar la fecha de fin de vigencia."));
		msg.add(new Message("calMs", "El reporte solo puede generarse dentro de un mismo año calendario."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		fechaAcuEnd.setMessages(msg);
		fields.add(fechaAcuEnd);

		section4.setFields(fields);
		sections.add(section4);

		Section section5 = new Section();
		section5.setIdSection("section5");
		section5.setSubtitle("Por Código");

		fields = new ArrayList<>();
		Field<Value> txtCodigo = new Field<>();
		msg = new ArrayList<>();
		txtCodigo.setId("txtcodgic");
		txtCodigo.setLabel("Código:");
		txtCodigo.setPlaceholder("Código del Gift Card");
		msg.add(new Message(reqMe, "Debe Escribir un código."));
		msg.add(new Message("calMs", "La búsqueda solo puede realizarse por separado serial o código de Gift Card ."));
		msg.add(new Message(regEx, "No puede colocar caracteres especiales"));
		txtCodigo.setMessages(msg);
		txtCodigo.setFormat("^[0-9a-zA-Z ]*$");
		txtCodigo.setRequired("N");
		txtCodigo.setStatus("visible");
		fields.add(txtCodigo);

		Field<Value> txtSerial = new Field<>();
		msg = new ArrayList<>();
		txtSerial.setId("txtserial");
		txtSerial.setLabel("Serial:");
		txtSerial.setPlaceholder("Serial del Gift Card");
		msg.add(new Message(reqMe, "Debe Escribir un serial."));
		msg.add(new Message("calMs", "La búsqueda solo puede realizarse por separado serial o código de Gift Card ."));
		msg.add(new Message(regEx, "No puede colocar caracteres especiales"));
		txtSerial.setMessages(msg);
		txtSerial.setFormat("^[0-9a-zA-Z ]*$");
		txtSerial.setRequired("N");
		txtSerial.setStatus("visible");
		fields.add(txtSerial);

		section5.setFields(fields);
		sections.add(section5);

		Section section6 = new Section();
		section6.setIdSection("section6");
		fields = new ArrayList<>();
		Field<Value> btnGenerar = new Field<>();
		btnGenerar.setId("btnGenerar");
		btnGenerar.setLabel("Generar");
		btnGenerar.setStatus("visible");

		fields.add(btnGenerar);
		section6.setFields(fields);
		sections.add(section6);

		form.setSections(sections);
		return form;
	}

	public Form retrieveRedReportForm(String user) {
		Form form = new Form();

		form.setTitle("Reporte WS Redenciones");
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");

		Field<Value> partnerList = new Field<>();
		partnerList.setId("slt_comercio");
		msg.add(new Message(reqMe, "Debe Seleccionar un aliado."));
		partnerList.setPlaceholder("Aliados");
		partnerList.setLabel("Aliado:");
		partnerList.setRequired("Y");
		partnerList.setStatus("visible");
		fields.add(partnerList);

		Field<Value> selectedPartners = new Field<>();
		selectedPartners.setId("ddlCmr");
		selectedPartners.setRequired("Y");
		selectedPartners.setMessages(msg);
		selectedPartners.setPlaceholder("Aliados seleccionados");
		if (env.getProperty("config.user-types.partner").equals(user))
			selectedPartners.setStatus("hidden");
		else
			selectedPartners.setStatus("visible");
		fields.add(selectedPartners);

		Field<Value> addPar = new Field<>();
		addPar.setId("addCmr");
		addPar.setLabel("+");
		if (env.getProperty("config.user-types.partner").equals(user)) {
			addPar.setStatus("hidden");
		} else {
			addPar.setStatus("visible");
		}

		fields.add(addPar);

		Field<Value> resPar = new Field<>();
		resPar.setId("remCmr");
		resPar.setLabel("-");
		if (env.getProperty("config.user-types.partner").equals(user)) {
			resPar.setStatus("hidden");
		} else {
			resPar.setStatus("visible");
		}
		fields.add(resPar);

		section1.setFields(fields);

		sections.add(section1);

		fields = new ArrayList<>();

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setDescription("Seleccione los parámetros de consulta:");

		Field<Value> startDate = new Field<>();
		startDate.setId("fechadesde");
		startDate.setPlaceholder("Fecha de Inicio:");
		startDate.setLabel("Fecha de Inicio:");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		startDate.setMessages(msg);
		startDate.setRequired("Y");
		startDate.setStatus("visible");

		fields.add(startDate);

		Field<Value> endDate = new Field<>();
		endDate.setId("fechahasta");
		endDate.setLabel("Fecha de Fin:");
		endDate.setPlaceholder("Fecha de Fin:");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		endDate.setMessages(msg);
		endDate.setRequired("Y");
		endDate.setStatus("visible");

		fields.add(endDate);

		Field<Value> lmNumber = new Field<>();
		lmNumber.setId("txtnc");
		lmNumber.setPlaceholder("Número LifeMiles");
		lmNumber.setLabel("Número LifeMiles");
		lmNumber.setMaxLength(11);
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Dígitos"));
		lmNumber.setMessages(msg);
		lmNumber.setRequired("N");
		lmNumber.setStatus("visible");

		fields.add(lmNumber);

		Field<Value> appNumber = new Field<>();
		appNumber.setId("txtrs");
		appNumber.setPlaceholder("Número de Aprobación");
		appNumber.setLabel("Número de Aprobación");
		appNumber.setRequired("N");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Dígitos"));
		appNumber.setStatus("visible");

		fields.add(appNumber);

		Field<Value> note = new Field<>();
		note.setId("transTypeNote");
		note.setLabel("Tipos de Transacción");
		note.setStatus("visible");
		fields.add(note);

		Field<Value> transType = new Field<>();
		transType.setId("slt_Tipo_Transacciones");
		transType.setPlaceholder("Tipos de transacciones");
		transType.setLabel("Tipo de transacción");
		transType.setStatus("visible");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Seleccione Transacciones"));
		transType.setMessages(msg);
		fields.add(transType);

		Field<Value> selectedTrans = new Field<>();
		selectedTrans.setId("ddlTra");
		selectedTrans.setRequired("Y");
		selectedTrans.setPlaceholder("Tipos de Transacción seleccionados");
		selectedTrans.setStatus("visible");
		fields.add(selectedTrans);

		Field<Value> addTra = new Field<>();
		addTra.setId("addTra");
		addTra.setLabel("+");
		addTra.setStatus("visible");
		fields.add(addTra);

		Field<Value> resTra = new Field<>();
		resTra.setId("remTra");
		resTra.setLabel("-");
		resTra.setStatus("visible");
		fields.add(resTra);

		section2.setFields(fields);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		fields = new ArrayList<>();
		Field<Value> genBtn = new Field<>();
		genBtn.setId("genBtn");
		genBtn.setLabel("Generar");
		genBtn.setStatus("visible");
		fields.add(genBtn);

		section3.setFields(fields);

		sections.add(section3);
		form.setSections(sections);

		return form;

	}

	// Formulario de Reporte MCV

	public Form retrieveMilesCVReportForm(String user) {
		Form form = new Form();

		form.setTitle("Reporte MCV");
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");

		Field<Value> partnerList = new Field<>();
		partnerList.setId("slt_comercio");
		msg.add(new Message(reqMe, "Debe Seleccionar un aliado."));
		partnerList.setPlaceholder("Aliados");
		partnerList.setLabel("Aliado:");
		partnerList.setRequired("Y");
		partnerList.setStatus("visible");
		fields.add(partnerList);

		Field<Value> selectedPartners = new Field<>();
		selectedPartners.setId("ddlCmr");
		selectedPartners.setRequired("Y");
		if (env.getProperty("config.user-types.partner").equals(user))
			selectedPartners.setStatus("hidden");
		else
			selectedPartners.setStatus("visible");
		selectedPartners.setMessages(msg);
		selectedPartners.setPlaceholder("Aliados seleccionados");
		fields.add(selectedPartners);

		Field<Value> btnPlus = new Field<>();
		btnPlus.setId("addCmr");

		if (env.getProperty("config.user-types.partner").equals(user)) {
			partnerList.setRequired("Y");
			partnerList.setStatus("readonly");
			btnPlus.setStatus("hidden");
		} else
			btnPlus.setStatus("visible");

		fields.add(btnPlus);

		Field<Value> btnMinus = new Field<>();
		btnMinus.setId("remCmr");
		if (env.getProperty("config.user-types.partner").equals(user))
			btnMinus.setStatus("hidden");
		else
			btnMinus.setStatus("visible");

		fields.add(btnMinus);

		section1.setFields(fields);

		sections.add(section1);

		fields = new ArrayList<>();

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setDescription("Seleccione los parámetros de consulta:");

		Field<Value> startDate = new Field<>();
		startDate.setId("fechadesde");
		startDate.setPlaceholder("Fecha de Inicio:");
		startDate.setLabel("Fecha de Inicio:");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha de inicio."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		startDate.setMessages(msg);
		startDate.setRequired("Y");
		startDate.setStatus("visible");

		fields.add(startDate);

		Field<Value> endDate = new Field<>();
		endDate.setId("fechahasta");
		endDate.setLabel("Fecha de Fin:");
		endDate.setPlaceholder("Fecha de Fin:");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha de fin."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		endDate.setMessages(msg);
		endDate.setRequired("Y");
		endDate.setStatus("visible");

		fields.add(endDate);

		Field<Value> lmNumber = new Field<>();
		lmNumber.setId("txtnc");
		lmNumber.setPlaceholder("Número LifeMiles");
		lmNumber.setLabel("Número LifeMiles:");
		lmNumber.setMaxLength(11);
		lmNumber.setFormat("^([0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Números"));
		lmNumber.setMessages(msg);
		lmNumber.setRequired("N");
		lmNumber.setStatus("visible");

		fields.add(lmNumber);

		Field<Value> appNumber = new Field<>();
		appNumber.setId("txtrs");
		appNumber.setPlaceholder("Número de Aprobación");
		appNumber.setLabel("Número de Aprobación:");
		appNumber.setRequired("N");
		appNumber.setFormat("^([0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Números"));
		appNumber.setStatus("visible");

		fields.add(appNumber);

		Field<Value> prePurch = new Field<>();
		prePurch.setId("txtprecompra");
		prePurch.setPlaceholder("Número de Precompra");
		prePurch.setLabel("Número de Precompra:");
		prePurch.setRequired("N");
		prePurch.setFormat("^([0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Números"));
		prePurch.setStatus("visible");
		fields.add(prePurch);

		Field<Value> note = new Field<>();
		note.setId("transTypeNote");
		note.setLabel("Tipos de Transacción");
		note.setStatus("visible");
		fields.add(note);

		Field<Value> transType = new Field<>();
		transType.setId("slt_Tipo_Transacciones");
		transType.setPlaceholder("Tipos de transacciones");
		transType.setRequired("Y");
		transType.setLabel("Tipo de transacción:");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar un tipo de transacción"));
		transType.setMessages(msg);
		transType.setStatus("visible");
		fields.add(transType);

		Field<Value> selectedTrans = new Field<>();
		selectedTrans.setId("ddlTra");
		selectedTrans.setRequired("Y");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "No hay Transacciones seleccionadas."));
		selectedTrans.setMessages(msg);
		selectedTrans.setPlaceholder("Tipos de Transacción seleccionados");
		selectedTrans.setStatus("visible");
		fields.add(selectedTrans);

		Field<Value> btnPlusTwo = new Field<>();
		btnPlusTwo.setId("addTra");
		btnPlusTwo.setStatus("visible");
		fields.add(btnPlusTwo);

		Field<Value> btnMinusTwo = new Field<>();
		btnMinusTwo.setId("remTra");
		btnMinusTwo.setStatus("visible");

		fields.add(btnMinusTwo);

		section2.setFields(fields);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		fields = new ArrayList<>();
		Field<Value> genBtn = new Field<>();
		genBtn.setId("genBtn");
		genBtn.setLabel("Generar");
		genBtn.setStatus("visible");
		fields.add(genBtn);

		section3.setFields(fields);

		sections.add(section3);
		form.setSections(sections);

		return form;
	}

	public Form retrieveTransReport(String idForm, String user) {
		Form form = new Form();
		form.setTitle("Reporte de transacciones");

		List<Message> msg;
		List<Section> sections = new ArrayList<>();
		List<Field<Value>> fields = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");

		Field<Value> btnPlus;
		Field<Value> btnMinus;

		if (env.getProperty("config.form-names.tra-cmr-report").equals(idForm)
			
				) {
			Field<Value> cmbPartner = new Field<>();
			cmbPartner.setId("slt_comercio");

			btnPlus = new Field<>();
			btnPlus.setId("addCmr");

			btnMinus = new Field<>();
			btnMinus.setId("remCmr");

			Field<Value> cmbAliadoMulti = new Field<>();
			cmbAliadoMulti.setId("ddlCmr");
			cmbAliadoMulti.setRequired("Y");
			cmbAliadoMulti.setStatus("visible");

			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione un aliado"));
			cmbAliadoMulti.setMessages(msg);

			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione un aliado"));
			cmbPartner.setMessages(msg);
			cmbPartner.setLabel("Aliado:");
			cmbPartner.setRequired("N");
			cmbPartner.setStatus("visible");

			btnPlus.setStatus("visible");
			btnMinus.setStatus("visible");

			if (env.getProperty("config.user-types.partner").equals(user)) {
				cmbAliadoMulti.setStatus("hidden");
				cmbAliadoMulti.setRequired("N");
				cmbPartner.setStatus("readonly");
				btnPlus.setStatus("hidden");
				btnMinus.setStatus("hidden");
			}

			fields.add(cmbPartner);
			fields.add(cmbAliadoMulti);
			fields.add(btnPlus);
			fields.add(btnMinus);
		}
		if (env.getProperty("config.form-names.tra-cou-report").equals(idForm)
				&& userLM.equals(user)) {
			Field<Value> cmbPais = new Field<>();
			cmbPais.setId("ddlTraPais");

			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione un país"));
			cmbPais.setMessages(msg);
			cmbPais.setLabel("País:");
			cmbPais.setRequired("N");
			cmbPais.setStatus("visible");

			btnPlus = new Field<>();
			btnPlus.setId("addPai");

			btnMinus = new Field<>();
			btnMinus.setId("remPai");

			btnPlus.setStatus("visible");
			btnMinus.setStatus("visible");

			Field<Value> cmbPaiMulti = new Field<>();
			cmbPaiMulti.setId("ddlPaisMulti");
			cmbPaiMulti.setRequired("Y");
			cmbPaiMulti.setStatus("visible");

			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione un país"));
			cmbPaiMulti.setMessages(msg);

			fields.add(cmbPais);
			fields.add(cmbPaiMulti);
			fields.add(btnPlus);
			fields.add(btnMinus);
		}

		section1.setFields(fields);
		sections.add(section1);

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setDescription("Seleccione los parámetros de consulta:");

		fields = new ArrayList<>();

		Field<Value> startDateTra = new Field<>();
		startDateTra.setId("fechadesde");
		startDateTra.setLabel("Fecha de inicio:");
		startDateTra.setStatus("visible");
		startDateTra.setRequired("Y");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Seleccione una fecha de inicio"));
		msg.add(new Message(regEx, "Ingrese el formato correcto"));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		startDateTra.setMessages(msg);
		fields.add(startDateTra);

		Field<Value> endDateTra = new Field<>();
		endDateTra.setId("fechahasta");
		endDateTra.setLabel("Fecha de fin:");
		endDateTra.setStatus("visible");
		endDateTra.setRequired("Y");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Seleccione una fecha de fin"));
		msg.add(new Message(regEx, "Ingrese el formato correcto"));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		endDateTra.setMessages(msg);
		fields.add(endDateTra);

		Field<Value> mun = new Field<>();
		mun.setId("txtMunTra");
		mun.setLabel("Número LifeMiles:");
		mun.setStatus("visible");
		mun.setRequired("N");
		mun.setMaxLength(11);
		mun.setFormat("^[0-9]*$");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese el MUN"));
		msg.add(new Message(regEx, "Ingrese solamente numeros"));
		mun.setMessages(msg);
		fields.add(mun);

		Field<Value> txtrs = new Field<>();
		txtrs.setId("txtrs");
		txtrs.setLabel("Número de aprobación:");
		txtrs.setStatus("visible");
		txtrs.setRequired("N");
		txtrs.setFormat("^[0-9]*$");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese el numero de aprobación"));
		msg.add(new Message(regEx, "Ingrese solamente numeros"));
		txtrs.setMessages(msg);
		fields.add(txtrs);

		section2.setFields(fields);
		sections.add(section2);

		if (!env.getProperty("config.form-names.tra-cou-report").equals(idForm)) {
			Section section3 = new Section();
			section3.setIdSection("pslt_sucursales");
			section3.setSubtitle("Establecimientos");

			fields = new ArrayList<>();

			Field<Value> slt_sucursales = new Field<>();
			slt_sucursales.setId("slt_sucursales");
			slt_sucursales.setRequired("N");
			slt_sucursales.setLabel("Establecimiento:");
			slt_sucursales.setStatus("visible");

			fields.add(slt_sucursales);

			Field<Value> ddlSucs = new Field<>();
			ddlSucs.setId("ddlSucs");
			ddlSucs.setRequired("Y");
			ddlSucs.setStatus("visible");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione establecimientos"));
			ddlSucs.setMessages(msg);
			fields.add(ddlSucs);

			btnPlus = new Field<>();
			btnPlus.setId("addSuc");
			fields.add(btnPlus);

			btnMinus = new Field<>();
			btnMinus.setId("remSuc");
			fields.add(btnMinus);

			btnPlus.setStatus("visible");
			btnMinus.setStatus("visible");

			section3.setFields(fields);
			sections.add(section3);

			Section section4 = new Section();
			section4.setIdSection("pslt_Tipo_Transacciones");
			section4.setSubtitle("Tipos de transacción");

			fields = new ArrayList<>();

			Field<Value> cmbTrans = new Field<>();
			cmbTrans.setId("slt_Tipo_Transacciones");
			cmbTrans.setRequired("N");
			cmbTrans.setLabel("Tipo de transacción:");
			cmbTrans.setStatus("visible");

			fields.add(cmbTrans);

			Field<Value> ddlTra = new Field<>();
			ddlTra.setId("ddlTra");
			ddlTra.setRequired("Y");
			ddlTra.setStatus("visible");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Seleccione el tipo de transacción"));
			ddlTra.setMessages(msg);
			fields.add(ddlTra);

			btnPlus = new Field<>();
			btnPlus.setId("addTra");
			fields.add(btnPlus);

			btnMinus = new Field<>();
			btnMinus.setId("remTra");
			fields.add(btnMinus);

			btnPlus.setStatus("visible");
			btnMinus.setStatus("visible");

			section4.setFields(fields);
			sections.add(section4);

		}

		Section section5 = new Section();
		section5.setIdSection("section5");

		fields = new ArrayList<>();
		Field<Value> btnSearch = new Field<>();
		btnSearch.setId("btnGenerar");
		btnSearch.setLabel("Generar");
		btnSearch.setStatus("visible");

		fields.add(btnSearch);

		section5.setFields(fields);
		sections.add(section5);
		form.setSections(sections);
		return form;
	}

	// Form de reporte de cajeros

	public Form retrieveCashierReportForm(String user) {
		Form form = new Form();

		form.setTitle("Reporte Cajeros");
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");

		Field<Value> partnerList = new Field<>();
		partnerList.setId("slt_comercio");
		msg.add(new Message(reqMe, "Debe Seleccionar un aliado."));
		partnerList.setPlaceholder("Aliados");
		partnerList.setLabel("Aliado:");
		partnerList.setRequired("Y");
		partnerList.setStatus("visible");
		fields.add(partnerList);

		Field<Value> selectedPartners = new Field<>();
		selectedPartners.setId("ddlCmr");
		selectedPartners.setRequired("Y");
		if (env.getProperty("config.user-types.partner").equals(user))
			selectedPartners.setStatus("hidden");
		else
			selectedPartners.setStatus("visible");
		selectedPartners.setMessages(msg);
		selectedPartners.setPlaceholder("Aliados seleccionados");
		fields.add(selectedPartners);

		Field<Value> btnPlus = new Field<>();
		btnPlus.setId("addCmr");

		if (env.getProperty("config.user-types.partner").equals(user)) {
			partnerList.setRequired("Y");
			partnerList.setStatus("readonly");
			btnPlus.setStatus("hidden");
		} else
			btnPlus.setStatus("visible");

		fields.add(btnPlus);

		Field<Value> btnMinus = new Field<>();
		btnMinus.setId("remCmr");
		if (env.getProperty("config.user-types.partner").equals(user))
			btnMinus.setStatus("hidden");
		else
			btnMinus.setStatus("visible");

		fields.add(btnMinus);

		section1.setFields(fields);

		sections.add(section1);

		fields = new ArrayList<>();

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setDescription("Seleccione los parámetros de consulta:");

		Field<Value> codCash = new Field<>();
		codCash.setId("txtcash");
		codCash.setPlaceholder("Código Cajero");
		codCash.setLabel("Código Cajero:");
		codCash.setMaxLength(11);
		codCash.setFormat("^([0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Números"));
		codCash.setMessages(msg);
		codCash.setRequired("N");
		codCash.setStatus("visible");

		fields.add(codCash);

		Field<Value> lmNumber = new Field<>();
		lmNumber.setId("txtnc");
		lmNumber.setPlaceholder("Número LifeMiles");
		lmNumber.setLabel("Número LifeMiles:");
		lmNumber.setMaxLength(11);
		lmNumber.setFormat("^([0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Números"));
		lmNumber.setMessages(msg);
		lmNumber.setRequired("N");
		lmNumber.setStatus("visible");

		fields.add(lmNumber);

		Field<Value> docNum = new Field<>();
		docNum.setId("txtdoc");
		docNum.setPlaceholder("Número Documento");
		docNum.setLabel("Número Documento:");
		docNum.setMaxLength(15);
		docNum.setFormat("^([0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Números"));
		docNum.setMessages(msg);
		docNum.setRequired("N");
		docNum.setStatus("visible");

		fields.add(docNum);

		Field<Value> codEmp = new Field<>();
		codEmp.setId("txtemp");
		codEmp.setPlaceholder("Código Empleado");
		codEmp.setLabel("Código Empleado:");
		codEmp.setMaxLength(11);
		codEmp.setFormat("^([0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Números"));
		codEmp.setMessages(msg);
		codEmp.setRequired("N");
		codEmp.setStatus("visible");

		fields.add(codEmp);

		Field<Value> startDate = new Field<>();
		startDate.setId("fechadesde");
		startDate.setPlaceholder("Fecha de Inicio:");
		startDate.setLabel("Fecha de Inicio:");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha de inicio."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		startDate.setMessages(msg);
		startDate.setRequired("N");
		startDate.setStatus("visible");

		fields.add(startDate);

		Field<Value> endDate = new Field<>();
		endDate.setId("fechahasta");
		endDate.setLabel("Fecha de Fin:");
		endDate.setPlaceholder("Fecha de Fin:");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar una fecha de fin."));
		msg.add(new Message(datIn, "La fecha de inicio debe ser menor a la fecha fin"));
		endDate.setMessages(msg);
		endDate.setRequired("N");
		endDate.setStatus("visible");

		fields.add(endDate);

		Field<Value> namefield = new Field<>();
		namefield.setId("txtname");
		namefield.setPlaceholder("Nombre");
		namefield.setLabel("Nombre:");
		namefield.setMaxLength(11);
		namefield.setFormat("^([a-zA-Z]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		namefield.setMessages(msg);
		namefield.setRequired("N");
		namefield.setStatus("visible");

		fields.add(namefield);

		Field<Value> lastnamefield = new Field<>();
		lastnamefield.setId("txtlastname");
		lastnamefield.setPlaceholder("Apellido");
		lastnamefield.setLabel("Apellido:");
		lastnamefield.setMaxLength(11);
		lastnamefield.setFormat("^([a-zA-Z]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		lastnamefield.setMessages(msg);
		lastnamefield.setRequired("N");
		lastnamefield.setStatus("visible");

		fields.add(lastnamefield);

		Field<Value> radioBtn = new Field<>();
		radioBtn.setAction(null);
		radioBtn.setFormat(null);
		radioBtn.setId("cashierRadio");
		radioBtn.setLabel("Estado");
		radioBtn.setMaxLength(null);
		radioBtn.setRequired("Y");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Seleccione una opcion para generar el reporte"));
		radioBtn.setMessages(msg);
		radioBtn.setStatus("visible");
		radioBtn.setType(null);
		radioBtn.setDefaultValue("A");

		fields.add(radioBtn);

		section2.setFields(fields);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		fields = new ArrayList<>();
		Field<Value> genBtn = new Field<>();
		genBtn.setId("genBtn");
		genBtn.setLabel("Generar");
		genBtn.setStatus("visible");
		fields.add(genBtn);

		section3.setFields(fields);

		sections.add(section3);
		form.setSections(sections);

		return form;
	}

	// form user creation
	public Form retrieveUserCreation(String user) {
		Form form = new Form();

		List<Message> msg = new ArrayList<>();
		msg.add(new Message(exists, "Ese usuario ya existe"));
		msg.add(new Message(inputMis, "Un valor requerido hace falta"));
		msg.add(new Message(pasNotMatch, "La contraseña no coincide con la confirmación"));
		msg.add(new Message(minlenghtPas, "La contraseña debe contener mínimo 8 caracteres."));
		msg.add(new Message(pasReq, "La contraseña debe contener al menos una mayúscula, una minúscula y un número"));
		msg.add(new Message(apprvExists,"Ya existe un aprobador para el área y flujo/aliado seleccionado"));
		form.setMessages(msg);
		form.setTitle("Crear usuarios");
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		msg = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setDescription("Seleccione del siguiente listado los aliados que desee asignar al nuevo usuario");

		Field<Value> groupList = new Field<>();
		groupList.setId("slt_conso");
		msg.add(new Message(reqMe, "Debe Seleccionar un grupo."));
		groupList.setLabel("Grupo:");
		groupList.setRequired("Y");
		groupList.setStatus("visible");
		fields.add(groupList);

		Field<Value> partnerList = new Field<>();
		partnerList.setId("slt_commmerce");
		partnerList.setLabel("Aliado:");
		partnerList.setRequired("N");
		partnerList.setStatus("visible");

		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar un aliado."));
		Field<Value> selectedPartners = new Field<>();
		selectedPartners.setId("ddAliados");
		selectedPartners.setRequired("Y");

		Field<Value> btnPlus = new Field<>();
		btnPlus.setId("addCmr");

		Field<Value> btnMinus = new Field<>();
		btnMinus.setId("remCmr");

		if (env.getProperty("config.user-types.partner").equals(user)) {
			groupList.setStatus("hidden");
			partnerList.setStatus("readonly");
			selectedPartners.setStatus("hidden");
			selectedPartners.setRequired("N");
			btnPlus.setStatus("hidden");
			btnMinus.setStatus("hidden");
		} else {
			selectedPartners.setStatus("visible");
			btnPlus.setStatus("visible");
			btnMinus.setStatus("visible");

			if (userGR.equals(user))
				groupList.setStatus("readonly");
		}
		fields.add(partnerList);
		selectedPartners.setMessages(msg);
		selectedPartners.setPlaceholder("Aliados seleccionados");
		fields.add(selectedPartners);

		fields.add(btnPlus);
		fields.add(btnMinus);

		section1.setFields(fields);

		sections.add(section1);

		fields = new ArrayList<>();

		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setDescription("Complete la siguiente información para crear un nuevo usuario.");

		Field<Value> field = new Field<>();
		field.setId("txtPNombre");
		field.setPlaceholder("Primer Nombre");
		field.setLabel("Primer Nombre:");
		field.setFormat("^([a-zA-Z]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		field.setMessages(msg);
		field.setRequired("Y");
		field.setStatus("visible");

		fields.add(field);

		field = new Field<>();
		field.setId("txtSNombre");
		field.setPlaceholder("Segundo Nombre");
		field.setLabel("Segundo Nombre:");
		field.setFormat("^([a-zA-Z]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		field.setMessages(msg);
		field.setRequired("N");
		field.setStatus("visible");

		fields.add(field);

		field = new Field<>();
		field.setId("txtPApellido");
		field.setPlaceholder("Primer Apellido");
		field.setLabel("Primer Apellido:");
		field.setFormat("^([a-zA-Z]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		field.setMessages(msg);
		field.setRequired("Y");
		field.setStatus("visible");

		fields.add(field);

		field = new Field<>();
		field.setId("txtSApellido");
		field.setPlaceholder("Segundo Apellido");
		field.setLabel("Segundo Apellido:");
		field.setFormat("^([a-zA-Z]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		field.setMessages(msg);
		field.setRequired("N");
		field.setStatus("visible");

		fields.add(field);

		Field<Value> docNum = new Field<>();
		docNum.setId("txtDocumento");
		docNum.setPlaceholder("Número Documento");
		docNum.setLabel("Número de Documento:");
		docNum.setMaxLength(15);
		docNum.setFormat("^([0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir Números"));
		docNum.setMessages(msg);
		docNum.setRequired("Y");
		docNum.setStatus("visible");

		fields.add(docNum);

		field = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Ingrese una dirección de correo correcta"));
		msg.add(new Message(regEx, "Ingrese una dirección de correo correcta"));
		field.setAction(null);
		field.setFormat("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)+$");
		field.setId("txtEmailUser");
		field.setLabel("Correo electrónico:");
		field.setPlaceholder("Correo electrónico de contacto");
		field.setMessages(msg);
		field.setMaxLength(40);
		field.setRequired("Y");
		field.setStatus("visible");

		fields.add(field);

		field = new Field<>();
		field.setId("txtUsuario");
		field.setPlaceholder("Usuario");
		field.setLabel("Usuario:");
		field.setFormat("^([A-Z]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		msg.add(new Message(reqMe, "Ingrese un nombre de usuario"));
		field.setMessages(msg);
		field.setRequired("Y");
		field.setStatus("visible");

		fields.add(field);

		field = new Field<>();
		field.setId("txtCargo");
		field.setPlaceholder("Cargo en la empresa");
		field.setLabel("Cargo en la empresa:");
		field.setFormat("^([a-zA-Z0-9]*)$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir alfanumerico"));
		field.setMessages(msg);
		field.setRequired("N");
		field.setStatus("visible");

		fields.add(field);

		field = new Field<>();
		field.setId("txtPassword");
		field.setPlaceholder("Contraseña");
		field.setLabel("Contraseña:");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir alfanumerico"));
		field.setMessages(msg);
		field.setRequired("Y");
		field.setStatus("visible");

		fields.add(field);

		field = new Field<>();
		field.setId("txtConfirmPwd");
		field.setPlaceholder("Repita la Contraseña");
		field.setLabel("Confirmar Contraseña:");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir alfanumerico"));
		field.setMessages(msg);
		field.setRequired("Y");
		field.setStatus("visible");

		fields.add(field);

		section2.setFields(fields);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		section3.setDescription(
				"Para habilitar el nuevo usuario, seleccione la opción Activo. Para restringir el acceso del mismo en el portal, seleccione <i>Inactivo</i>.");

		fields = new ArrayList<>();

		Field<Value> radioBtn = new Field<>();
		radioBtn.setAction(null);
		radioBtn.setFormat(null);
		radioBtn.setId("radEstado");
		radioBtn.setLabel("Estado");
		radioBtn.setMaxLength(null);
		radioBtn.setRequired("Y");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar un estado"));
		radioBtn.setMessages(msg);
		radioBtn.setStatus("visible");

		fields.add(radioBtn);

		section3.setFields(fields);
		sections.add(section3);

		Section section4 = new Section();
		section4.setIdSection("section4");
		section4.setSubtitle("Funciones");
		section4.setDescription("Seleccione del siguiente listado las funciones que desee habilitar al nuevo usuario.");

		fields = new ArrayList<>();

		field = new Field<>();
		field.setFormat(null);
		field.setId("slt_rol_create");
		field.setLabel("Seleccione:");
		field.setRequired("N");
		field.setStatus("visible");

		fields.add(field);

		field = new Field<>();
		field.setId("ddlRolesCreate");
		field.setRequired("Y");

		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar alguna función"));
		field.setMessages(msg);
		field.setStatus("visible");
		fields.add(field);

		field = new Field<>();
		field.setId("btn_Add");
		field.setStatus("visible");
		fields.add(field);

		field = new Field<>();
		field.setId("btn_Rem");
		field.setStatus("visible");
		fields.add(field);

		section4.setFields(fields);
		sections.add(section4);

		Section section8 = new Section();
		section8.setIdSection("section8");
		section8.setSubtitle("");
		section8.setDescription("");

		fields = new ArrayList<>();
		field = new Field<>();
		field.setId("btt_Guardar");
		field.setStatus("visible");
		field.setLabel("Guardar");
		fields.add(field);

		section8.setFields(fields);
		sections.add(section8);

		form.setSections(sections);

		return form;
	}

	// user form retrieve approver area
	public Form retreivesAreasUserForm(String idForm, String userType) {
		Form form = new Form();
		List<Field<Value>> fields;
		List<Section> sections = new ArrayList<>();
		if (env.getProperty("config.form-names.approver-area").equals(idForm)) {
			Section section5 = new Section();
			section5.setIdSection("section5");
			section5.setSubtitle("Tipo de Aprobador");
			section5.setDescription(
					"Seleccione del siguiente listado el tipo de aprobador que se asignará al usuario.");

			fields = new ArrayList<>();
			Field<Value> field = new Field<>();
			field.setFormat(null);
			field.setId("ddlArea");
			field.setLabel("Seleccione:");
			field.setRequired("N");
			field.setStatus("visible");

			fields.add(field);

			section5.setFields(fields);
			sections.add(section5);

			form.setSections(sections);
		} else if (env.getProperty("config.form-names.sub-flow").equals(idForm)) {
			Section section6 = new Section();
			section6.setIdSection("section6");
			section6.setSubtitle("Aprobador suplente");
			section6.setDescription(
					"Seleccione del siguiente listado al usuario que recibirá las solicitudes cuando no este disponible.");

			fields = new ArrayList<>();
			Field<Value> field = new Field<>();
			field.setFormat(null);
			field.setId("ddlSuplente");
			field.setLabel("Seleccione:");
			field.setRequired("N");
			field.setStatus("visible");

			fields.add(field);

			section6.setFields(fields);
			sections.add(section6);

			Section section7 = new Section();
			section7.setIdSection("section7");
			section7.setSubtitle("");
			section7.setDescription("Seleccione del siguiente listado los flujos asignados al aprobador.");

			fields = new ArrayList<>();

			field = new Field<>();
			field.setFormat(null);
			field.setId("slt_Aprb");
			field.setLabel("Seleccione:");
			field.setRequired("N");
			field.setStatus("visible");

			fields.add(field);

			field = new Field<>();
			field.setId("ddlAprb");
			field.setRequired("Y");
			field.setStatus("visible");
			fields.add(field);

			field = new Field<>();
			field.setId("btnaddAprb");
			field.setStatus("visible");
			fields.add(field);

			field = new Field<>();
			field.setId("btnremAprb");
			field.setStatus("visible");
			fields.add(field);

			section7.setFields(fields);
			sections.add(section7);

			form.setSections(sections);
		}
		return form;
	}

	public Form retrievePartnerListCreationUser(String user) {
		Form form = new Form();

		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg;

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setDescription("Seleccione del siguiente listado los aliados que desee asignar al nuevo usuario");


		Field<Value> partnerList = new Field<>();
		partnerList.setId("slt_commmerce");
		partnerList.setLabel("Aliado:");
		partnerList.setRequired("N");
		partnerList.setStatus("visible");

		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe Seleccionar un aliado."));
		Field<Value> selectedPartners = new Field<>();
		selectedPartners.setId("ddAliados");
		selectedPartners.setRequired("Y");

		Field<Value> btnPlus = new Field<>();
		btnPlus.setId("addCmr");

		Field<Value> btnMinus = new Field<>();
		btnMinus.setId("remCmr");

		selectedPartners.setStatus("visible");
		btnPlus.setStatus("visible");
		btnMinus.setStatus("visible");

		fields.add(partnerList);
		selectedPartners.setMessages(msg);
		selectedPartners.setPlaceholder("Aliados seleccionados");
		fields.add(selectedPartners);

		fields.add(btnPlus);
		fields.add(btnMinus);

		section1.setFields(fields);

		sections.add(section1);

		form.setSections(sections);

		return form;
	}

	public Form retrieveUserInfo(String idForm, String userType) {
		Form form = new Form();

		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();

		msg.add(new Message(notExists, "El usuario que quiere modificar no existe"));
		msg.add(new Message(inputMis, "Un valor requerido hace falta"));
		msg.add(new Message(apprvExists,"Ya existe un aprobador para el área y flujo/aliado seleccionado"));
		form.setMessages(msg);

		Section section1 = new Section();
		section1.setIdSection("section2");
		Field<Value> firstName = new Field<>();
		firstName.setId("txtPNombre");
		firstName.setRequired("Y");
		firstName.setStatus("visible");
		firstName.setPlaceholder("Primer Nombre");
		firstName.setLabel("Primer Nombre:");
		firstName.setFormat("^[a-zA-Z ]*$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		msg.add(new Message(reqMe, "Debe escribir un nombre"));
		firstName.setMessages(msg);

		fields.add(firstName);

		Field<Value> secondName = new Field<>();
		secondName.setId("txtSNombre");
		secondName.setRequired("N");
		secondName.setStatus("visible");
		secondName.setPlaceholder("Segundo Nombre");
		secondName.setLabel("Segundo Nombre:");
		secondName.setFormat("^[a-zA-Z ]*$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		secondName.setMessages(msg);

		fields.add(secondName);

		Field<Value> lastName = new Field<>();
		lastName.setId("txtPApellido");
		lastName.setRequired("Y");
		lastName.setStatus("visible");
		lastName.setPlaceholder("Primer Apellido");
		lastName.setLabel("Primer Apellido:");
		lastName.setFormat("^[a-zA-Z ]*$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		msg.add(new Message(reqMe, "Debe escribir un apellido"));
		lastName.setMessages(msg);

		fields.add(lastName);

		Field<Value> secondLastName = new Field<>();
		secondLastName.setId("txtSApellido");
		secondLastName.setRequired("N");
		secondLastName.setStatus("visible");
		secondLastName.setPlaceholder("Segundo Apellido");
		secondLastName.setLabel("Segundo Apellido:");
		secondLastName.setFormat("^[a-zA-Z ]*$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		secondLastName.setMessages(msg);

		fields.add(secondLastName);

		Field<Value> position = new Field<>();
		position.setId("txtCargo");
		position.setRequired("N");
		position.setStatus("visible");
		position.setPlaceholder("Cargo en la Empresa");
		position.setLabel("Cargo en la Empresa:");
		position.setFormat("^[0-9a-zA-Z ]*$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Solo debe escribir letras"));
		position.setMessages(msg);

		fields.add(position);

		Field<Value> email = new Field<>();
		email.setId("txtEmailUser");
		email.setRequired("Y");
		email.setStatus("visible");
		email.setPlaceholder("Correo Electrónico");
		email.setLabel("Correo Electrónico:");
		email.setFormat("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)+$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Debe escribir un formato de correo válido"));
		msg.add(new Message(reqMe, "Debe escribir un correo electrónico"));
		email.setMessages(msg);

		fields.add(email);

		Field<Value> document = new Field<>();
		document.setId("txtDocumento");
		document.setRequired("Y");
		document.setStatus("visible");
		document.setPlaceholder("Número de Documento");
		document.setLabel("Número de Documento:");
		document.setFormat("^[a-zA-Z0-9-áéíóúñ ]*$");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Debe escribir números o letras"));
		msg.add(new Message(reqMe, "Debe escribir un número de documento"));
		document.setMessages(msg);

		fields.add(document);

		Field<Value> creationDate = new Field<>();
		creationDate.setId("txtFechaUser");
		creationDate.setRequired("N");
		creationDate.setStatus("readonly");
		creationDate.setPlaceholder("Fecha de Inscripción");
		creationDate.setLabel("Fecha de Inscripción:");
		msg = new ArrayList<>();
		msg.add(new Message(regEx, "Debe digitar una fecha en formato dd/mm/yyyy"));
		msg.add(new Message(reqMe, "Debe ingresar una fecha"));
		creationDate.setMessages(msg);

		fields.add(creationDate);

		section1.setFields(fields);

		sections.add(section1);
		// status
		Section section2 = new Section();
		section2.setIdSection("section3");
		section2.setSubtitle("Estado");
		section2.setDescription(
				"Para habilitar el nuevo usuario, seleccione la opción <i>Activo</i>. Para restringir el acceso del mismo en el portal, seleccione <i>Inactivo.</i>");
		fields = new ArrayList<>();
		Field<Value> userState = new Field<>();
		userState.setId("radEstado");
		userState.setStatus("visible");
		userState.setRequired("Y");

		fields.add(userState);
		section2.setFields(fields);
		sections.add(section2);

		// funciones
		Section section3 = new Section();
		section3.setIdSection("section4");
		section3.setSubtitle("Funciones");
		fields = new ArrayList<>();
		section3.setDescription("Seleccione del siguiente listado las funciones que desee habilitar al usuario.");
		Field<Value> functions = new Field<>();
		functions.setId("slt_rol");
		functions.setLabel("Seleccione:");
		functions.setPlaceholder("Funciones");
		functions.setStatus("visible");

		fields.add(functions);

		Field<Value> selectedFunctions = new Field<>();
		selectedFunctions.setId("ddlRoles");
		selectedFunctions.setPlaceholder("Funciones seleccionadas");
		selectedFunctions.setStatus("visible");

		fields.add(selectedFunctions);

		Field<Value> btnAddFnc = new Field<>();
		btnAddFnc.setId("btn_Add");
		btnAddFnc.setLabel("+");
		btnAddFnc.setStatus("visible");
		fields.add(btnAddFnc);

		Field<Value> btnRemFnc = new Field<>();
		btnRemFnc.setId("btn_Rem");
		btnRemFnc.setLabel("-");
		btnRemFnc.setStatus("visible");
		fields.add(btnRemFnc);

		section3.setFields(fields);
		sections.add(section3);

		if (idForm.equals(env.getProperty("config.form-names.info-user-group"))) {
			// administradores de aliados (tipo grupo)
			Section section4 = new Section();
			section4.setIdSection("section5");
			section4.setSubtitle("Administración de Aliados");
			section4.setDescription("Seleccione del siguiente listado los aliados que desee asignar al usuario.");
			// section4.setSubtitle("Administración de aliados");
			// section4.setDescription("Seleccione del siguiente listado los
			// aliados que desee asignar al usuario.");
			fields = new ArrayList<>();

			Field<Value> cmbPartner = new Field<>();
			cmbPartner.setId("slt_aliados");
			cmbPartner.setLabel("Seleccione:");
			cmbPartner.setStatus("visible");
			cmbPartner.setPlaceholder("Aliados");

			fields.add(cmbPartner);

			Field<Value> ddAliados = new Field<>();
			ddAliados.setId("ddAliadosSelect");
			ddAliados.setStatus("visible");
			ddAliados.setPlaceholder("Aliados Seleccionados");
			fields.add(ddAliados);

			Field<Value> btnAddPar = new Field<>();
			btnAddPar.setId("addAliado");
			btnAddPar.setLabel("+");
			btnAddPar.setStatus("visible");
			fields.add(btnAddPar);

			Field<Value> btnRemPar = new Field<>();
			btnRemPar.setId("remAliado");
			btnRemPar.setLabel("-");
			btnRemPar.setStatus("visible");
			fields.add(btnRemPar);

			section4.setFields(fields);
			sections.add(section4);

		}

		if (idForm.equals(env.getProperty("config.form-names.info-user-approve-flow"))
				|| idForm.equals(env.getProperty("config.form-names.info-user-approve-partner"))) {

			// aprobadores
			Section section5 = new Section();
			section5.setIdSection("section6");
			section5.setSubtitle("Tipo de Aprobador");
			section5.setDescription(
					"Seleccione del siguiente listado el tipo de aprobador que se asignará al usuario.");
			fields = new ArrayList<>();

			Field<Value> AproveType = new Field<>();
			AproveType.setId("ddlAreaInfo");
			AproveType.setStatus("visible");
			AproveType.setLabel("Tipo de Aprobador:");
			AproveType.setPlaceholder("Tipo de Aprobador");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe ingresar un tipo de aprobador"));
			AproveType.setMessages(msg);
			fields.add(AproveType);

			Field<Value> field = new Field<>();
			field.setId("chbxOutOffice");
			field.setStatus("visible");
			field.setLabel("Aprobador ausente");
			field.setPlaceholder("Aprobador ausente.");

			fields.add(field);

			section5.setFields(fields);
			sections.add(section5);

			Section section6 = new Section();
			section6.setIdSection("section7");
			section6.setSubtitle("Aprobador Suplente");
			section6.setDescription(
					"Seleccione del siguiente listado al usuario que recibirá las solicitudes cuando no este disponible.");

			fields = new ArrayList<>();

			Field<Value> SubsCombo = new Field<>();
			SubsCombo.setId("ddlSuplenteInfo");
			SubsCombo.setStatus("visible");
			SubsCombo.setLabel("Suplente:");
			SubsCombo.setPlaceholder("Suplente");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe ingresar un suplente"));
			AproveType.setMessages(msg);
			fields.add(SubsCombo);

			section6.setFields(fields);
			sections.add(section6);

			if (idForm.equals(env.getProperty("config.form-names.info-user-approve-partner"))) {
				Section section7 = new Section();
				section7.setIdSection("section8");
				section7.setDescription("Seleccione del siguiente listado los comercios asignados al aprobador");
				fields = new ArrayList<>();

				Field<Value> aprovePartners = new Field<>();
				aprovePartners.setId("ddlAprbxCmr");
				aprovePartners.setStatus("visible");
				aprovePartners.setLabel("Seleccione:");
				aprovePartners.setPlaceholder("Comercios asignados a aliados");
				msg = new ArrayList<>();
				msg.add(new Message(reqMe, "Debe ingresar un comercio"));
				aprovePartners.setMessages(msg);
				fields.add(aprovePartners);

				Field<Value> aprovePartnersSelected = new Field<>();
				aprovePartnersSelected.setId("ddlCmrxAprb");
				aprovePartnersSelected.setStatus("visible");
				aprovePartnersSelected.setPlaceholder("Comercios asignados a aliados seleccionados");
				msg = new ArrayList<>();
				msg.add(new Message(reqMe, "Debe ingresar un comercio"));
				aprovePartnersSelected.setMessages(msg);
				fields.add(aprovePartnersSelected);

				Field<Value> btnAddPar = new Field<>();
				btnAddPar.setId("btnaddCmr");
				btnAddPar.setLabel("+");
				btnAddPar.setStatus("visible");
				fields.add(btnAddPar);

				Field<Value> btnRemPar = new Field<>();
				btnRemPar.setId("btnremCmr");
				btnRemPar.setLabel("-");
				btnRemPar.setStatus("visible");
				fields.add(btnRemPar);

				section7.setFields(fields);
				sections.add(section7);

			} else if (idForm.equals(env.getProperty("config.form-names.info-user-approve-flow"))) {

				Section section7 = new Section();
				section7.setIdSection("section9");
				section7.setDescription("Seleccione del siguiente listado los flujos asignados al aprobador");
				fields = new ArrayList<>();

				Field<Value> aproveFlowns = new Field<>();
				aproveFlowns.setId("ddlFlujosInfo");
				aproveFlowns.setStatus("visible");
				aproveFlowns.setLabel("Seleccione:");
				aproveFlowns.setPlaceholder("Flujos asignados a aliados");
				msg = new ArrayList<>();
				msg.add(new Message(reqMe, "Debe ingresar un flujo"));
				aproveFlowns.setMessages(msg);
				fields.add(aproveFlowns);

				Field<Value> aproveFlownsSelected = new Field<>();
				aproveFlownsSelected.setId("ddlAprbxFlu");
				aproveFlownsSelected.setStatus("visible");
				aproveFlownsSelected.setPlaceholder("Flujos asignados a aliados seleccionados");
				msg = new ArrayList<>();
				msg.add(new Message(reqMe, "Debe ingresar un flujo"));
				aproveFlownsSelected.setMessages(msg);
				fields.add(aproveFlownsSelected);

				Field<Value> btnAddPar = new Field<>();
				btnAddPar.setId("btnAddFlu");
				btnAddPar.setLabel("+");
				btnAddPar.setStatus("visible");
				fields.add(btnAddPar);

				Field<Value> btnRemPar = new Field<>();
				btnRemPar.setId("btnRemFlu");
				btnRemPar.setLabel("-");
				btnRemPar.setStatus("visible");
				fields.add(btnRemPar);

				section7.setFields(fields);
				sections.add(section7);
			}

		}
		// seccion de boton
		Section section8 = new Section();
		section8.setIdSection("section10");
		fields = new ArrayList<>();
		Field<Value> btnSave = new Field<>();
		btnSave.setId("btt_Guardar");
		btnSave.setLabel("Guardar");
		btnSave.setStatus("visible");
		fields.add(btnSave);
		section8.setFields(fields);
		sections.add(section8);

		form.setSections(sections);

		return form;
	}

	public Form retrieveAreasApproveTypeForm(String userType) {
		Form form = new Form();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg;
		Section section5 = new Section();
		section5.setIdSection("section6");
		section5.setSubtitle("Tipo de Aprobador");
		section5.setDescription("Seleccione del siguiente listado el tipo de aprobador que se asignará al usuario.");

		Field<Value> aproveType = new Field<>();
		aproveType.setId("ddlAreaInfo");
		aproveType.setStatus("hidden");
		aproveType.setLabel("Tipo de Aprobador:");
		aproveType.setPlaceholder("Tipo de Aprobador");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe ingresar un tipo de aprobador"));
		aproveType.setMessages(msg);
		fields.add(aproveType);

		section5.setFields(fields);
		sections.add(section5);

		form.setSections(sections);

		return form;

	}

	public Form retrieveAreasApproveForm(String idForm) {
		Form form = new Form();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg;

		Section section6 = new Section();
		section6.setIdSection("section7");
		section6.setSubtitle("Aprobador Suplente");
		section6.setDescription(
				"Seleccione del siguiente listado al usuario que recibirá las solicitudes cuando no este disponible.");

		Field<Value> subsCombo = new Field<>();
		subsCombo.setId("ddlSuplenteInfo");
		subsCombo.setStatus("visible");
		subsCombo.setLabel("Suplente:");
		subsCombo.setPlaceholder("Suplente");
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe ingresar un suplente"));
		subsCombo.setMessages(msg);
		fields.add(subsCombo);

		section6.setFields(fields);
		sections.add(section6);

		if (idForm.equals(env.getProperty("config.form-names.approver-flow"))) {
			Section section7 = new Section();
			section7.setIdSection("section9");
			section7.setDescription("Seleccione del siguiente listado los flujos asignados al aprobador");
			fields = new ArrayList<>();

			Field<Value> aproveFlowns = new Field<>();
			aproveFlowns.setId("ddlFlujosInfo");
			aproveFlowns.setStatus("visible");
			aproveFlowns.setLabel("Seleccione:");
			aproveFlowns.setPlaceholder("Flujos asignados a aliados");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe ingresar un flujo"));
			aproveFlowns.setMessages(msg);
			fields.add(aproveFlowns);

			Field<Value> aproveFlownsSelected = new Field<>();
			aproveFlownsSelected.setId("ddlAprbxFlu");
			aproveFlownsSelected.setStatus("visible");
			aproveFlownsSelected.setPlaceholder("Flujos asignados a aliados seleccionados");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe ingresar un flujo"));
			aproveFlownsSelected.setMessages(msg);
			fields.add(aproveFlownsSelected);

			Field<Value> btnAddPar = new Field<>();
			btnAddPar.setId("btnAddFlu");
			btnAddPar.setLabel("+");
			btnAddPar.setStatus("visible");
			fields.add(btnAddPar);

			Field<Value> btnRemPar = new Field<>();
			btnRemPar.setId("btnRemFlu");
			btnRemPar.setLabel("-");
			btnRemPar.setStatus("visible");
			fields.add(btnRemPar);

			section7.setFields(fields);
			sections.add(section7);

			form.setSections(sections);
		} else if (idForm.equals(env.getProperty("config.form-names.approver-partner"))) {
			Section section7 = new Section();
			section7.setIdSection("section8");
			section7.setDescription("Seleccione del siguiente listado los comercios asignados al aprobador");
			fields = new ArrayList<>();

			Field<Value> aprovePartners = new Field<>();
			aprovePartners.setId("ddlAprbxCmr");
			aprovePartners.setStatus("visible");
			aprovePartners.setLabel("Seleccione:");
			aprovePartners.setPlaceholder("Comercios asignados a aliados");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe ingresar un comercio"));
			aprovePartners.setMessages(msg);
			fields.add(aprovePartners);

			Field<Value> aprovePartnersSelected = new Field<>();
			aprovePartnersSelected.setId("ddlCmrxAprb");
			aprovePartnersSelected.setStatus("visible");
			aprovePartnersSelected.setPlaceholder("Comercios asignados a aliados seleccionados");
			msg = new ArrayList<>();
			msg.add(new Message(reqMe, "Debe ingresar un comercio"));
			aprovePartnersSelected.setMessages(msg);
			fields.add(aprovePartnersSelected);

			Field<Value> btnAddPar = new Field<>();
			btnAddPar.setId("btnaddCmr");
			btnAddPar.setLabel("+");
			btnAddPar.setStatus("visible");
			fields.add(btnAddPar);

			Field<Value> btnRemPar = new Field<>();
			btnRemPar.setId("btnremCmr");
			btnRemPar.setLabel("-");
			btnRemPar.setStatus("visible");
			fields.add(btnRemPar);

			section7.setFields(fields);
			sections.add(section7);

			form.setSections(sections);
		}

		return form;

	}*/



	/*public Form retrieveHistRequest() {
		Form formPojo = new Form();
		List<Message> msg = new ArrayList<>();
		formPojo.setTitle("Historial de solicitudes");

		msg.add(new Message(reqMe, "No hay solicitudes ingresadas"));
		formPojo.setMessages(msg);
		List<Section> sections = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");

		List<Field<Value>> fields = new ArrayList<>();
		formPojo.setMessages(msg);
		Field<Value> tablaHist = new Field<>();
		tablaHist.setAction(null);
		tablaHist.setFormat(null);
		tablaHist.setId("reqHist");
		tablaHist.setLabel("");
		tablaHist.setMaxLength(null);
		tablaHist.setType("");
		tablaHist.setStatus("visible");

		fields.add(tablaHist);
		section1.setFields(fields);
		sections.add(section1);

		formPojo.setSections(sections);
		return formPojo;

	}

	public Form retrieveRequestApprovePartner() {
		Form formPojo = new Form();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();

		formPojo.setTitle("Solicitud de Aprobación");			
		formPojo.setMessages(msg);

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setSubtitle("El aliado ha actualizado la siguiente información");
		
		Field<Value> lblEstado = new Field<>();		
		lblEstado.setId("lblEstado");			
		lblEstado.setStatus("visible");		
		fields.add(lblEstado);
		
		Field<Value> lblFLujo = new Field<>();		
		lblFLujo.setId("lblNomFlujo");			
		lblFLujo.setStatus("visible");		
		fields.add(lblFLujo);
		
		Field<Value> btnRegresar = new Field<>();
		btnRegresar.setAction(null);
		btnRegresar.setFormat(null);
		btnRegresar.setId("btnRegresaSol");
		btnRegresar.setLabel("Regresar a historial");
		btnRegresar.setMaxLength(0);
		btnRegresar.setRequired(null);
		btnRegresar.setStatus("visible");
		btnRegresar.setType("");
		fields.add(btnRegresar);
		
		Field<Value> lblNomAliado = new Field<>();		
		lblNomAliado.setId("lblNomAliado");			
		lblNomAliado.setStatus("visible");		
		fields.add(lblNomAliado);
		
		Field<Value> imgAct = new Field<>();
		imgAct.setAction(null);
		imgAct.setFormat(null);
		imgAct.setId("imgLogoAp");
		imgAct.setLabel(null);
		imgAct.setMaxLength(null);
		imgAct.setRequired("N");
		imgAct.setStatus("hidden");
		imgAct.setType("empty");

		fields.add(imgAct);

		Field<Value> imgAnt = new Field<>();
		imgAnt.setAction(null);
		imgAnt.setFormat(null);
		imgAnt.setId("imgLogoAnt");
		imgAnt.setLabel("Logo Anterior");
		imgAnt.setMaxLength(null);
		imgAnt.setRequired("N");
		imgAnt.setStatus("hidden");
		imgAnt.setType("");
		
		fields.add(imgAnt);

		Field<Value> imgNew = new Field<>();
		imgNew.setAction(null);
		imgNew.setFormat(null);
		imgNew.setId("imgLogoNuevo");
		imgNew.setLabel("Logo Nuevo");
		imgNew.setMaxLength(null);
		imgNew.setRequired("N");
		imgNew.setStatus("hidden");
		imgNew.setType("");

		fields.add(imgNew);

		Field<Value> txtIdAp = new Field<>();
		txtIdAp.setAction(null);
		txtIdAp.setFormat(null);
		txtIdAp.setId("txtIdAp");
		txtIdAp.setLabel("ID Aliado:");
		txtIdAp.setPlaceholder("");
		txtIdAp.setMaxLength(5);
		txtIdAp.setRequired("Y");
		txtIdAp.setStatus("visible");
		txtIdAp.setType("");

		fields.add(txtIdAp);

		Field<Value> txtNombrecAp = new Field<>();
		txtNombrecAp.setAction(null);
		txtNombrecAp.setFormat(null);
		txtNombrecAp.setId("txtNombrecAp");
		txtNombrecAp.setLabel("Nombre Comercial:");
		txtNombrecAp.setPlaceholder("");		
		txtNombrecAp.setMaxLength(5);
		txtNombrecAp.setRequired("Y");
		txtNombrecAp.setStatus("readonly");
		txtNombrecAp.setType("");

		fields.add(txtNombrecAp);

		Field<Value> ddlConsoAp = new Field<>();
		msg = new ArrayList<>();
		ddlConsoAp.setAction(null);
		ddlConsoAp.setFormat(null);
		ddlConsoAp.setId("ddlConsoAp");
		ddlConsoAp.setLabel("Grupo:");
		ddlConsoAp.setMessages(msg);
		ddlConsoAp.setMaxLength(null);
		ddlConsoAp.setRequired("N");
		ddlConsoAp.setStatus("readonly");
		ddlConsoAp.setType("partnerDetailCmb");

		fields.add(ddlConsoAp);

		Field<Value> txtTelAp = new Field<>();
		txtTelAp.setAction(null);
		txtTelAp.setFormat("");
		txtTelAp.setId("txtTelAp");
		txtTelAp.setLabel("Teléfono:");
		txtTelAp.setPlaceholder("");
		txtTelAp.setMessages(msg);
		txtTelAp.setMaxLength(15);
		txtTelAp.setRequired("N");
		txtTelAp.setStatus("readonly");
		txtTelAp.setType("empty");

		fields.add(txtTelAp);

		Field<Value> txtEmailAp = new Field<>();
		txtEmailAp.setAction(null);
		txtEmailAp.setFormat("");
		txtEmailAp.setId("txtEmailAp");
		txtEmailAp.setLabel("Email:");
		txtEmailAp.setPlaceholder("");
		txtEmailAp.setMessages(msg);
		txtEmailAp.setMaxLength(40);
		txtEmailAp.setRequired("N");
		txtEmailAp.setStatus("readonly");
		txtEmailAp.setType("empty");

		fields.add(txtEmailAp);

		Field<Value> txtWebPageAp = new Field<>();
		txtWebPageAp.setAction(null);
		txtWebPageAp.setFormat("");
		txtWebPageAp.setId("txtWebPageAp");
		txtWebPageAp.setLabel("Página Web:");
		txtWebPageAp.setPlaceholder("");
		txtWebPageAp.setMessages(msg);
		txtWebPageAp.setMaxLength(40);
		txtWebPageAp.setRequired("N");
		txtWebPageAp.setStatus("readonly");
		txtWebPageAp.setType("empty");

		fields.add(txtWebPageAp);

		Field<Value> txtRazonsAp = new Field<>();
		txtRazonsAp.setAction(null);
		txtRazonsAp.setFormat(null);
		txtRazonsAp.setId("txtRazonsAp");
		txtRazonsAp.setLabel("Razón social:");
		txtRazonsAp.setMaxLength(200);
		txtRazonsAp.setRequired("N");
		txtRazonsAp.setStatus("readonly");
		txtRazonsAp.setType("empty");

		fields.add(txtRazonsAp);

		Field<Value> ddlCategoriaAp = new Field<>();
		ddlCategoriaAp.setAction(null);
		ddlCategoriaAp.setFormat(null);
		ddlCategoriaAp.setId("ddlCategoriaAp");
		ddlCategoriaAp.setLabel("Categoría");
		ddlCategoriaAp.setMaxLength(200);
		ddlCategoriaAp.setRequired("Y");
		ddlCategoriaAp.setStatus("readonly");
		ddlCategoriaAp.setType("empty");

		fields.add(ddlCategoriaAp);

		Field<Value> areaDescripAp = new Field<>();
		areaDescripAp.setAction(null);
		areaDescripAp.setFormat(null);
		areaDescripAp.setId("areaDescripAp");
		areaDescripAp.setLabel("Descripción del aliado:");
		areaDescripAp.setMaxLength(200);
		areaDescripAp.setRequired("N");
		areaDescripAp.setStatus("readonly");
		areaDescripAp.setType("empty");

		fields.add(areaDescripAp);
		
		Field<Value> segmentacion = new Field<>();		
		segmentacion.setId("segmentacion");			
		segmentacion.setStatus("visible");		
		fields.add(segmentacion);
						
		Field<Value> configuraciones = new Field<>();		
		configuraciones.setId("configuraciones");			
		configuraciones.setStatus("visible");		
		fields.add(configuraciones);

		Field<Value> pCmrEstadoAp = new Field<>();
		pCmrEstadoAp.setAction(null);
		pCmrEstadoAp.setFormat(null);
		pCmrEstadoAp.setId("pCmrEstadoAp");
		pCmrEstadoAp.setLabel("Estado del Comercio");
		pCmrEstadoAp.setMaxLength(null);
		pCmrEstadoAp.setRequired("Y");
		pCmrEstadoAp.setStatus("readonly");
		pCmrEstadoAp.setType("partnerRadio");

		fields.add(pCmrEstadoAp);

		section1.setFields(fields);
		sections.add(section1);

		Section section2 = new Section();
		List<Field<Value>> fields2 = new ArrayList<>();
		section2.setIdSection("section2");
		section2.setSubtitle("");

		Field<Value> pRespuesta = new Field<>();
		pRespuesta.setAction(null);
		pRespuesta.setFormat(null);
		pRespuesta.setId("pRespuesta");
		pRespuesta.setLabel("Respuesta");
		pRespuesta.setMaxLength(null);
		pRespuesta.setRequired("Y");
		pRespuesta.setStatus("visible");
		pRespuesta.setType("respuestaRadio");

		fields2.add(pRespuesta);

		Field<Value> areaComent = new Field<>();
		areaComent.setAction(null);
		areaComent.setFormat(null);
		areaComent.setId("areaDescripR");
		areaComent.setLabel("Comentarios");
		areaComent.setMaxLength(200);
		areaComent.setRequired("N");
		areaComent.setStatus("visible");
		areaComent.setType("empty");
		
		fields2.add(areaComent);
		
		Field<Value> tableApprovers = new Field<>();
		tableApprovers.setAction(null);
		tableApprovers.setFormat(null);
		tableApprovers.setId("approversTable");
		tableApprovers.setLabel("");
		tableApprovers.setMaxLength(null);
		tableApprovers.setType("");
		tableApprovers.setStatus("visible");

		fields2.add(tableApprovers);		

		section2.setFields(fields2);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		section3.setSubtitle("");
		List<Field<Value>> fields3 = new ArrayList<>();
		
		Field<Value> btnProcesar = new Field<>();
		btnProcesar.setAction(null);
		btnProcesar.setFormat(null);
		btnProcesar.setId("btnProcesarSol");
		btnProcesar.setLabel("Procesar");
		btnProcesar.setMaxLength(0);
		btnProcesar.setRequired(null);
		btnProcesar.setStatus("visible");
		btnProcesar.setType("");
		fields3.add(btnProcesar);

		section3.setFields(fields3);
		sections.add(section3);

		formPojo.setSections(sections);

		return formPojo;

	}

	public Form retrieveMyRequest() {
		Form formPojo = new Form();
		List<Message> msg = new ArrayList<>();
		formPojo.setTitle("Mis solicitudes");

		msg.add(new Message(reqMe, "No hay solicitudes ingresadas"));
		formPojo.setMessages(msg);
		List<Section> sections = new ArrayList<>();

		Section section1 = new Section();
		section1.setIdSection("section1");

		List<Field<Value>> fields = new ArrayList<>();
		formPojo.setMessages(msg);
		Field<Value> tablaHist = new Field<>();
		tablaHist.setAction(null);
		tablaHist.setFormat(null);
		tablaHist.setId("myReqHist");
		tablaHist.setLabel("");
		tablaHist.setMaxLength(null);
		tablaHist.setType("");
		tablaHist.setStatus("visible");

		fields.add(tablaHist);
		section1.setFields(fields);
		sections.add(section1);

		formPojo.setSections(sections);
		return formPojo;

	}

	public Form retrieveRequestApprovePromotion() {
		Form formPojo = new Form();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();

		formPojo.setTitle("Solicitud de Aprobación");
		
		msg.add(new Message(newPrAcc, "Nueva promoción de acumulación LM"));
		msg.add(new Message(modPrRe,"Modificación de promocion de Redención LM"));
		msg.add(new Message(newPrRe,"Nueva promocion de Redención LM"));
		msg.add(new Message(modPrAcc,"Modificación de promoción de Acumulación"));
		msg.add(new Message(approbers, "La solicitud no ha sido ingresada debido a falta de configuración de aprobadores"));
		
		msg.add(new Message(pndMe, "Solicitud Pendiente:"));
		msg.add(new Message(aprMe, "Solicitud Aprobada:"));
		formPojo.setMessages(msg);

		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setSubtitle("El aliado ha actualizado la siguiente información");

		Field<Value> lblEstado = new Field<>();		
		lblEstado.setId("lblEstado");			
		lblEstado.setStatus("visible");		
		fields.add(lblEstado);
		
		Field<Value> lblFLujo = new Field<>();
		lblFLujo.setAction(null);
		lblFLujo.setFormat(null);
		lblFLujo.setId("lblNomFlujo");
		lblFLujo.setMaxLength(0);
		lblFLujo.setRequired(null);
		lblFLujo.setStatus("visible");
		lblFLujo.setType("");
		fields.add(lblFLujo);		
		
		Field<Value> btnRegresar = new Field<>();
		btnRegresar.setAction(null);
		btnRegresar.setFormat(null);
		btnRegresar.setId("btnRegresaSol");
		btnRegresar.setLabel("Regresar a historial");
		btnRegresar.setMaxLength(0);
		btnRegresar.setRequired(null);
		btnRegresar.setStatus("visible");
		btnRegresar.setType("");
		fields.add(btnRegresar);
		
		Field<Value> lblNomAliado = new Field<>();		
		lblNomAliado.setId("lblNomAliado");			
		lblNomAliado.setStatus("visible");		
		fields.add(lblNomAliado);

		Field<Value> tipoBono = new Field<>();
		tipoBono.setAction(null);
		tipoBono.setFormat(null);
		tipoBono.setId("ddlTipoBonoAp");
		tipoBono.setLabel("Tipo de Bono:");
		tipoBono.setPlaceholder("");
		tipoBono.setMaxLength(5);
		tipoBono.setRequired(null);
		tipoBono.setStatus("readonly");
		tipoBono.setType("");

		fields.add(tipoBono);

		Field<Value> bono = new Field<>();
		msg = new ArrayList<>();
		bono.setAction(null);
		bono.setFormat(null);
		bono.setId("txtBonoAp");
		bono.setLabel("Bono:");
		bono.setMessages(msg);
		bono.setMaxLength(null);
		bono.setRequired("N");
		bono.setStatus("readonly");
		bono.setType("");
		fields.add(bono);

		Field<Value> montoMinimo = new Field<>();
		montoMinimo.setAction(null);
		montoMinimo.setFormat("");
		montoMinimo.setId("txtMontoMinAp");
		montoMinimo.setLabel("Monto Minimo:");
		montoMinimo.setPlaceholder("");
		montoMinimo.setMessages(msg);
		montoMinimo.setMaxLength(15);
		montoMinimo.setRequired("Y");
		montoMinimo.setStatus("readonly");
		montoMinimo.setType("empty");

		fields.add(montoMinimo);
		
		Field<Value> segm = new Field<>();
		segm.setAction(null);
		segm.setFormat(null);
		segm.setId("ddlTiposSegAp");
		segm.setLabel("Segmentaciones:");
		segm.setMaxLength(200);
		segm.setRequired("N");
		segm.setStatus("readonly");
		segm.setType("empty");
		fields.add(segm);
		
		Field<Value> fechaInicio = new Field<>();
		fechaInicio.setAction(null);
		fechaInicio.setFormat("");
		fechaInicio.setId("txtFechadesdeAp");
		fechaInicio.setLabel("Fecha de Inicio:");
		fechaInicio.setPlaceholder("");
		fechaInicio.setMessages(msg);
		fechaInicio.setMaxLength(40);
		fechaInicio.setRequired("N");
		fechaInicio.setStatus("readonly");
		fechaInicio.setType("empty");

		fields.add(fechaInicio);

		Field<Value> fechaHasta = new Field<>();
		fechaHasta.setAction(null);
		fechaHasta.setFormat("");
		fechaHasta.setId("txtFechahastaAp");
		fechaHasta.setLabel("Fecha de Fin:");
		fechaHasta.setPlaceholder("");
		fechaHasta.setMessages(msg);
		fechaHasta.setMaxLength(40);
		fechaHasta.setRequired("N");
		fechaHasta.setStatus("readonly");
		fechaHasta.setType("empty");

		fields.add(fechaHasta);

		Field<Value> horaIni = new Field<>();
		horaIni.setAction(null);
		horaIni.setFormat(null);
		horaIni.setId("txtHoraIniAp");
		horaIni.setLabel("Horario de Inicio:");
		horaIni.setMaxLength(200);
		horaIni.setRequired("N");
		horaIni.setStatus("readonly");
		horaIni.setType("empty");

		fields.add(horaIni);

		Field<Value> horaFin = new Field<>();
		horaFin.setAction(null);
		horaFin.setFormat(null);
		horaFin.setId("txtHoraFinAp");
		horaFin.setLabel("Horario de Fin:");
		horaFin.setMaxLength(200);
		horaFin.setRequired("N");
		horaFin.setStatus("readonly");
		horaFin.setType("empty");

		fields.add(horaFin);

		Field<Value> cCosto = new Field<>();
		cCosto.setAction(null);
		cCosto.setFormat(null);
		cCosto.setId("ddlCCostoAp");
		cCosto.setLabel("Centro de Costo:");
		cCosto.setMaxLength(200);
		cCosto.setRequired("N");
		cCosto.setStatus("readonly");
		cCosto.setType("empty");

		fields.add(cCosto);

		Field<Value> descPromo = new Field<>();
		descPromo.setAction(null);
		descPromo.setFormat(null);
		descPromo.setId("areaDescripPromoAp");
		descPromo.setLabel("Descripción de la Promoción");
		descPromo.setMaxLength(null);
		descPromo.setRequired("Y");
		descPromo.setStatus("readonly");
		descPromo.setType("");

		fields.add(descPromo);
		
		Field<Value> recurrence = new Field<>();
		recurrence.setAction(null);
		recurrence.setFormat(null);
		recurrence.setId("weekdaysAp");
		recurrence.setLabel("Recurrencia:");
		recurrence.setMaxLength(null);
		recurrence.setRequired("Y");
		recurrence.setStatus("readonly");
		recurrence.setType("");
		fields.add(recurrence);								
		
		Field<Value> status = new Field<>();
		status.setAction(null);
		status.setFormat(null);
		status.setId("estadoAp");
		status.setLabel("Estado:");
		status.setMaxLength(null);
		status.setRequired("Y");
		status.setStatus("readonly");
		status.setType("");
		fields.add(status);				
		
		Field<Value> segCli = new Field<>();
		segCli.setAction(null);
		segCli.setFormat(null);
		segCli.setId("segmentacionCliAp");
		segCli.setLabel("");
		segCli.setMaxLength(null);
		segCli.setRequired("N");
		segCli.setStatus("visible");
		segCli.setType(null);
		fields.add(segCli);
		
		Field<Value> segEst = new Field<>();
		segEst.setAction(null);
		segEst.setFormat(null);
		segEst.setId("segmentacionEstAp");
		segEst.setLabel("");
		segEst.setRequired("N");
		segEst.setStatus("visible");
		segEst.setType(null);
		fields.add(segEst);

		section1.setFields(fields);
		sections.add(section1);

		Section section2 = new Section();
		List<Field<Value>> fields2 = new ArrayList<>();
		section2.setIdSection("section2");
		section2.setSubtitle("");

		Field<Value> pRespuesta = new Field<>();
		pRespuesta.setAction(null);
		pRespuesta.setFormat(null);
		pRespuesta.setId("pRespuesta");
		pRespuesta.setLabel("Respuesta");
		pRespuesta.setMaxLength(null);
		pRespuesta.setRequired("Y");
		pRespuesta.setStatus("visible");
		pRespuesta.setType("respuestaRadio");

		fields2.add(pRespuesta);

		Field<Value> areaComent = new Field<>();
		areaComent.setAction(null);
		areaComent.setFormat(null);
		areaComent.setId("areaDescripR");
		areaComent.setLabel("Comentarios");
		areaComent.setMaxLength(200);
		areaComent.setRequired("N");
		areaComent.setStatus("visible");
		areaComent.setType("empty");

		fields2.add(areaComent);

		section2.setFields(fields2);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		section3.setSubtitle("");
		List<Field<Value>> fields3 = new ArrayList<>();

		Field<Value> tableApprovers = new Field<>();
		tableApprovers.setAction(null);
		tableApprovers.setFormat(null);
		tableApprovers.setId("approversTable");
		tableApprovers.setLabel("");
		tableApprovers.setMaxLength(null);
		tableApprovers.setType("");
		tableApprovers.setStatus("visible");

		fields3.add(tableApprovers);

		Field<Value> btnProcesar = new Field<>();
		btnProcesar.setAction(null);
		btnProcesar.setFormat(null);
		btnProcesar.setId("btnProcesarSol");
		btnProcesar.setLabel("Procesar");
		btnProcesar.setMaxLength(0);
		btnProcesar.setRequired(null);
		btnProcesar.setStatus("visible");
		btnProcesar.setType("");
		fields3.add(btnProcesar);
		
		section3.setFields(fields3);
		sections.add(section3);

		formPojo.setSections(sections);

		return formPojo;

	}
	
	
	public Form retrieveAddCashierForm(String user){
		Form formPojo = new Form();
		List<Field<Value>> fields = new ArrayList<>();
		List<Section> sections = new ArrayList<>();
		List<Message> msg = new ArrayList<>();
		
		formPojo.setTitle("Registros de cajeros");
		msg.add(new Message(parSave,"Éxito parcial. Los siguientes cajeros no pudieron ingresarse: <a id='cashError' class='cboxElement' href='#divClbInfo'>cajeros</a>"));
		msg.add(new Message(inputMis,"Un valor requerido hace falta"));
		
		formPojo.setMessages(msg);
		Section section1 = new Section();
		section1.setIdSection("section1");
		section1.setSubtitle("");
	
		Field<Value> partner = new Field<>();
		partner.setAction(null);
		partner.setFormat(null);
		partner.setId("ddlComercios");
		partner.setLabel("Aliado:");
		partner.setPlaceholder("Aliado");
		msg.add(new Message(reqMe,"Ingrese un aliado"));
		partner.setMessages(msg);
		partner.setMaxLength(null);
		partner.setRequired("Y");
		partner.setStatus("visible");
		partner.setType("");
		fields.add(partner);

		section1.setFields(fields);
		sections.add(section1);


		Section section2 = new Section();
		section2.setIdSection("section2");
		section2.setSubtitle("Formulario");
		section2.setDescription("Verifica los datos cargados para el cajero y presiona <i>Guardar.</i>");
		fields = new ArrayList<>();
		Field<Value> lmNumber = new Field<>();
		lmNumber.setAction(null);
		lmNumber.setFormat(null);
		lmNumber.setId("txtftnumCa");
		lmNumber.setLabel("No. LifeMiles:");
		lmNumber.setPlaceholder("No. LifeMiles");
		lmNumber.setMaxLength(16);
		lmNumber.setRequired("N");
		lmNumber.setStatus("visible");
		lmNumber.setType("");
		fields.add(lmNumber);

		msg = new ArrayList<>();
		
		Field<Value> docNumber = new Field<>();
		docNumber.setAction(null);
		docNumber.setFormat(null);
		docNumber.setId("txtDocumentoCa");
		msg.add( new Message(reqMe,"Ingrese un número de documento"));
		docNumber.setMessages(msg);
		docNumber.setLabel("No. Documento:");
		docNumber.setPlaceholder("No. Documento");
		docNumber.setMaxLength(20);
		docNumber.setRequired("Y");
		docNumber.setStatus("visible");
		docNumber.setType("");
		fields.add(docNumber);
		
		Field<Value> firstName = new Field<>();
		firstName.setAction(null);
		firstName.setFormat(null);
		firstName.setId("txtPnombreCa");
		firstName.setLabel("Primer Nombre:");
		firstName.setPlaceholder("Primer Nombre");
		firstName.setMaxLength(20);
		firstName.setRequired("N");
		firstName.setStatus("visible");
		firstName.setType("");
		fields.add(firstName);
		
		Field<Value> lastName = new Field<>();
		lastName.setAction(null);
		lastName.setFormat(null);
		lastName.setId("txtPapellidoCa");
		lastName.setLabel("Primer Apellido:");
		lastName.setPlaceholder("Primer Apellido");
		lastName.setMaxLength(20);
		lastName.setRequired("N");
		lastName.setStatus("visible");
		lastName.setType("");
		fields.add(lastName);

		Field<Value> empNumber = new Field<>();
		empNumber.setAction(null);
		empNumber.setFormat(null);
		empNumber.setId("txtCodempleadoCa");
		empNumber.setLabel("Cod. Empleado:");
		empNumber.setPlaceholder("Cod. Empleado");
		empNumber.setMaxLength(20);
		empNumber.setRequired("N");
		empNumber.setStatus("visible");
		empNumber.setType("");
		fields.add(empNumber);


		Field<Value> btnSave = new Field<>();
		btnSave.setAction(null);
		btnSave.setFormat(null);
		btnSave.setId("btnSave");
		btnSave.setLabel("Guardar");

		btnSave.setMaxLength(null);
		btnSave.setRequired("N");
		btnSave.setStatus("visible");
		btnSave.setType("");
		fields.add(btnSave);

		section2.setFields(fields);
		sections.add(section2);

		Section section3 = new Section();
		section3.setIdSection("section3");
		section3.setSubtitle("Archivo");
		section3.setDescription("Agregar cajeros por archivo");

		fields = new ArrayList<>();

		Field<Value> lblFile = new Field<>();
		lblFile.setId("lblFile");
		lblFile.setLabel("Para agregar cajeros al comercio seleccionado, presione <i>Adjuntar</i> y seleccione el archivo de Excel con la <a id='ClbSuc' class='Colorbox cboxElement' href='#divClbSuc'> estructura definida </a>.<a href='Filestmp/Layout_Cajeros.xls' target='_blank'> Descargar Layout</a>");
		lblFile.setStatus("visible");
		fields.add(lblFile);

		Field<Value> fileCas = new Field<>();
		msg = new ArrayList<>();
		msg.add(new Message(reqMe, "Debe seleccionar un archivo excel"));
		msg.add(new Message(noSup, "Su navegador no soporta el almacenamiento de archivos"));
		fileCas.setMessages(msg);
		fileCas.setAction(null);
		fileCas.setFormat(null);
		fileCas.setId("FileCaj");
		fileCas.setLabel("Adjuntar...");
		fileCas.setDefaultValue("No ha seleccionado ningún archivo");
		fileCas.setMaxLength(null);
		fileCas.setRequired("N");
		fileCas.setStatus("visible");
		fileCas.setType("");

		fields.add(fileCas);

		Field<Value> lblConf = new Field<>();
		lblConf.setId("lblConf");
		lblConf.setLabel("Asegúrese que el archivo cargado sea el correcto y presione <i>Guardar</i> para que sean efectivos los cambios.");
		lblConf.setStatus("visible");
		fields.add(lblConf);

		Field<Value> btnFileLoad = new Field<>();
		btnFileLoad.setAction(null);
		btnFileLoad.setFormat(null);
		btnFileLoad.setId("btnFileLoad");
		btnFileLoad.setLabel("Guardar");

		btnFileLoad.setMaxLength(null);
		btnFileLoad.setRequired("N");
		btnFileLoad.setStatus("visible");
		btnFileLoad.setType("");
		fields.add(btnFileLoad);


		section3.setFields(fields);
		sections.add(section3);

		formPojo.setSections(sections);

		return formPojo;
	}
*/
}
