package com.loyalty.data.fields;

public interface IFieldData<T> {
	//public String retrieveUserType(String partnerCode);
	public T retrieveFormFields(String form, String user);
}	
