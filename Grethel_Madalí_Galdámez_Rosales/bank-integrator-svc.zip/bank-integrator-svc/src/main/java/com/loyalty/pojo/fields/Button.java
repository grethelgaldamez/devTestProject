package com.loyalty.pojo.fields;

public class Button {
	private String extend;
	private String title;
	
	public Button() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Button(String extend, String title) {
		super();
		this.extend = extend;
		this.title = title;
	}
	public String getExtend() {
		return extend;
	}
	public void setExtend(String extend) {
		this.extend = extend;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
