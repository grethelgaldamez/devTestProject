package com.loyalty.pojo.fields;

import java.util.List;

public class CheckBoxValue extends Value {
	private List<DataCheck> items;

	public List<DataCheck> getItems() {
		return items;
	}

	public void setItems(List<DataCheck> items) {
		this.items = items;
	}
	
}
