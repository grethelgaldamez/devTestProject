package com.loyalty.pojo.fields;

import java.util.List;

public class Data {
	private String id;
	private String name;
	private List<Attr> attrs;

	public Data(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Data(String id, String name, List<Attr> attrs) {
		super();
		this.id = id;
		this.name = name;
		this.attrs = attrs;
	}
	
	public List<Attr> getAttrs() {
		return attrs;
	}

	public void setAttrs(List<Attr> attrs) {
		this.attrs = attrs;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
