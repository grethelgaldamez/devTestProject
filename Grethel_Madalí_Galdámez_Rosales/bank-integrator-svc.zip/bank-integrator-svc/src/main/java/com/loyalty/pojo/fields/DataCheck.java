package com.loyalty.pojo.fields;

public class DataCheck {
	private String label;
	private String value;
	private boolean check;

	public DataCheck(String label, String value, boolean check) {
		super();
		this.label = label;
		this.value = value;
		this.check = check;
	}
	public DataCheck(){
		super();
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public boolean isCheck() {
		return check;
	}
	public void setCheck(boolean check) {
		this.check = check;
	}

}
