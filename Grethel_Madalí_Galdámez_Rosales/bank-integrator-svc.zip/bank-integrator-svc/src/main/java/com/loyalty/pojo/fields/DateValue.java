package com.loyalty.pojo.fields;

public class DateValue extends Value{
	String dateFormat;
	Boolean changeMonth;
	Boolean changeYear;
	String minDate;
	String maxDate;
	String yearRange;
	
	
	public String getYearRange() {
		return yearRange;
	}
	public void setYearRange(String yearRange) {
		this.yearRange = yearRange;
	}
	public String getDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}	
	public Boolean getChangeMonth() {
		return changeMonth;
	}
	public void setChangeMonth(Boolean changeMonth) {
		this.changeMonth = changeMonth;
	}
	public Boolean getChangeYear() {
		return changeYear;
	}
	public void setChangeYear(Boolean changeYear) {
		this.changeYear = changeYear;
	}
	public String getMinDate() {
		return minDate;
	}
	public void setMinDate(String minDate) {
		this.minDate = minDate;
	}
	public String getMaxDate() {
		return maxDate;
	}
	public void setMaxDate(String maxDate) {
		this.maxDate = maxDate;
	}
		
}
