package com.loyalty.pojo.fields;

import com.loyalty.pojo.svc.gantt.ObjectGantt;

public class GanttValue extends Value{

	private ObjectGantt gantt;

	public ObjectGantt getGantt() {
		return gantt;
	}

	public void setGantt(ObjectGantt gantt) {
		this.gantt = gantt;
	}
	
	
}
