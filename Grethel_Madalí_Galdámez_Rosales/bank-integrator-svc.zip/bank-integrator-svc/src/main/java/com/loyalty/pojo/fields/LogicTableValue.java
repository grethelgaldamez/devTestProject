package com.loyalty.pojo.fields;

import java.util.List;

import com.loyalty.pojo.fields.table.Language;

public class LogicTableValue extends Value{
	List<LogicColumn> columns;
	List<RowLogic> rows;
	private int pageLength;
	private Boolean ordering; 
	private Boolean lengthChange; //habilitar la cantidad de datos que se pueden ver por pagina
	private Language language;
	private Boolean searching;
	private String pagingType;
	private List<Object[]> order;
	
	public List<Object[]> getOrder() {
		return order;
	}


	public void setOrder(List<Object[]> order) {
		this.order = order;
	}


	public List<LogicColumn> getColumns() {
		return columns;
	}
	
	
	public LogicTableValue() {
		super();
	}


	public LogicTableValue(List<LogicColumn> columns, List<RowLogic> rows) {
		super();
		this.columns = columns;
		this.rows = rows;
	}


	public void setColumns(List<LogicColumn> columns) {
		this.columns = columns;
	}
	public List<RowLogic> getRows() {
		return rows;
	}
	public void setRows(List<RowLogic> rows) {
		this.rows = rows;
	}


	public int getPageLength() {
		return pageLength;
	}


	public void setPageLength(int pageLength) {
		this.pageLength = pageLength;
	}

	public Boolean getOrdering() {
		return ordering;
	}


	public void setOrdering(Boolean ordering) {
		this.ordering = ordering;
	}


	public Boolean getLengthChange() {
		return lengthChange;
	}


	public void setLengthChange(Boolean lengthChange) {
		this.lengthChange = lengthChange;
	}


	public Boolean getSearching() {
		return searching;
	}


	public void setSearching(Boolean searching) {
		this.searching = searching;
	}


	public Language getLanguage() {
		return language;
	}


	public void setLanguage(Language language) {
		this.language = language;
	}


	public String getPagingType() {
		return pagingType;
	}


	public void setPagingType(String pagingType) {
		this.pagingType = pagingType;
	}			
	
}
