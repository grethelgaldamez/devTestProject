package com.loyalty.pojo.fields;

public class Message {
	private String idMessage;
	private String nomMessage;
	public String getIdMessage() {
		return idMessage;
	}
	public void setIdMessage(String idMessage) {
		this.idMessage = idMessage;
	}
	public String getNomMessage() {
		return nomMessage;
	}
	public void setNomMessage(String nomMessage) {
		this.nomMessage = nomMessage;
	}
	
	public Message(String idMessage, String nomMessage) {
		super();
		this.idMessage = idMessage;
		this.nomMessage = nomMessage;
	}
	
	public Message() {
		super();
	}	
	
}
