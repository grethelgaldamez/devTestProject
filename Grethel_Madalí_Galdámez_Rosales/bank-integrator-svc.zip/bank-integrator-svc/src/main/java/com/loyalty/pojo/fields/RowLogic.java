package com.loyalty.pojo.fields;

import java.util.List;

public class RowLogic {
	private List<RowLogicDetail> rowLogicDetail;

	
	
	public RowLogic() {
		super();
	}

	public RowLogic(List<RowLogicDetail> rowLogicDetail) {
		super();
		this.rowLogicDetail = rowLogicDetail;
	}

	public List<RowLogicDetail> getRowLogicDetail() {
		return rowLogicDetail;
	}

	public void setRowLogicDetail(List<RowLogicDetail> rowLogicDetail) {
		this.rowLogicDetail = rowLogicDetail;
	}
	
	
	
}
