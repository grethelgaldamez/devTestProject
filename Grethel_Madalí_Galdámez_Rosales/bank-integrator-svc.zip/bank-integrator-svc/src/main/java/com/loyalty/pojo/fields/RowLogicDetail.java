package com.loyalty.pojo.fields;

public class RowLogicDetail {
	private String title;
	private String state;
	private String value;
	
	
	
	public RowLogicDetail() {
		super();
	}
	
	
	public RowLogicDetail(String title, String state, String value) {
		super();
		this.title = title;
		this.state = state;
		this.value = value;
	}


	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	

}
