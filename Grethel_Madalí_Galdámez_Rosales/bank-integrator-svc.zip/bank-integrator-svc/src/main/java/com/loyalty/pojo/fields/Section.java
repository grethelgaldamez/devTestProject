package com.loyalty.pojo.fields;

import java.util.List;

public class Section {
	private String idSection;
	private String subtitle;
	private String description;
	private List<Field<Value>> fields;

	public String getIdSection() {
		return idSection;
	}

	public void setIdSection(String idSection) {
		this.idSection = idSection;
	}
	
	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Field<Value>> getFields() {
		return fields;
	}

	public void setFields(List<Field<Value>> fields) {
		this.fields = fields;
	}
}
