package com.loyalty.pojo.fields;

import java.util.ArrayList;
import java.util.List;

import com.loyalty.pojo.fields.table.Language;

public class TableValue extends Value {
	private List<Column> columns;
	private List<String[]> data;
	private int pageLength;
	private Boolean ordering; 
	private Boolean lengthChange; //habilitar la cantidad de datos que se pueden ver por pagina
	private Boolean paging;
	private Language language;	
	private Boolean searching;	
	private String pagingType;
	private List<Object[]> order;
	private List<Button> buttons;
	private String dom;
	
	public List<Object[]> getOrder() {
		return order;
	}
	public void setOrder(List<Object[]> order) {
		this.order = order;
	}
	public TableValue() {
		super();
		this.buttons = new ArrayList<>();
		this.paging = false;
		this.dom = "lfrtip";
	}
	public TableValue(List<Column> columns, List<String[]> data) {
		super();
		this.columns = columns;
		this.data = data;
	}
	public List<Column> getColumns() {
		return columns;
	}
	public void setColumns(List<Column> columns) {
		this.columns = columns;
	}
	public List<String[]> getData() {
		return data;
	}
	public void setData(List<String[]> data) {
		this.data = data;
	}
	public int getPageLength() {
		return pageLength;
	}
	public void setPageLength(int pageLength) {
		this.pageLength = pageLength;
	}	
	public Boolean getOrdering() {
		return ordering;
	}
	public void setOrdering(Boolean ordering) {
		this.ordering = ordering;
	}
	public Boolean getLengthChange() {
		return lengthChange;
	}
	public void setLengthChange(Boolean lengthChange) {
		this.lengthChange = lengthChange;
	}
	public Language getLanguage() {
		return language;
	}
	public void setLanguage(Language language) {
		this.language = language;
	}
	public Boolean getSearching() {
		return searching;
	}
	public void setSearching(Boolean searching) {
		this.searching = searching;
	}
	public String getPagingType() {
		return pagingType;
	}
	public void setPagingType(String pagingType) {
		this.pagingType = pagingType;
	}
	public Boolean getPaging() {
		return paging;
	}
	public void setPaging(Boolean paging) {
		this.paging = paging;
	}
	public List<Button> getButtons() {
		return buttons;
	}
	public void setButtons(List<Button> buttons) {
		this.buttons = buttons;
	}
	public String getDom() {
		return dom;
	}
	public void setDom(String dom) {
		this.dom = dom;
	}
	
}
