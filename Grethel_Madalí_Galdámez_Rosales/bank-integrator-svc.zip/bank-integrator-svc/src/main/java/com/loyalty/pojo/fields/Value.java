package com.loyalty.pojo.fields;

public class Value {
	
}
