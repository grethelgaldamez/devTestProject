package com.loyalty.pojo.fields.table;

public class Language {
	private Paginate Paginate;
	private String info;
	public Paginate getPaginate() {
		return Paginate;
	}
	public void setPaginate(Paginate paginate) {
		Paginate = paginate;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	
	
}
