package com.loyalty.pojo.svc.cashier;

public class Cashier {
	private String code;
	private String partner;
	private String partnerName;
	private String clientCode;
	private String documentNumber;
	private String clientFirstName;
	private String clienteLastName;
	private String employeeNumber;
	private Character status;
	private String createdBy;
	private String createdDate;
	private String modifiedBy;
	private String modifiedDate;
	
	
	public Cashier() {
		super();
	}
	public Cashier(String code, String partner, String partnerName, String clientCode, String documentNumber,
			String clientFirstName, String clienteLastName, String employeeNumber, Character status, String createdBy,
			String createdDate, String modifiedBy, String modifiedDate) {
		super();
		this.code = code;
		this.partner = partner;
		this.partnerName = partnerName;
		this.clientCode = clientCode;
		this.documentNumber = documentNumber;
		this.clientFirstName = clientFirstName;
		this.clienteLastName = clienteLastName;
		this.employeeNumber = employeeNumber;
		this.status = status;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}
	
	public Cashier(String code, String partner, String clientCode, String documentNumber, String clientFirstName,
			String clienteLastName, String employeeNumber, Character status, String createdBy, String createdDate,
			String modifiedBy, String modifiedDate) {
		super();
		this.code = code;
		this.partner = partner;
		this.clientCode = clientCode;
		this.documentNumber = documentNumber;
		this.clientFirstName = clientFirstName;
		this.clienteLastName = clienteLastName;
		this.employeeNumber = employeeNumber;
		this.status = status;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getPartner() {
		return partner;
	}
	public void setPartner(String partner) {
		this.partner = partner;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getClientCode() {
		return clientCode;
	}
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getClientFirstName() {
		return clientFirstName;
	}
	public void setClientFirstName(String clientFirstName) {
		this.clientFirstName = clientFirstName;
	}
	public String getClienteLastName() {
		return clienteLastName;
	}
	public void setClienteLastName(String clienteLastName) {
		this.clienteLastName = clienteLastName;
	}
	public String getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public Character getStatus() {
		return status;
	}
	public void setStatus(Character status) {
		this.status = status;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	

	
}
