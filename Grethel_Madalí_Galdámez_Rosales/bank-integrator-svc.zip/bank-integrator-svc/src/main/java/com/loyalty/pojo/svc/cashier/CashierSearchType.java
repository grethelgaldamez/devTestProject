package com.loyalty.pojo.svc.cashier;

public class CashierSearchType {
	String code;
	String documentNumber;
	String lifemilesNumber;
	String partnerCode;
	
	public CashierSearchType() {
		super();
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getLifemilesNumber() {
		return lifemilesNumber;
	}
	public void setLifemilesNumber(String lifemilesNumber) {
		this.lifemilesNumber = lifemilesNumber;
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	
}
