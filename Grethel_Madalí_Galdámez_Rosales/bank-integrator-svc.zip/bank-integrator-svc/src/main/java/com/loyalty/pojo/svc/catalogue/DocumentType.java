package com.loyalty.pojo.svc.catalogue;

public class DocumentType {
	private String documentCode;
	private String documentName;
	
	
	
	public DocumentType() {
		super();
	}
	
	
	public DocumentType(String documentCode, String documentName) {
		super();
		this.documentCode = documentCode;
		this.documentName = documentName;
	}


	public String getDocumentCode() {
		return documentCode;
	}
	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	
	

}
