package com.loyalty.pojo.svc.catalogue;

public class Location {
	private String idLocation;
	private String nameLocation;
	
	public Location(String idLocation, String nameLocation) {
		super();
		this.idLocation = idLocation;
		this.nameLocation = nameLocation;
	}
	public Location() {
		super();
	}
	public String getIdLocation() {
		return idLocation;
	}
	public void setIdLocation(String idLocation) {
		this.idLocation = idLocation;
	}
	public String getNameLocation() {
		return nameLocation;
	}
	public void setNameLocation(String nameLocation) {
		this.nameLocation = nameLocation;
	}		
}
