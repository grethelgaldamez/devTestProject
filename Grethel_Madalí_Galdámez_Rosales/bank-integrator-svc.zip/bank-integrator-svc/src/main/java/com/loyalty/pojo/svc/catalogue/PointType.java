package com.loyalty.pojo.svc.catalogue;

public class PointType {
	private String transactionCode;
	private String transactionName;
	private String pointTypeParent;
	
	
	public PointType() {
		super();
	}
	public PointType(String transactionCode, String transactionName) {
		super();
		this.transactionCode = transactionCode;
		this.transactionName = transactionName;
	}
	public PointType(String transactionCode, 
			String transactionName,
			String pointTypeParent) {
		super();
		this.transactionCode = transactionCode;
		this.transactionName = transactionName;
		this.pointTypeParent =pointTypeParent;
	}
	public String getTransactionCode() {
		return transactionCode;
	}
	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}
	public String getTransactionName() {
		return transactionName;
	}
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	public String getPointTypeParent() {
		return pointTypeParent;
	}
	public void setPointTypeParent(String pointTypeParent) {
		this.pointTypeParent = pointTypeParent;
	}
	

}
