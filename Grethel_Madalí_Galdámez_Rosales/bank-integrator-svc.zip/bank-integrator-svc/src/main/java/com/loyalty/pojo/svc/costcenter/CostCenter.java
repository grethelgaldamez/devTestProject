package com.loyalty.pojo.svc.costcenter;

public class CostCenter {
	private String costCenterCode;
	private String costCenterName;

	public CostCenter() {
		super();
	}

	public CostCenter(String costCenterCode, String costCenterName) {
		super();
		this.costCenterCode = costCenterCode;
		this.costCenterName = costCenterName;
	}

	public String getCostCenterCode() {
		return costCenterCode;
	}

	public void setCostCenterCode(String costCenterCode) {
		this.costCenterCode = costCenterCode;
	}

	public String getCostCenterName() {
		return costCenterName;
	}

	public void setCostCenterName(String costCenterName) {
		this.costCenterName = costCenterName;
	}

}
