package com.loyalty.pojo.svc.gantt;

public class DataObject {
	private String promName;
	private DataPopUp rows;
	public String getPromName() {
		return promName;
	}
	public void setPromName(String promName) {
		this.promName = promName;
	}
	public DataPopUp getRows() {
		return rows;
	}
	public void setRows(DataPopUp rows) {
		this.rows = rows;
	}
	
	
}
