package com.loyalty.pojo.svc.gantt;

import java.util.List;

public class ObjectGantt {
	private String[] months;
	private String[] dow;
	private List<TableGantt> gantt;
	private String[] rows;

	public String[] getMonths() {
		return months;
	}

	public void setMonths(String[] months) {
		this.months = months;
	}

	public String[] getDow() {
		return dow;
	}

	public void setDow(String[] dow) {
		this.dow = dow;
	}

	public List<TableGantt> getGantt() {
		return gantt;
	}

	public void setGantt(List<TableGantt> gantt) {
		this.gantt = gantt;
	}

	public String[] getRows() {
		return rows;
	}

	public void setRows(String[] rows) {
		this.rows = rows;
	}

}
