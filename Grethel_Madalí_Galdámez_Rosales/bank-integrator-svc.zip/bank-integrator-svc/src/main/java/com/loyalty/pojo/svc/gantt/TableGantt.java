package com.loyalty.pojo.svc.gantt;

import java.util.List;

public class TableGantt {
	private String name;
	private String desc;
	private List<ValueGantt> values;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public List<ValueGantt> getValues() {
		return values;
	}

	public void setValues(List<ValueGantt> values) {
		this.values = values;
	}

}
