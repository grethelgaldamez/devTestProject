package com.loyalty.pojo.svc.gantt;

public class ValueGantt {
	private String from;
	private String to;
	private String label;
	private String customClass;
	private DataObject dataObj;

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getCustomClass() {
		return customClass;
	}

	public void setCustomClass(String customClass) {
		this.customClass = customClass;
	}

	public DataObject getDataObj() {
		return dataObj;
	}

	public void setDataObj(DataObject dataObj) {
		this.dataObj = dataObj;
	}

}
