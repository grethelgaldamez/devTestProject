package com.loyalty.pojo.svc.giftcard;

public class GiftCard {
	private String code;
	private String serial;
	private String status;
	private String actDate;
	private String genDate;
	private String expDate;
	private Integer miles;
	private String partner;		
	
	public GiftCard() {
		super();
	}
	public GiftCard(String code, String serial, String status, String actDate, String genDate, String expDate,
			Integer miles, String partner) {
		super();
		this.code = code;
		this.serial = serial;
		this.status = status;
		this.actDate = actDate;
		this.genDate = genDate;
		this.expDate = expDate;
		this.miles = miles;
		this.partner = partner;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getSerial() {
		return serial;
	}
	public void setSerial(String serial) {
		this.serial = serial;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getActDate() {
		return actDate;
	}
	public void setActDate(String actDate) {
		this.actDate = actDate;
	}
	public String getGenDate() {
		return genDate;
	}
	public void setGenDate(String genDate) {
		this.genDate = genDate;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public Integer getMiles() {
		return miles;
	}
	public void setMiles(Integer miles) {
		this.miles = miles;
	}
	public String getPartner() {
		return partner;
	}
	public void setPartner(String partner) {
		this.partner = partner;
	}
	
	
}