package com.loyalty.pojo.svc.mcv;

public class MilesConv {
	private String memberNum;
	private String memberId;
	private String firstName;
	private String lastName;
	private String partnerCode;
	private String partnerName;
	private String transactionDate;
	private String transactionHour;
	private String transactionCode;
	private String transactionDescription;
	private String transactionId;
	private String transactionIdSource;
	private String autNumber;
	private String totalMiles;
	private String prePurchCode;
	private String promoCode;
	private String user;	
	private String resCode;
	private String message;
	private String actRefNum;
	private String actNum;
	private String partnerCat;
	private String processDate;
	private String promoDesc;
	
	public MilesConv() {
		super();
	}
	
	public MilesConv(String memberNum, String memberId, String firstName, String lastName, String partnerCode,
			String partnerName, String transactionDate, String transactionHour, String transactionCode,
			String transactionDescription, String transactionId, String transactionIdSource, String autNumber,
			String totalMiles, String prePurchCode, String promoCode, String user) {
		super();
		this.memberNum = memberNum;
		this.memberId = memberId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.partnerCode = partnerCode;
		this.partnerName = partnerName;
		this.transactionDate = transactionDate;
		this.transactionHour = transactionHour;
		this.transactionCode = transactionCode;
		this.transactionDescription = transactionDescription;
		this.transactionId = transactionId;
		this.transactionIdSource = transactionIdSource;
		this.autNumber = autNumber;
		this.totalMiles = totalMiles;
		this.prePurchCode = prePurchCode;
		this.promoCode = promoCode;
		this.user = user;
	}
	public String getMemberNum() {
		return memberNum;
	}
	public void setMemberNum(String memberNum) {
		this.memberNum = memberNum;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionHour() {
		return transactionHour;
	}
	public void setTransactionHour(String transactionHour) {
		this.transactionHour = transactionHour;
	}
	public String getTransactionCode() {
		return transactionCode;
	}
	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionIdSource() {
		return transactionIdSource;
	}
	public void setTransactionIdSource(String transactionIdSource) {
		this.transactionIdSource = transactionIdSource;
	}
	public String getAutNumber() {
		return autNumber;
	}
	public void setAutNumber(String autNumber) {
		this.autNumber = autNumber;
	}
	public String getTotalMiles() {
		return totalMiles;
	}
	public void setTotalMiles(String totalMiles) {
		this.totalMiles = totalMiles;
	}
	public String getPrePurchCode() {
		return prePurchCode;
	}
	public void setPrePurchCode(String prePurchCode) {
		this.prePurchCode = prePurchCode;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}

	public String getResCode() {
		return resCode;
	}

	public void setResCode(String resCode) {
		this.resCode = resCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getActRefNum() {
		return actRefNum;
	}

	public void setActRefNum(String actRefNum) {
		this.actRefNum = actRefNum;
	}

	public String getActNum() {
		return actNum;
	}

	public void setActNum(String actNum) {
		this.actNum = actNum;
	}

	public String getPartnerCat() {
		return partnerCat;
	}

	public void setPartnerCat(String partnerCat) {
		this.partnerCat = partnerCat;
	}

	public String getProcessDate() {
		return processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

	public String getPromoDesc() {
		return promoDesc;
	}

	public void setPromoDesc(String promoDesc) {
		this.promoDesc = promoDesc;
	}
	
	
}
