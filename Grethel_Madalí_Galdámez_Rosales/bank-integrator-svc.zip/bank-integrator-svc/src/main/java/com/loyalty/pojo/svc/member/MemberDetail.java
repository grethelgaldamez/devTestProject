package com.loyalty.pojo.svc.member;

public class MemberDetail {
	private String memberNum; //Membership Number
	private String firstName;
	private String lastName;
	private String secondName;
	private String secondLastName;
	private String companyName;
	private String employerName;
	private String mobileISDCode;
	private String mobileAreaCode;
	private String mobileNumber;
	private String email;
	private String birthDate;
	private String address;
	private String postalCode;
	private String companyId;
	private String memberStatus; //membership status
	private String accountStatus;
	
	public MemberDetail() {
		super();
	}
	
	public MemberDetail(String memberNum, String firstName, String lastName, String secondName, String secondLastName,
			String companyName, String employerName, String mobileISDCode, String mobileAreaCode, String mobileNumber,
			String email, String birthDate, String address, String postalCode, String companyId, String memberStatus,
			String accountStatus) {
		super();
		this.memberNum = memberNum;
		this.firstName = firstName;
		this.lastName = lastName;
		this.secondName = secondName;
		this.secondLastName = secondLastName;
		this.companyName = companyName;
		this.employerName = employerName;
		this.mobileISDCode = mobileISDCode;
		this.mobileAreaCode = mobileAreaCode;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.birthDate = birthDate;
		this.address = address;
		this.postalCode = postalCode;
		this.companyId = companyId;
		this.memberStatus = memberStatus;
		this.accountStatus = accountStatus;
	}
	public String getMemberNum() {
		return memberNum;
	}
	public void setMemberNum(String memberNum) {
		this.memberNum = memberNum;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String surName) {
		this.lastName = surName;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public String getSecondLastName() {
		return secondLastName;
	}
	public void setSecondLastName(String secondLastName) {
		this.secondLastName = secondLastName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public String getMobileISDCode() {
		return mobileISDCode;
	}
	public void setMobileISDCode(String mobileISDCode) {
		this.mobileISDCode = mobileISDCode;
	}
	public String getMobileAreaCode() {
		return mobileAreaCode;
	}
	public void setMobileAreaCode(String mobileAreaCode) {
		this.mobileAreaCode = mobileAreaCode;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getMemberStatus() {
		return memberStatus;
	}
	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}	
	
	
}
