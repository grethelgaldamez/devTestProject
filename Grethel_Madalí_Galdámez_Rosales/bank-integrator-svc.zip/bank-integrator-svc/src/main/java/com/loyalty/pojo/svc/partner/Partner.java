package com.loyalty.pojo.svc.partner;

public class Partner {
	private String code;
	private String name;
	private char status;

	public Partner() {
		//constructor
	}

	public Partner(String code, String name, char status) {
		super();
		this.code = code;
		this.name = name;
		this.status = status;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

}
