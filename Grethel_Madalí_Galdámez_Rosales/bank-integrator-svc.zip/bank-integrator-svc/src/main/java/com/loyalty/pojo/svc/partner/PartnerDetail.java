package com.loyalty.pojo.svc.partner;

public class PartnerDetail<T>{
	private String partnerCode;
	private String partnerName;
	private String parentPartnerCode;
	private String partnerCategory;
	private String categoryName;
	private String partnerReason;
	private String partnerPhone;
	private String partnerEmail;
	private String partnerWebPage;
	private String partnerDescription;
	private String partnerSrcImg;
	private char partnerStatus;		
	private T config;
	private String confType; 	
	private byte[] partnerImage;
		
	public PartnerDetail(String partnerCode, String partnerName, String parentPartnerCode, String partnerCategory,
			String partnerReason, String partnerPhone, String partnerEmail, String partnerWebPage,
			String partnerDescription, String partnerSrcImg, char partnerStatus, String confType,
			T config) {
		super();
		this.partnerCode = partnerCode;
		this.partnerName = partnerName;
		this.parentPartnerCode = parentPartnerCode;
		this.partnerCategory = partnerCategory;
		this.partnerReason = partnerReason;
		this.partnerPhone = partnerPhone;
		this.partnerEmail = partnerEmail;
		this.partnerWebPage = partnerWebPage;
		this.partnerDescription = partnerDescription;
		this.partnerSrcImg = partnerSrcImg;
		this.partnerStatus = partnerStatus;
		this.confType = confType;
		this.config = config;
	}


	public PartnerDetail() {
		super();
	}


	public String getConfType() {
		return confType;
	}

	public void setConfType(String confType) {
		this.confType = confType;
	}

	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getParentPartnerCode() {
		return parentPartnerCode;
	}
	public void setParentPartnerCode(String parentPartnerCode) {
		this.parentPartnerCode = parentPartnerCode;
	}
	public String getPartnerCategory() {
		return partnerCategory;
	}
	public void setPartnerCategory(String partnerCategory) {
		this.partnerCategory = partnerCategory;
	}
	public String getPartnerReason() {
		return partnerReason;
	}
	public void setPartnerReason(String partnerReason) {
		this.partnerReason = partnerReason;
	}
	public String getPartnerEmail() {
		return partnerEmail;
	}
	public void setPartnerEmail(String partnerEmail) {
		this.partnerEmail = partnerEmail;
	}
	public String getPartnerWebPage() {
		return partnerWebPage;
	}
	public void setPartnerWebPage(String partnerWebPage) {
		this.partnerWebPage = partnerWebPage;
	}
	public String getPartnerDescription() {
		return partnerDescription;
	}
	public void setPartnerDescription(String partnerDescription) {
		this.partnerDescription = partnerDescription;
	}
	public String getPartnerSrcImg() {
		return partnerSrcImg;
	}
	public void setPartnerSrcImg(String partnerSrcImg) {
		this.partnerSrcImg = partnerSrcImg;
	}
	public char getPartnerStatus() {
		return partnerStatus;
	}
	public void setPartnerStatus(char partnerStatus) {
		this.partnerStatus = partnerStatus;
	}
	public T getConfig() {
		return config;
	}

	public void setConfig(T config) {
		this.config = config;
	}


	public String getPartnerPhone() {
		return partnerPhone;
	}


	public void setPartnerPhone(String partnerPhone) {
		this.partnerPhone = partnerPhone;
	}


	public byte[] getPartnerImage() {
		return partnerImage;
	}


	public void setPartnerImage(byte[] partnerImage) {
		this.partnerImage = partnerImage;
	}


	public String getCategoryName() {
		return categoryName;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	

	
	
}
