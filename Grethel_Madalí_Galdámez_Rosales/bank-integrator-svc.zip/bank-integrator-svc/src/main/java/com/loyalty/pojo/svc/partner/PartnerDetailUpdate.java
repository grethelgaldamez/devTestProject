package com.loyalty.pojo.svc.partner;

import com.loyalty.pojo.svc.prepurchase.PrePurchaseList;

public class PartnerDetailUpdate {
	private PartnerDetail<?> partnerDetail;
	private PrePurchaseList prePurchase;
	private byte[] partnerStoreMasive;
	private byte[] partnerConfMasive;
	
	public PartnerDetailUpdate() {
		super();
	}

	public PartnerDetail<?> getPartnerDetail() {
		return partnerDetail;
	}

	public void setPartnerDetail(PartnerDetail<?> partnerDetail) {
		this.partnerDetail = partnerDetail;
	}

	public PrePurchaseList getPrePurchase() {
		return prePurchase;
	}

	public void setPrePurchase(PrePurchaseList prePurchase) {
		this.prePurchase = prePurchase;
	}

	public byte[] getPartnerStoreMasive() {
		return partnerStoreMasive;
	}

	public void setPartnerStoreMasive(byte[] partnerStoreMasive) {
		this.partnerStoreMasive = partnerStoreMasive;
	}

	public byte[] getPartnerConfMasive() {
		return partnerConfMasive;
	}

	public void setPartnerConfMasive(byte[] partnerConfMasive) {
		this.partnerConfMasive = partnerConfMasive;
	}
	
	
	
}
