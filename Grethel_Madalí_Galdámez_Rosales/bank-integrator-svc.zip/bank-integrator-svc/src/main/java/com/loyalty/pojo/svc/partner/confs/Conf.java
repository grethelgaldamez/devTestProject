package com.loyalty.pojo.svc.partner.confs;

public class Conf {

}
