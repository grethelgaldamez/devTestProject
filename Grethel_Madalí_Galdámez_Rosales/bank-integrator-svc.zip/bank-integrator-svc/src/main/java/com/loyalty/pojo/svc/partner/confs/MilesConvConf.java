package com.loyalty.pojo.svc.partner.confs;

public class MilesConvConf extends Conf{
	private String accCode;
	private String promAccCode;
	private int maxAccumulate;
	private int maxAccumulateProm;
		
	
	
	public MilesConvConf() {
		super();
	}
	public MilesConvConf(String accCode, String promAccCode, int maxAccumulate, int maxAccumulateProm) {
		super();
		this.accCode = accCode;
		this.promAccCode = promAccCode;
		this.maxAccumulate = maxAccumulate;
		this.maxAccumulateProm = maxAccumulateProm;
	}
	public String getAccCode() {
		return accCode;
	}
	public void setAccCode(String accCode) {
		this.accCode = accCode;
	}
	public String getPromAccCode() {
		return promAccCode;
	}
	public void setPromAccCode(String promAccCode) {
		this.promAccCode = promAccCode;
	}
	public int getMaxAccumulate() {
		return maxAccumulate;
	}
	public void setMaxAccumulate(int maxAccumulate) {
		this.maxAccumulate = maxAccumulate;
	}
	public int getMaxAccumulateProm() {
		return maxAccumulateProm;
	}
	public void setMaxAccumulateProm(int maxAccumulateProm) {
		this.maxAccumulateProm = maxAccumulateProm;
	}
	
	
}
