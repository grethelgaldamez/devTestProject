package com.loyalty.pojo.svc.partner.confs;

public class RetailConf extends Conf{
	private String accCode;
	private String revAccCode;
	private String anuAccCode;
	private String redCode;
	private String revRedCode;
	private String anuRedCode;		
	
	
	public RetailConf() {
		super();
	}
	public RetailConf(String accCode, String revAccCode, String anuAccCode, String redCode, String revRedCode,
			String anuRedCode) {
		super();
		this.accCode = accCode;
		this.revAccCode = revAccCode;
		this.anuAccCode = anuAccCode;
		this.redCode = redCode;
		this.revRedCode = revRedCode;
		this.anuRedCode = anuRedCode;
	}
	public String getAccCode() {
		return accCode;
	}
	public void setAccCode(String accCode) {
		this.accCode = accCode;
	}
	public String getRevAccCode() {
		return revAccCode;
	}
	public void setRevAccCode(String revAccCode) {
		this.revAccCode = revAccCode;
	}
	public String getAnuAccCode() {
		return anuAccCode;
	}
	public void setAnuAccCode(String anuAccCode) {
		this.anuAccCode = anuAccCode;
	}
	public String getRedCode() {
		return redCode;
	}
	public void setRedCode(String redCode) {
		this.redCode = redCode;
	}
	public String getRevRedCode() {
		return revRedCode;
	}
	public void setRevRedCode(String revRedCode) {
		this.revRedCode = revRedCode;
	}
	public String getAnuRedCode() {
		return anuRedCode;
	}
	public void setAnuRedCode(String anuRedCode) {
		this.anuRedCode = anuRedCode;
	}
	
	
	
}
