package com.loyalty.pojo.svc.prepurchase;

public class HistPrePurchase {
	private String partnerCode;
	private String prepurchaseCode;
	private String firstStartDate;
	private String lastStartDate;
	private String firstEndDate;
	private String lastEndDate;
	private String pointType;
	
	
	
	public HistPrePurchase(String partnerCode, String prepurchaseCode, String firstStartDate, String lastStartDate,
			String firstEndDate, String lastEndDate) {
		super();
		this.partnerCode = partnerCode;
		this.prepurchaseCode = prepurchaseCode;
		this.firstStartDate = firstStartDate;
		this.lastStartDate = lastStartDate;
		this.firstEndDate = firstEndDate;
		this.lastEndDate = lastEndDate;
	}
	public HistPrePurchase() {
		super();
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getPrepurchaseCode() {
		return prepurchaseCode;
	}
	public void setPrepurchaseCode(String prepurchaseCode) {
		this.prepurchaseCode = prepurchaseCode;
	}
	public String getFirstStartDate() {
		return firstStartDate;
	}
	public void setFirstStartDate(String firstStartDate) {
		this.firstStartDate = firstStartDate;
	}
	public String getLastStartDate() {
		return lastStartDate;
	}
	public void setLastStartDate(String lastStartDate) {
		this.lastStartDate = lastStartDate;
	}
	public String getFirstEndDate() {
		return firstEndDate;
	}
	public void setFirstEndDate(String firstEndDate) {
		this.firstEndDate = firstEndDate;
	}
	public String getLastEndDate() {
		return lastEndDate;
	}
	public void setLastEndDate(String lastEndDate) {
		this.lastEndDate = lastEndDate;
	}
	public String getPointType() {
		return pointType;
	}
	public void setPointType(String pointType) {
		this.pointType = pointType;
	}

	
	
	
}
