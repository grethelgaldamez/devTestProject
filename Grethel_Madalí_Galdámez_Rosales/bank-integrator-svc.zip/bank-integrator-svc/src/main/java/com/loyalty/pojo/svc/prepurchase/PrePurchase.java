package com.loyalty.pojo.svc.prepurchase;

public class PrePurchase {
	private String prePurchCode;
	private String prePurchName;
	private String fechaIni;
	private String fechaFin;
	private Integer valor;
	private String pointType;
	private String partner;
	private String status;
	
	public PrePurchase() {
		super();
	}
	public PrePurchase(String prePurchCode, String prePurchName, String pointType) {
		super();
		this.prePurchCode = prePurchCode;
		this.prePurchName = prePurchName;
		this.pointType = pointType;
	}
	public PrePurchase(String prePurchCode, String prePurchName, String pointType, String fechaIni, String fechaFin,
			Integer valor) {
		super();
		this.prePurchCode = prePurchCode;
		this.prePurchName = prePurchName;
		this.pointType = pointType;
		this.fechaIni = fechaIni;
		this.fechaFin = fechaFin;
		this.valor = valor;
	}
	public String getFechaIni() {
		return fechaIni;
	}
	public void setFechaIni(String fechaIni) {
		this.fechaIni = fechaIni;
	}
	public String getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}
	public Integer getValor() {
		return valor;
	}
	public void setValor(Integer valor) {
		this.valor = valor;
	}
	public String getPrePurchCode() {
		return prePurchCode;
	}
	public void setPrePurchCode(String prePurchCode) {
		this.prePurchCode = prePurchCode;
	}
	public String getPrePurchName() {
		return prePurchName;
	}
	public void setPrePurchName(String prePurchName) {
		this.prePurchName = prePurchName;
	}
	public String getPointType() {
		return pointType;
	}
	public void setPointType(String pointType) {
		this.pointType = pointType;
	}
	public String getPartner() {
		return partner;
	}
	public void setPartner(String partner) {
		this.partner = partner;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	
	
}
