package com.loyalty.pojo.svc.prepurchase;

import java.util.List;

public class PrePurchaseList {
	private List<PrePurchase> disponibles;
	private List<PrePurchase> seleccionadas;
	
	public PrePurchaseList() {
		super();
	}
	public PrePurchaseList(List<PrePurchase> disponibles, List<PrePurchase> seleccionadas) {
		super();
		this.disponibles = disponibles;
		this.seleccionadas = seleccionadas;
	}
	
	public List<PrePurchase> getDisponibles() {
		return disponibles;
	}
	public void setDisponibles(List<PrePurchase> disponibles) {
		this.disponibles = disponibles;
	}
	public List<PrePurchase> getSeleccionadas() {
		return seleccionadas;
	}
	public void setSeleccionadas(List<PrePurchase> noDisponibles) {
		this.seleccionadas = noDisponibles;
	}
	
	
}
