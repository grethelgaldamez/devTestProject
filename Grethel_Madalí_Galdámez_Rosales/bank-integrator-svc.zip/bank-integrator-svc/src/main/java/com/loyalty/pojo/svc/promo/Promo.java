package com.loyalty.pojo.svc.promo;

import java.util.List;

public class Promo {
	private String partnerCode;
	private String promoCode;
	private String bonusType;
	private Character promoType;
	private Double bonus;
	private String startDate;
	private String endDate;
	private String costCenter;
	private String accrualTrans;
	private String description;
	private String startHour;
	private String endHour;
	private List<String> recurrence;
	private String owner;
	private Character status;
	private String minAmount;
	private String segmentByCust;
	
	public Promo() {
		super();
	}
	
	public Promo(String partnerCode, String promoCode, String bonusType, Character promoType, Double bonus, String startDate,
			String endDate, String costCenter, String accrualTrans, String description, String startHour,
			String endHour, List<String> recurrence, String owner, Character status, String minAmount, String segmentByCust) {
		super();
		this.partnerCode = partnerCode;
		this.promoCode = promoCode;
		this.promoType = promoType;
		this.bonusType = bonusType;
		this.bonus = bonus;
		this.startDate = startDate;
		this.endDate = endDate;
		this.costCenter = costCenter;
		this.accrualTrans = accrualTrans;
		this.description = description;
		this.startHour = startHour;
		this.endHour = endHour;
		this.recurrence = recurrence;
		this.owner = owner;
		this.status = status;
		this.minAmount = minAmount;
		this.segmentByCust = segmentByCust;
	}



	public Character getPromoType() {
		return promoType;
	}

	public void setPromoType(Character promoType) {
		this.promoType = promoType;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public String getBonusType() {
		return bonusType;
	}
	public void setBonusType(String bonusType) {
		this.bonusType = bonusType;
	}
	public Double getBonus() {
		return bonus;
	}
	public void setBonus(Double bonus) {
		this.bonus = bonus;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getAccrualTrans() {
		return accrualTrans;
	}
	public void setAccrualTrans(String accrualTrans) {
		this.accrualTrans = accrualTrans;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartHour() {
		return startHour;
	}
	public void setStartHour(String startHour) {
		this.startHour = startHour;
	}
	public String getEndHour() {
		return endHour;
	}
	public void setEndHour(String endHour) {
		this.endHour = endHour;
	}
	public List<String> getRecurrence() {
		return recurrence;
	}
	public void setRecurrence(List<String> recurrence) {
		this.recurrence = recurrence;
	}
	public Character getStatus() {
		return status;
	}
	public void setStatus(Character status) {
		this.status = status;
	}
	public String getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(String minAmount) {
		this.minAmount = minAmount;
	}
	public String getSegmentByCust() {
		return segmentByCust;
	}
	public void setSegmentByCust(String segmentByCust) {
		this.segmentByCust = segmentByCust;
	}
	
}
