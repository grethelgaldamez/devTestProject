package com.loyalty.pojo.svc.promo;

import java.util.List;

public class PromoCreation {

	private List<Promo> prom;
	private byte[] segmentByStore;
	private byte[] segmentByCli;
	public List<Promo> getProm() {
		return prom;
	}
	public void setProm(List<Promo> prom) {
		this.prom = prom;
	}
	public byte[] getSegmentByStore() {
		return segmentByStore;
	}
	public void setSegmentByStore(byte[] segmentByStore) {
		this.segmentByStore = segmentByStore;
	}
	public byte[] getSegmentByCli() {
		return segmentByCli;
	}
	public void setSegmentByCli(byte[] segmentByCli) {
		this.segmentByCli = segmentByCli;
	}
	
}
