package com.loyalty.pojo.svc.promo;

public class PromoUpdate {

	private Promo prom;
	private byte[] segmentByStore;
	private byte[] segmentByCli;
	private char wf;
	
	public PromoUpdate(Promo prom, char wf) {
		super();
		this.prom = prom;
		this.wf = wf;
	}
	public PromoUpdate() {
		super();
	}
	public PromoUpdate(Promo prom, byte[] segmentByStore, byte[] segmentByCli, char wf) {
		super();
		this.prom = prom;
		this.segmentByStore = segmentByStore;
		this.segmentByCli = segmentByCli;
		this.wf = wf;
	}
	public char getWf() {
		return wf;
	}
	public void setWf(char wf) {
		this.wf = wf;
	}
	public Promo getProm() {
		return prom;
	}
	public void setProm(Promo prom) {
		this.prom = prom;
	}
	public byte[] getSegmentByStore() {
		return segmentByStore;
	}
	public void setSegmentByStore(byte[] segmentByStore) {
		this.segmentByStore = segmentByStore;
	}
	public byte[] getSegmentByCli() {
		return segmentByCli;
	}
	public void setSegmentByCli(byte[] segmentByCli) {
		this.segmentByCli = segmentByCli;
	}
	
}
