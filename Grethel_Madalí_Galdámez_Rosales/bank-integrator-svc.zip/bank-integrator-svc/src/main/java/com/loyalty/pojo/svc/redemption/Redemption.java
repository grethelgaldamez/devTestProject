package com.loyalty.pojo.svc.redemption;

public class Redemption {

	private String munComercial;
	private String codCustomer;
	private String name;
	private String apel;
	private String partnerCode;
	private String partnerName;
	private String transDate;
	private String transHour;
	private String transCode;
	private String transDesc;
	private String transId;
	private String transIdSource;
	private String transAutNum;
	private Integer totalMiles;
	private Integer itemMiles;
	private Integer ownMiles;
	private Integer purchMiles;
	
	public Redemption() {
		super();
	}
	
	public Redemption(String munComercial, String codCustomer, String name, String apel,
			String partnerCode, String partnerName, String transDate, String transHour, String transCode,
			String transDesc, String transId, String transIdSource, String transAutNum, Integer totalMiles, Integer itemMiles,
			Integer ownMiles, Integer purchMiles) {
		super();
		this.munComercial = munComercial;
		this.codCustomer = codCustomer;
		this.name = name;
		this.apel = apel;
		this.partnerCode = partnerCode;
		this.partnerName = partnerName;
		this.transDate = transDate;
		this.transHour = transHour;
		this.transCode = transCode;
		this.transDesc = transDesc;
		this.transId = transId;
		this.transIdSource = transIdSource;
		this.transAutNum = transAutNum;
		this.totalMiles = totalMiles;
		this.itemMiles = itemMiles;
		this.ownMiles = ownMiles;
		this.purchMiles = purchMiles;
	}

	public String getMunComercial() {
		return munComercial;
	}
	public void setMunComercial(String munComercial) {
		this.munComercial = munComercial;
	}
	public String getCodCustomer() {
		return codCustomer;
	}
	public void setCodCustomer(String codCustomer) {
		this.codCustomer = codCustomer;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getApel() {
		return apel;
	}
	public void setApel(String apel) {
		this.apel = apel;
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	public String getTransHour() {
		return transHour;
	}
	public void setTransHour(String transHour) {
		this.transHour = transHour;
	}
	public String getTransCode() {
		return transCode;
	}
	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}
	public String getTransDesc() {
		return transDesc;
	}
	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getTransIdSource() {
		return transIdSource;
	}
	public void setTransIdSource(String transIdSource) {
		this.transIdSource = transIdSource;
	}
	public String getTransAutNum() {
		return transAutNum;
	}
	public void setTransAutNum(String transAutNum) {
		this.transAutNum = transAutNum;
	}
	public Integer getTotalMiles() {
		return totalMiles;
	}
	public void setTotalMiles(Integer totalMiles) {
		this.totalMiles = totalMiles;
	}
	public Integer getItemMiles() {
		return itemMiles;
	}
	public void setItemMiles(Integer itemMiles) {
		this.itemMiles = itemMiles;
	}
	public Integer getOwnMiles() {
		return ownMiles;
	}
	public void setOwnMiles(Integer ownMiles) {
		this.ownMiles = ownMiles;
	}
	public Integer getPurchMiles() {
		return purchMiles;
	}
	public void setPurchMiles(Integer purchMiles) {
		this.purchMiles = purchMiles;
	}
	
	
	
}
