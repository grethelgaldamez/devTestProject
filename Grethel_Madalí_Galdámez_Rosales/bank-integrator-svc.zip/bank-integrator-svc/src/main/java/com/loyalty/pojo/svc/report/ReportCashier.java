package com.loyalty.pojo.svc.report;

import java.util.List;

public class ReportCashier {
	private List<String> partners;
	private String cashierCode;
	private String lifemilesNumber;
	private String documentNumber;
	private String employeeNumber;
	private String startDate;
	private String endDate;
	private String clientFirstName;
	private String clientLastName;
	private String status;
	
	public ReportCashier(){
		super();
	}
	
	
	public ReportCashier(List<String> partners, String cashierCode, String lifemilesNumber, String documentNumber,
			String employeeNumber, String startDate, String endDate, String clientFirstName, String clientLastName,
			String status) {
		super();
		this.partners = partners;
		this.cashierCode = cashierCode;
		this.lifemilesNumber = lifemilesNumber;
		this.documentNumber = documentNumber;
		this.employeeNumber = employeeNumber;
		this.startDate = startDate;
		this.endDate = endDate;
		this.clientFirstName = clientFirstName;
		this.clientLastName = clientLastName;
		this.status = status;
	}
	public List<String> getPartners() {
		return partners;
	}
	public void setPartners(List<String> partners) {
		this.partners = partners;
	}
	public String getCashierCode() {
		return cashierCode;
	}
	public void setCashierCode(String cashierCode) {
		this.cashierCode = cashierCode;
	}
	public String getLifemilesNumber() {
		return lifemilesNumber;
	}
	public void setLifemilesNumber(String lifemilesNumber) {
		this.lifemilesNumber = lifemilesNumber;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getClientFirstName() {
		return clientFirstName;
	}
	public void setClientFirstName(String clientFirstName) {
		this.clientFirstName = clientFirstName;
	}
	public String getClientLastName() {
		return clientLastName;
	}
	public void setClientLastName(String clientLastName) {
		this.clientLastName = clientLastName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
		
	
}
