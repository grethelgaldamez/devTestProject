package com.loyalty.pojo.svc.report;

public class ReportGiftCard {
	private String serial;		
	private String acumStartDate;
	private String acumEndDate;	
	private String actStartDate;
	private String actEndDate;	
	private String partner;
	
	public ReportGiftCard() {
		super();
	}

	
	public String getPartner() {
		return partner;
	}



	public void setPartner(String partner) {
		this.partner = partner;
	}



	public ReportGiftCard(String serial, String acumStartDate, String acumEndDate, String actStartDate,
			String actEndDate, String partner) {
		super();
		this.serial = serial;
		this.acumStartDate = acumStartDate;
		this.acumEndDate = acumEndDate;
		this.actStartDate = actStartDate;
		this.actEndDate = actEndDate;
		this.partner = partner;
	}



	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getAcumStartDate() {
		return acumStartDate;
	}

	public void setAcumStartDate(String acumStartDate) {
		this.acumStartDate = acumStartDate;
	}

	public String getAcumEndDate() {
		return acumEndDate;
	}

	public void setAcumEndDate(String acumEndDate) {
		this.acumEndDate = acumEndDate;
	}

	public String getActStartDate() {
		return actStartDate;
	}

	public void setActStartDate(String actStartDate) {
		this.actStartDate = actStartDate;
	}

	public String getActEndDate() {
		return actEndDate;
	}

	public void setActEndDate(String actEndDate) {
		this.actEndDate = actEndDate;
	}

}