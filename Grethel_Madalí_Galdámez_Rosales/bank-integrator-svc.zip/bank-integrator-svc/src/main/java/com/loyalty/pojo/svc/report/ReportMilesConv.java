package com.loyalty.pojo.svc.report;

import java.util.List;

public class ReportMilesConv {
	private List<String> partnerCode;
	private String startDate;
	private String endDate;
	private String lifeMilesNumber;
	private String autNumber;
	private String prePurchNumber;
	private List<String> transactionCode;
		
	public ReportMilesConv() {
		super();
	}
		
	public ReportMilesConv(List<String> partnerCode, String startDate, String endDate, String lifeMilesNumber,
			String autNumber, String prePurchNumber, List<String> transactionCode) {
		super();
		this.partnerCode = partnerCode;
		this.startDate = startDate;
		this.endDate = endDate;
		this.lifeMilesNumber = lifeMilesNumber;
		this.autNumber = autNumber;
		this.prePurchNumber = prePurchNumber;
		this.transactionCode = transactionCode;
	}

	public List<String> getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(List<String> partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getLifeMilesNumber() {
		return lifeMilesNumber;
	}

	public void setLifeMilesNumber(String lifeMilesNumber) {
		this.lifeMilesNumber = lifeMilesNumber;
	}

	public String getAutNumber() {
		return autNumber;
	}

	public void setAutNumber(String autNumber) {
		this.autNumber = autNumber;
	}

	public String getPrePurchNumber() {
		return prePurchNumber;
	}

	public void setPrePurchNumber(String prePurchNumber) {
		this.prePurchNumber = prePurchNumber;
	}

	public List<String> getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(List<String> transactionCode) {
		this.transactionCode = transactionCode;
	}	
	
	
}
