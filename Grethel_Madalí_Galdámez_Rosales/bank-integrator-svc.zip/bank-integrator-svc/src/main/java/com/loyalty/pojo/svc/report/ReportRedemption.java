package com.loyalty.pojo.svc.report;

import java.util.List;

public class ReportRedemption {
	private List<String> partner;
	private List<String> transaction;		
	private String startDate;
	private String endDate;
	private String member;
	private String approbationNumber;

	public ReportRedemption() {
		super();
	}
	
	public ReportRedemption(List<String> partner, List<String> transaction, String startDate, String endDate,
			String member, String approbationNumber) {
		super();
		this.partner = partner;
		this.transaction = transaction;
		this.startDate = startDate;
		this.endDate = endDate;
		this.member = member;
		this.approbationNumber = approbationNumber;
	}
	public List<String> getPartner() {
		return partner;
	}
	public void setPartner(List<String> partner) {
		this.partner = partner;
	}
	public List<String> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<String> transaction) {
		this.transaction = transaction;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getMember() {
		return member;
	}
	public void setMember(String member) {
		this.member = member;
	}
	public String getApprobationNumber() {
		return approbationNumber;
	}
	public void setApprobationNumber(String approbationNumber) {
		this.approbationNumber = approbationNumber;
	}

	
	
}