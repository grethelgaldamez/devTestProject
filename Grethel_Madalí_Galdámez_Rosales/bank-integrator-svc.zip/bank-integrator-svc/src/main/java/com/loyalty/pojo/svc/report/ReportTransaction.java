package com.loyalty.pojo.svc.report;

import java.util.List;

public class ReportTransaction {
	private List<String> partners;
	private List<String> stores;
	private List<String> countries;
	private String startDate;
	private String endDate;
	private String lifemilesNumber;
	private String aprobationNumber;
	private List<String> transactions;
	private Boolean transType; //true es por partner, false es por país
	
	public ReportTransaction() {
		super();
	}
	public ReportTransaction(List<String> partners, List<String> stores, List<String> countries, String startDate, String endDate,
			String lifemilesNumber, String aprobationNumber, List<String> transactions, Boolean transType) {
		super();
		this.partners = partners;
		this.stores = stores;
		this.countries = countries;
		this.startDate = startDate;
		this.endDate = endDate;
		this.lifemilesNumber = lifemilesNumber;
		this.aprobationNumber = aprobationNumber;
		this.transactions = transactions;
		this.transType = transType;
	}
	public List<String> getCountries() {
		return countries;
	}
	public void setCountries(List<String> countries) {
		this.countries = countries;
	}
	public Boolean getTransType() {
		return transType;
	}
	public void setTransType(Boolean transType) {
		this.transType = transType;
	}
	public List<String> getPartners() {
		return partners;
	}
	public void setPartners(List<String> partners) {
		this.partners = partners;
	}
	public List<String> getStores() {
		return stores;
	}
	public void setStores(List<String> stores) {
		this.stores = stores;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getLifemilesNumber() {
		return lifemilesNumber;
	}
	public void setLifemilesNumber(String lifemilesNumber) {
		this.lifemilesNumber = lifemilesNumber;
	}
	public String getAprobationNumber() {
		return aprobationNumber;
	}
	public void setAprobationNumber(String aprobationNumber) {
		this.aprobationNumber = aprobationNumber;
	}
	public List<String> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<String> transactions) {
		this.transactions = transactions;
	}
	
	
	
}
