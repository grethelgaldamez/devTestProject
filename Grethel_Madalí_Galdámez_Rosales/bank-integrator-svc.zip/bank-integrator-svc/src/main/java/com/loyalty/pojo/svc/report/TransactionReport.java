package com.loyalty.pojo.svc.report;

public class TransactionReport {
	private String actNumber;
	private String actRefNum;
	private String amount;
	private String cashierCode;
	private String cashierName;
	private String city;
	private String commerceCode;
	private String commerceName;
	private String country;
	private String currency;
	private String description;
	private String documentNumber;
	private String exchangeRate;
	private String firstName;
	private String ghostCard;
	private String lastName;
	private String memberNum;
	private String milePrice;
	private String miles;
	private String partnerCode;
	private String partnerName;
	private String pointType;
	private String processDate;
	private String promCode;
	private String promName;
	private String remark;
	private String response;
	private String rewardCode;
	private String storeCode;
	private String storeName;
	private String transCode;
	private String transDate;
	private String voucherId;
	private String voucherOrigin;
	private String authNumber;
	private String authOrigin;

	public TransactionReport() {
		super();
	}

	public TransactionReport(String actNumber, String actRefNum, String amount, String cashierCode, String cashierName,
			String city, String commerceCode, String commerceName, String country, String currency, String description,
			String documentNumber, String exchangeRate, String firstName, String ghostCard, String lastName,
			String memberNum, String milePrice, String miles, String partnerCode, String partnerName, String pointType,
			String processDate, String promCode, String promName, String remark, String response, String rewardCode,
			String storeCode, String storeName, String transCode, String transDate) {
		super();
		this.actNumber = actNumber;
		this.actRefNum = actRefNum;
		this.amount = amount;
		this.cashierCode = cashierCode;
		this.cashierName = cashierName;
		this.city = city;
		this.commerceCode = commerceCode;
		this.commerceName = commerceName;
		this.country = country;
		this.currency = currency;
		this.description = description;
		this.documentNumber = documentNumber;
		this.exchangeRate = exchangeRate;
		this.firstName = firstName;
		this.ghostCard = ghostCard;
		this.lastName = lastName;
		this.memberNum = memberNum;
		this.milePrice = milePrice;
		this.miles = miles;
		this.partnerCode = partnerCode;
		this.partnerName = partnerName;
		this.pointType = pointType;
		this.processDate = processDate;
		this.promCode = promCode;
		this.promName = promName;
		this.remark = remark;
		this.response = response;
		this.rewardCode = rewardCode;
		this.storeCode = storeCode;
		this.storeName = storeName;
		this.transCode = transCode;
		this.transDate = transDate;

	}

	public String getActNumber() {
		return actNumber;
	}

	public void setActNumber(String actNumber) {
		this.actNumber = actNumber;
	}

	public String getActRefNum() {
		return actRefNum;
	}

	public void setActRefNum(String actRefNum) {
		this.actRefNum = actRefNum;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCashierCode() {
		return cashierCode;
	}

	public void setCashierCode(String cashierCode) {
		this.cashierCode = cashierCode;
	}

	public String getCashierName() {
		return cashierName;
	}

	public void setCashierName(String cashierName) {
		this.cashierName = cashierName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCommerceCode() {
		return commerceCode;
	}

	public void setCommerceCode(String commerceCode) {
		this.commerceCode = commerceCode;
	}

	public String getCommerceName() {
		return commerceName;
	}

	public void setCommerceName(String commerceName) {
		this.commerceName = commerceName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGhostCard() {
		return ghostCard;
	}

	public void setGhostCard(String ghostCard) {
		this.ghostCard = ghostCard;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMemberNum() {
		return memberNum;
	}

	public void setMemberNum(String memberNum) {
		this.memberNum = memberNum;
	}

	public String getMilePrice() {
		return milePrice;
	}

	public void setMilePrice(String milePrice) {
		this.milePrice = milePrice;
	}

	public String getMiles() {
		return miles;
	}

	public void setMiles(String miles) {
		this.miles = miles;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getPointType() {
		return pointType;
	}

	public void setPointType(String pointType) {
		this.pointType = pointType;
	}

	public String getProcessDate() {
		return processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

	public String getPromCode() {
		return promCode;
	}

	public void setPromCode(String promCode) {
		this.promCode = promCode;
	}

	public String getPromName() {
		return promName;
	}

	public void setPromName(String promName) {
		this.promName = promName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getRewardCode() {
		return rewardCode;
	}

	public void setRewardCode(String rewardCode) {
		this.rewardCode = rewardCode;
	}

	public String getStoreCode() {
		return storeCode;
	}

	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getVoucherId() {
		return voucherId;
	}

	public void setVoucherId(String voucherId) {
		this.voucherId = voucherId;
	}

	public String getVoucherOrigin() {
		return voucherOrigin;
	}

	public void setVoucherOrigin(String voucherOrigin) {
		this.voucherOrigin = voucherOrigin;
	}

	public String getAuthNumber() {
		return authNumber;
	}

	public void setAuthNumber(String authNumber) {
		this.authNumber = authNumber;
	}

	public String getAuthOrigin() {
		return authOrigin;
	}

	public void setAuthOrigin(String authOrigin) {
		this.authOrigin = authOrigin;
	}

}
