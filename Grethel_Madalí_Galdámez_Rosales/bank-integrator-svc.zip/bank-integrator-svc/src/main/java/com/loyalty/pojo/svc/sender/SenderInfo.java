package com.loyalty.pojo.svc.sender;

import java.util.List;

public class SenderInfo {
	private String senderCode;
	private String senderUserName;
	private String senderPassword;
	private char status;
	private List<SenderIp> senderIp;
		
	public SenderInfo() {
		super();
	}
	public SenderInfo(String senderCode, String senderUserName, String senderPassword, char status,
			List<SenderIp> senderIp) {
		super();
		this.senderCode = senderCode;
		this.senderUserName = senderUserName;
		this.senderPassword = senderPassword;
		this.status = status;
		this.senderIp = senderIp;
	}
	public String getSenderCode() {
		return senderCode;
	}
	public void setSenderCode(String senderCode) {
		this.senderCode = senderCode;
	}
	public String getSenderUserName() {
		return senderUserName;
	}
	public void setSenderUserName(String senderUserName) {
		this.senderUserName = senderUserName;
	}
	public String getSenderPassword() {
		return senderPassword;
	}
	public void setSenderPassword(String senderPassword) {
		this.senderPassword = senderPassword;
	}
	public char getStatus() {
		return status;
	}
	public void setStatus(char status) {
		this.status = status;
	}
	public List<SenderIp> getSenderIp() {
		return senderIp;
	}
	public void setSenderIp(List<SenderIp> senderIp) {
		this.senderIp = senderIp;
	}		
	
}
