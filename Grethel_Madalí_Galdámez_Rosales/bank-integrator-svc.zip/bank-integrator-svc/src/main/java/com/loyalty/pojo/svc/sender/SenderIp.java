package com.loyalty.pojo.svc.sender;

public class SenderIp {
	
	private String senderCode;
	private String ipInic;
	private String ipFin;
	private char status;
	
	public SenderIp() {
		super();
	}
	
	public SenderIp(String senderCode, String ipInic, String ipFin) {
		super();
		this.senderCode = senderCode;
		this.ipInic = ipInic;
		this.ipFin = ipFin;
	}	
	
	public SenderIp(String senderCode, String ipInic, String ipFin, char status) {
		super();
		this.senderCode = senderCode;
		this.ipInic = ipInic;
		this.ipFin = ipFin;
		this.status = status;
	}

	public SenderIp(String senderCode, String ipInic) {
		super();
		this.senderCode = senderCode;
		this.ipInic = ipInic;
	}

	public String getSenderCode() {
		return senderCode;
	}

	public void setSenderCode(String senderCode) {
		this.senderCode = senderCode;
	}

	public String getIpInic() {
		return ipInic;
	}

	public void setIpInic(String ipInic) {
		this.ipInic = ipInic;
	}

	public String getIpFin() {
		return ipFin;
	}

	public void setIpFin(String ipFin) {
		this.ipFin = ipFin;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}
	

}
