package com.loyalty.pojo.svc.store;

public class IntStoreUpdate {
	private StoreDetail storeDet;
	private StoreConfiguration storeConf;
	
	public StoreDetail getStoreDet() {
		return storeDet;
	}
	public void setStoreDet(StoreDetail storeDet) {
		this.storeDet = storeDet;
	}
	public StoreConfiguration getStoreConf() {
		return storeConf;
	}
	public void setStoreConf(StoreConfiguration storeConf) {
		this.storeConf = storeConf;
	}
	
	
}
