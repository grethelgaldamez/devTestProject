package com.loyalty.pojo.svc.store;

public class LocationStore {
	private String idCountry;
	private String idState;
	private String idCity;
	private String nameCity;


	public LocationStore() {
		super();
	}

	public LocationStore(String idCountry,String idState, String idCity,String nameCity) {
		super();
		this.idCountry = idCountry;
		this.idState = idState;
		this.idCity = idCity;
		this.nameCity = nameCity;
	
	}
	
	
	public String getIdState() {
		return idState;
	}
	public void setIdState(String idState) {
		this.idState = idState;
	}
	public String getIdCity() {
		return idCity;
	}
	public void setIdCity(String idCity) {
		this.idCity = idCity;
	}
	
	public String getIdCountry() {
		return idCountry;
	}


	public void setIdCountry(String idCountry) {
		this.idCountry = idCountry;
	}

	public String getNameCity() {
		return nameCity;
	}

	public void setNameCity(String nameCity) {
		this.nameCity = nameCity;
	}

	
}
