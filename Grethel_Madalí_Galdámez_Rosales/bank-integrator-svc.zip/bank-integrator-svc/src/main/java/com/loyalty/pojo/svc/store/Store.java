package com.loyalty.pojo.svc.store;

public class Store {

	private String storeCode;
	private String storeName;
	private String storeCity;
	private String storeAddress;
	private char status;
	private String partnerCode; // éste es el código del aliado al que pertenece
								// el establecimiento

	private String storeState;
	private String storeCountry;
	

	public Store() {
		super();
	}

	public Store(String storeCode, 
			String storeName, 
			String storeCity, 
			String storeAddress, 
			String partnerCode,
			char status) {
		super();
		this.storeCode = storeCode;
		this.storeName = storeName;
		this.storeCity = storeCity;
		this.storeAddress = storeAddress;
		this.partnerCode = partnerCode;
		this.status = status;
	}
	
	public Store(String storeCode, String storeName, String storeCity, String storeAddress, char status,
			String partnerCode, String storeState, String storeCountry) {
		super();
		this.storeCode = storeCode;
		this.storeName = storeName;
		this.storeCity = storeCity;
		this.storeAddress = storeAddress;
		this.status = status;
		this.partnerCode = partnerCode;
		this.storeState = storeState;
		this.storeCountry = storeCountry;
	}

	public String getStoreState() {
		return storeState;
	}

	public void setStoreState(String storeState) {
		this.storeState = storeState;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	

	public String getStoreCode() {
		return storeCode;
	}

	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getStoreCity() {
		return storeCity;
	}

	public void setStoreCity(String storeCity) {
		this.storeCity = storeCity;
	}

	public String getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}
	
	
	public String getStoreCountry() {
		return storeCountry;
	}

	public void setStoreCountry(String storeCountry) {
		this.storeCountry = storeCountry;
	}


}
