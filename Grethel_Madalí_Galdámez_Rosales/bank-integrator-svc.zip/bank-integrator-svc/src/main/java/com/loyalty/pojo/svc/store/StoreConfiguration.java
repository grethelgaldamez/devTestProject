package com.loyalty.pojo.svc.store;


public class StoreConfiguration {
	
	private String storeConfigId;
	private String billingPartner;
	private Double accrualRate;
	private Double redemptionRate;
	private Double minMilesForAcc;
	private Double minMilesForRed;
	private String startDate;
	private String endDate;
	private char activeFlag;
	
	public StoreConfiguration(){
		
	}
	public StoreConfiguration(String storeConfigId, String billingPartner, double accrualRate, double redemptionRate,
			double minMilesForAcc, double minMilesForRed, String startDate, String endDate, char activeFlag) {
		super();
		this.storeConfigId = storeConfigId;
		this.billingPartner = billingPartner;
		this.accrualRate = accrualRate;
		this.redemptionRate = redemptionRate;
		this.minMilesForAcc = minMilesForAcc;
		this.minMilesForRed = minMilesForRed;
		this.startDate = startDate;
		this.endDate = endDate;
		this.activeFlag = activeFlag;
	}
	public String getStoreConfigId() {
		return storeConfigId;
	}
	public void setStoreConfigId(String storeConfigId) {
		this.storeConfigId = storeConfigId;
	}
	public String getBillingPartner() {
		return billingPartner;
	}
	public void setBillingPartner(String billingPartner) {
		this.billingPartner = billingPartner;
	}
	public Double getAccrualRate() {
		return accrualRate;
	}
	public void setAccrualRate(Double accrualRate) {
		this.accrualRate = accrualRate;
	}
	public Double getRedemptionRate() {
		return redemptionRate;
	}
	public void setRedemptionRate(Double redemptionRate) {
		this.redemptionRate = redemptionRate;
	}
	public Double getMinMilesForAcc() {
		return minMilesForAcc;
	}
	public void setMinMilesForAcc(Double minMilesForAcc) {
		this.minMilesForAcc = minMilesForAcc;
	}
	public Double getMinMilesForRed() {
		return minMilesForRed;
	}
	public void setMinMilesForRed(Double minMilesForRed) {
		this.minMilesForRed = minMilesForRed;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public char getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(char activeFlag) {
		this.activeFlag = activeFlag;
	}
	
	
	

}
