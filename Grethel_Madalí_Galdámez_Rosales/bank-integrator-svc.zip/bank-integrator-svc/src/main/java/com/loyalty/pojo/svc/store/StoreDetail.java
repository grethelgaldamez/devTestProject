package com.loyalty.pojo.svc.store;

import java.util.List;

public class StoreDetail {
	
	private String storeCode;
	private String storeName;
	private String senderCode;
	private String storeAddress;
	private String storeCountry;
	private String storeState;
	private String storeCity;
	private String latitude;
	private String longitude;
	private String IATACode;
	private String currency;
	private String phoneNumber;
	private char status;
	private String partnerCode; //éste es el código del aliado al que pertenece el establecimiento
	private List<StoreConfiguration> conf;
	
	public StoreDetail() {
		super();
	}
	
	public StoreDetail(String storeCode, String storeName, String senderCode, String storeAddress, String storeCountry,
			String storeState, String storeCity, String latitude, String longitude, String iATACode, String currency,
			String phoneNumber, char status, String partnerCode, List<StoreConfiguration> conf) {
		super();
		this.storeCode = storeCode;
		this.storeName = storeName;
		this.senderCode = senderCode;
		this.storeAddress = storeAddress;
		this.storeCountry = storeCountry;
		this.storeState = storeState;
		this.storeCity = storeCity;
		this.latitude = latitude;
		this.longitude = longitude;
		this.IATACode = iATACode;
		this.currency = currency;
		this.phoneNumber = phoneNumber;
		this.status = status;
		this.partnerCode = partnerCode;
		this.conf = conf;
	}
	public String getSenderCode() {
		return senderCode;
	}
	public void setSenderCode(String senderCode) {
		this.senderCode = senderCode;
	}
	public String getStoreCountry() {
		return storeCountry;
	}
	public void setStoreCountry(String storeCountry) {
		this.storeCountry = storeCountry;
	}
	public String getStoreState() {
		return storeState;
	}
	public void setStoreState(String storeState) {
		this.storeState = storeState;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getIATACode() {
		return IATACode;
	}
	public void setIATACode(String iATACode) {
		this.IATACode = iATACode;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public char getStatus() {
		return status;
	}
	public void setStatus(char status) {
		this.status = status;
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getStoreCode() {
		return storeCode;
	}
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getStoreCity() {
		return storeCity;
	}
	public void setStoreCity(String storeCity) {
		this.storeCity = storeCity;
	}
	public String getStoreAddress() {
		return storeAddress;
	}
	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}

	public List<StoreConfiguration> getConf() {
		return conf;
	}

	public void setConf(List<StoreConfiguration> conf) {
		this.conf = conf;
	}
	
	
}
