package com.loyalty.pojo.svc.transactions;

import java.io.Serializable;

public class Transaction implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String partnerCode;
	private String lifemilesNumber;
	private String autNumber;
	private String certificationNumber;
	private String transDate;
	//private String processDate;
	private String clientName;
	private Integer regularMiles;
	private String store;
	private Integer promotionMiles;
	private Double amount;
	private Integer totalMiles;
	private String pointTypeCode;
	private String transactionType;
	private String bonusCode;
	private String email;
	private String activityStatus;
	

	private String notificationType;
	
	
	public Transaction(String partnerCode, String lifemilesNumber, String autNumber, String certificationNumber,String transDate, String processDate,
			String clientName, Integer regularMiles, String store, Integer promotionMiles, Double amount,
			Integer totalMiles, String pointTypeCode,String transactionType,String bonusCode, String email, String notificationType) {
		super();
		this.partnerCode = partnerCode;
		this.lifemilesNumber = lifemilesNumber;
		this.autNumber = autNumber;
		this.certificationNumber = certificationNumber;
		this.transDate = transDate;
		this.clientName = clientName;
		this.regularMiles = regularMiles;
		this.store = store;
		this.pointTypeCode = pointTypeCode;
		this.promotionMiles = promotionMiles;
		this.amount = amount;
		this.totalMiles = totalMiles;
		this.bonusCode = bonusCode;
		this.email = email;
		this.notificationType = notificationType;
	}

	public Transaction(){
		
		
	}
	

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getCertificationNumber() {
		return certificationNumber;
	}

	public void setCertificationNumber(String certificationNumber) {
		this.certificationNumber = certificationNumber;
	}

	public String getBonusCode() {
		return bonusCode;
	}

	public void setBonusCode(String bonusCode) {
		this.bonusCode = bonusCode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getLifemilesNumber() {
		return lifemilesNumber;
	}
	public void setLifemilesNumber(String lifemilesNumber) {
		this.lifemilesNumber = lifemilesNumber;
	}
	
	public String getAutNumber() {
		return autNumber;
	}

	public void setAutNumber(String autNumber) {
		this.autNumber = autNumber;
	}
	
	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public Integer getRegularMiles() {
		return regularMiles;
	}
	public void setRegularMiles(Integer regularMiles) {
		this.regularMiles = regularMiles;
	}
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
		this.store = store;
	}
	public Integer getPromotionMiles() {
		return promotionMiles;
	}
	public void setPromotionMiles(Integer promotionMiles) {
		this.promotionMiles = promotionMiles;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Integer getTotalMiles() {
		return totalMiles;
	}
	public void setTotalMiles(Integer totalMiles) {
		this.totalMiles = totalMiles;
	}
	public String getPointTypeCode() {
		return pointTypeCode;
	}

	public void setPointTypeCode(String pointTypeCode) {
		this.pointTypeCode = pointTypeCode;
	}
	
	public String getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}
	
	
	

}
