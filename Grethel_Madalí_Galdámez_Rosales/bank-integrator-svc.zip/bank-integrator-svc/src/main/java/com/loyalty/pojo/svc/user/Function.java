package com.loyalty.pojo.svc.user;

public class Function {
	private String funcCode;
	private String funcName;
	private boolean access;
	
	public Function(){
		super();
		
	}
	
	public Function(String funcCode, String funcName, boolean access) {
		super();
		this.funcCode = funcCode;
		this.funcName = funcName;
		this.access = access;
	}
	
	public Function(String funcCode,String funcName){
		super();
		this.funcCode = funcCode;
		this.funcName = funcName;
	}
	public String getFuncCode() {
		return funcCode;
	}
	public void setFuncCode(String funcCode) {
		this.funcCode = funcCode;
	}
	public String getFuncName() {
		return funcName;
	}
	public void setFuncName(String funcName) {
		this.funcName = funcName;
	}
	public boolean isAccess() {
		return access;
	}
	public void setAccess(boolean access) {
		this.access = access;
	}

}
