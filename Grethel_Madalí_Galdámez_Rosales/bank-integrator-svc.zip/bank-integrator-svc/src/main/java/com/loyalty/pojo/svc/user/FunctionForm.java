package com.loyalty.pojo.svc.user;

public class FunctionForm {
	private String partnerCode;
	private String userCode;
	private String userType;
	
	public FunctionForm() {
		super();
	}
	public FunctionForm(String partnerCode, String userCode, String userType) {
		super();
		this.partnerCode = partnerCode;
		this.userCode = userCode;
		this.userType = userType;
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
}
