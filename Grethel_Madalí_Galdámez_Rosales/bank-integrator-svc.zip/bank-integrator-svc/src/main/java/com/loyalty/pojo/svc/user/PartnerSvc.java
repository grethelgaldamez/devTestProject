package com.loyalty.pojo.svc.user;

public class PartnerSvc {

	private String code;
	private String name;
	private boolean access;


	public PartnerSvc() {
		super();
	}
	
	public PartnerSvc(String code, String name, Boolean access) {
		super();
		this.code = code;
		this.name = name;
		this.access = access;
	}

	public boolean isAccess() {
		return access;
	}

	public void setAccess(boolean access) {
		this.access = access;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	

}
