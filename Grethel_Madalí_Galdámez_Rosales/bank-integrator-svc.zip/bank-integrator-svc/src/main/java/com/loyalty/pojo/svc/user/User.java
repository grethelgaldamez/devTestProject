package com.loyalty.pojo.svc.user;

import java.util.List;

import com.loyalty.pojo.svc.workflow.ApproverSettings;

public class User {
	private String firstName;
	private String secondName;
	private String surname; //last name
	private String secondSurname; //second last name
	private String email;
	private String userName; //codigo
	private String password;
	private String confPwd; //AGREGADO POR MI LPMS
	private String documentNumber;
	private String position;
	private Character userState; //estado
	private String codGroup;
	private String codPartner;
	private String userType;
	private List<Function> functions;
	private String createdDate;
	private String createdOrModifyBy; // AGREGADO POR MI LPMS
	private List<PartnerSvc> partners; // AGREGADO POR MI LPMS, solo es para agregar o actualizar y cuando es tipo grupo se usará
	
	//SOLO APLICA PARA RECIBIR DE LA WEB
	private String[] cmbFunctions;
	private String[] multiFunctions;
	private String[] cmbPartners;
	private String[] multiPartners;
	
	private Boolean isApprover;
	private ApproverSettings approverSettings;

	
	public String[] getCmbFunctions() {
		return cmbFunctions;
	}


	public void setCmbFunctions(String[] cmbFunctions) {
		this.cmbFunctions = cmbFunctions;
	}


	public String[] getMultiFunctions() {
		return multiFunctions;
	}


	public void setMultiFunctions(String[] multiFunctions) {
		this.multiFunctions = multiFunctions;
	}


	public String[] getCmbPartners() {
		return cmbPartners;
	}


	public void setCmbPartners(String[] cmbPartners) {
		this.cmbPartners = cmbPartners;
	}


	public String[] getMultiPartners() {
		return multiPartners;
	}


	public void setMultiPartners(String[] multiPartners) {
		this.multiPartners = multiPartners;
	}


	public List<PartnerSvc> getPartners() {
		return partners;
	}


	public void setPartners(List<PartnerSvc> partners) {
		this.partners = partners;
	}


	public String getUserType() {
		return userType;
	}


	public void setUserType(String userType) {
		this.userType = userType;
	}


	public User() {
		super();
	}
	

	public List<Function> getFunctions() {
		return functions;
	}


	public void setFunctions(List<Function> functions) {
		this.functions = functions;
	}




	public User(String firstName, String secondName, String surname, String secondSurname, String email,
			String userName, String password, String documentNumber, String position, Character userState,
			String codGroup, String codPartner,String createdDate,String userType) {
		super();
		this.firstName = firstName;
		this.secondName = secondName;
		this.surname = surname;
		this.secondSurname = secondSurname;
		this.email = email;
		this.userName = userName;
		this.password = password;
		this.documentNumber = documentNumber;
		this.position = position;
		this.userState = userState;
		this.codGroup = codGroup;
		this.codPartner = codPartner;
		this.createdDate = createdDate;
		this.userType = userType;
	}


	public String getCodGroup() {
		return codGroup;
	}


	public void setCodGroup(String codGroup) {
		this.codGroup = codGroup;
	}


	public String getCodPartner() {
		return codPartner;
	}


	public void setCodPartner(String codPartner) {
		this.codPartner = codPartner;
	}


	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getSecondSurname() {
		return secondSurname;
	}
	public void setSecondSurname(String secondSurname) {
		this.secondSurname = secondSurname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public Character getUserState() {
		return userState;
	}
	public void setUserState(Character userState) {
		this.userState = userState;
	}


	public String getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}


	public String getCreatedOrModifyBy() {
		return createdOrModifyBy;
	}


	public void setCreatedOrModifyBy(String createdOrModifyBy) {
		this.createdOrModifyBy = createdOrModifyBy;
	}


	public String getConfPwd() {
		return confPwd;
	}


	public void setConfPwd(String confPwd) {
		this.confPwd = confPwd;
	}


	public Boolean getIsApprover() {
		return isApprover;
	}


	public void setIsApprover(Boolean isApprover) {
		this.isApprover = isApprover;
	}


	public ApproverSettings getApproverSettings() {
		return approverSettings;
	}


	public void setApproverSettings(ApproverSettings approverSettings) {
		this.approverSettings = approverSettings;
	}

	
}
