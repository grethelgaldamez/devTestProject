package com.loyalty.pojo.svc.user;


//SIRVE PARA GUARDAR USUARIO
public class UserDetail {
	private User user;
	//faltarian los de workflow

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
}
