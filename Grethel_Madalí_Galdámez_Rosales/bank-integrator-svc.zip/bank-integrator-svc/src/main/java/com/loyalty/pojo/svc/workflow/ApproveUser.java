package com.loyalty.pojo.svc.workflow;

public class ApproveUser {
	private String substitute;
	private String areaCode;
	private String segType; //segmentation type: F o C
	private boolean  outOfOffice;
	
	public String getSubstitute() {
		return substitute;
	}
	public void setSubstitute(String substitute) {
		this.substitute = substitute;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getSegType() {
		return segType;
	}
	public void setSegType(String segType) {
		this.segType = segType;
	}
	public boolean isOutOfOffice() {
		return outOfOffice;
	}
	public void setOutOfOffice(boolean outOfOffice) {
		this.outOfOffice = outOfOffice;
	}
	
}
