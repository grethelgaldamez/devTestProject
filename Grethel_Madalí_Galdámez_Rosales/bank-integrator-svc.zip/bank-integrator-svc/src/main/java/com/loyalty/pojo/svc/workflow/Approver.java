package com.loyalty.pojo.svc.workflow;

public class Approver {	
	private String code;
	private String name;
	private Character segmentationType;
		
	public Approver() {
		super();
	}
	public Approver(String code, String name, Character segmentationType) {
		super();		
		this.code = code;
		this.name = name;
		this.segmentationType = segmentationType;
	}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Character getSegmentationType() {
		return segmentationType;
	}
	public void setSegmentationType(Character segmentationType) {
		this.segmentationType = segmentationType;
	}
}
