package com.loyalty.pojo.svc.workflow;

import java.util.List;

public class ApproverSettings {
	private String userCode;
	private String areaCode;
	private String substitute;
	private String segType;
	private boolean outOfOffice;
	private String createdOrModifyBy;
	
	private List<Flow> flowPartner;
	

	//SOLO APLICA PARA RECIBIR DE LA WEB
	private String[] cmbFlowPar;
	private String[] multiFlowPar;
	
	public ApproverSettings() {
		super();
	}

	public ApproverSettings(String userCode,  String areaCode, String substitute, String segType,
			boolean outOfOffice, List<Flow> flowPartner) {
		super();
		this.userCode = userCode;
		this.areaCode = areaCode;
		this.substitute = substitute;
		this.segType = segType;
		this.outOfOffice = outOfOffice;
		this.flowPartner = flowPartner;
	}


	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}


	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getSubstitute() {
		return substitute;
	}
	public void setSubstitute(String substitute) {
		this.substitute = substitute;
	}
	public String getSegType() {
		return segType;
	}
	public void setSegType(String segType) {
		this.segType = segType;
	}
	public boolean isOutOfOffice() {
		return outOfOffice;
	}
	public void setOutOfOffice(boolean outOfOffice) {
		this.outOfOffice = outOfOffice;
	}
	public List<Flow> getFlowPartner() {
		return flowPartner;
	}
	public void setFlowPartner(List<Flow> flowPartner) {
		this.flowPartner = flowPartner;
	}

	public String[] getCmbFlowPar() {
		return cmbFlowPar;
	}

	public void setCmbFlowPar(String[] cmbFlowPar) {
		this.cmbFlowPar = cmbFlowPar;
	}

	public String[] getMultiFlowPar() {
		return multiFlowPar;
	}

	public void setMultiFlowPar(String[] multiFlowPar) {
		this.multiFlowPar = multiFlowPar;
	}

	public String getCreatedOrModifyBy() {
		return createdOrModifyBy;
	}

	public void setCreatedOrModifyBy(String createdOrModifyBy) {
		this.createdOrModifyBy = createdOrModifyBy;
	}
	
	
	
	
	

}
