package com.loyalty.pojo.svc.workflow;

public class HistRequest {
	private String codRequest;
	private String approveType;
	private String partner;
	private String requestDate;
	private String responseDate;
	private String status;
	private String user;
	private String aprvsObtained;
	
	public HistRequest() {
		super();
	}
	

	
	public HistRequest(String codRequest, String approveType, String partner, String requestDate, String responseDate,
			String status, String user, String aprvsObtained) {
		super();
		this.codRequest = codRequest;
		this.approveType = approveType;
		this.partner = partner;
		this.requestDate = requestDate;
		this.responseDate = responseDate;
		this.status = status;
		this.user = user;
		this.aprvsObtained = aprvsObtained;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}


	public String getCodRequest() {
		return codRequest;
	}
	public void setCodRequest(String codRequest) {
		this.codRequest = codRequest;
	}
	public String getApproveType() {
		return approveType;
	}
	public void setApproveType(String approveType) {
		this.approveType = approveType;
	}
	public String getPartner() {
		return partner;
	}
	public void setPartner(String partner) {
		this.partner = partner;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public String getResponseDate() {
		return responseDate;
	}
	public void setResponseDate(String responseDate) {
		this.responseDate = responseDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAprvsObtained() {
		return aprvsObtained;
	}
	public void setAprvsObtained(String aprvsObtained) {
		this.aprvsObtained = aprvsObtained;
	}
	
	
	

}
