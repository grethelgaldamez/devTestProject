package com.loyalty.pojo.svc.workflow;

import java.util.List;

public class InfoRequest {
	private Request request;
	private List<ValueRequest> lstValueR;
	public InfoRequest() {
		super();
	}
	public InfoRequest(Request request, List<ValueRequest> lstValueR) {
		super();
		this.request = request;
		this.lstValueR = lstValueR;
	}
	public Request getRequest() {
		return request;
	}
	public void setRequest(Request request) {
		this.request = request;
	}
	public List<ValueRequest> getLstValueR() {
		return lstValueR;
	}
	public void setLstValueR(List<ValueRequest> lstValueR) {
		this.lstValueR = lstValueR;
	}	
}
