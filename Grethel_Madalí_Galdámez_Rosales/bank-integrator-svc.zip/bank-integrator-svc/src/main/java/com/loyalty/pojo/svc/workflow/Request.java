package com.loyalty.pojo.svc.workflow;

public class Request {
	private String codeFlow;
	private Character flowStatus;
	private String partnerName;
	private String userCode;
	private String detailFail;
	public Request() {
		super();
	}	

	public Request(String codeFlow, Character flowStatus, String partnerName, String userCode) {
		super();
		this.codeFlow = codeFlow;
		this.flowStatus = flowStatus;
		this.partnerName = partnerName;
		this.userCode = userCode;
	}

	public String getCodeFlow() {
		return codeFlow;
	}
	public void setCodeFlow(String codeFlow) {
		this.codeFlow = codeFlow;
	}
	public Character getFlowStatus() {
		return flowStatus;
	}
	public void setFlowStatus(Character flowStatus) {
		this.flowStatus = flowStatus;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getDetailFail() {
		return detailFail;
	}

	public void setDetailFail(String detailFail) {
		this.detailFail = detailFail;
	}
	
}
