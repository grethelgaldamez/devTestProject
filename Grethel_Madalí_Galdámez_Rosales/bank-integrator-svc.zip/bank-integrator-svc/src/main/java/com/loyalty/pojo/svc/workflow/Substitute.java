package com.loyalty.pojo.svc.workflow;

public class Substitute {
	private String userCode;
	public Substitute() {
		super();
	}
	public Substitute(String userCode) {
		super();
		this.userCode = userCode;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	
}
