package com.loyalty.pojo.svc.workflow;

import java.util.List;

public class TableApprovers {
	private String[] header;
	private List<String[]> body;
	public String[] getHeader() {
		return header;
	}
	public void setHeader(String[] header) {
		this.header = header;
	}
	public List<String[]> getBody() {
		return body;
	}
	public void setBody(List<String[]> body) {
		this.body = body;
	}
	
}
