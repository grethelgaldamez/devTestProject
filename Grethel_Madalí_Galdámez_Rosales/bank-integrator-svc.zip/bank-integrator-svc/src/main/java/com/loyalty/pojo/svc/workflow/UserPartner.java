package com.loyalty.pojo.svc.workflow;

public class UserPartner {
	private String partnerCode;
	private String partnerName;
	private boolean active;
	private char status;
	
	public UserPartner() {
		super();
	}
	
	public UserPartner(String partnerCode, String partnerName, Boolean active) {
		super();
		this.partnerCode = partnerCode;
		this.partnerName = partnerName;
		this.active = active;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	
	
}
