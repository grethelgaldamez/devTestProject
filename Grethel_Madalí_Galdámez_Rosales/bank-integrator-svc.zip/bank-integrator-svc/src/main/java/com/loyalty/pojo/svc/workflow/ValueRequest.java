package com.loyalty.pojo.svc.workflow;

public class ValueRequest {
	private String nomCampo;
	private String valorActual;
	private String valorNuevo;
		
	public ValueRequest() {
		super();
	}

	public ValueRequest(String nomCampo, String valorActual, String valorNuevo) {
		super();
		this.nomCampo = nomCampo;
		this.valorActual = valorActual;
		this.valorNuevo = valorNuevo;
	}

	public String getNomCampo() {
		return nomCampo;
	}

	public void setNomCampo(String nomCampo) {
		this.nomCampo = nomCampo;
	}

	public String getValorActual() {
		return valorActual;
	}

	public void setValorActual(String valorActual) {
		this.valorActual = valorActual;
	}

	public String getValorNuevo() {
		return valorNuevo;
	}

	public void setValorNuevo(String valorNuevo) {
		this.valorNuevo = valorNuevo;
	}
	
}
