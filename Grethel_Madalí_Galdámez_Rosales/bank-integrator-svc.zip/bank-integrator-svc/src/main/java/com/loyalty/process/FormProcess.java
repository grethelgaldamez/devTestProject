package com.loyalty.process;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.loyalty.builder.values.ValueBuilder;
import com.loyalty.data.fields.IFieldData;
import com.loyalty.pojo.HeaderRequest;
import com.loyalty.pojo.envelope.Envelope;
import com.loyalty.pojo.envelope.Message;
import com.loyalty.pojo.envelope.Status;
import com.loyalty.pojo.fields.Field;
import com.loyalty.pojo.fields.Form;
import com.loyalty.pojo.fields.Section;
import com.loyalty.pojo.fields.Value;
import com.loyalty.pojo.svc.cashier.Cashier;
import com.loyalty.pojo.svc.cashier.CashierSearchType;
import com.loyalty.pojo.svc.giftcard.GiftCard;
import com.loyalty.pojo.svc.mcv.MilesConv;
import com.loyalty.pojo.svc.member.MemberDetail;
import com.loyalty.pojo.svc.partner.Partner;
import com.loyalty.pojo.svc.partner.PartnerDetail;
import com.loyalty.pojo.svc.prepurchase.HistPrePurchase;
import com.loyalty.pojo.svc.prepurchase.PrePurchase;
import com.loyalty.pojo.svc.prepurchase.PrePurchaseList;
import com.loyalty.pojo.svc.promo.Promo;
import com.loyalty.pojo.svc.redemption.Redemption;
import com.loyalty.pojo.svc.report.ReportCashier;
import com.loyalty.pojo.svc.report.ReportGiftCard;
import com.loyalty.pojo.svc.report.ReportMilesConv;
import com.loyalty.pojo.svc.report.ReportRedemption;
import com.loyalty.pojo.svc.report.ReportTransaction;
import com.loyalty.pojo.svc.report.TransactionReport;
import com.loyalty.pojo.svc.sender.SenderInfo;
import com.loyalty.pojo.svc.store.StoreDetail;
import com.loyalty.pojo.svc.transactions.Transaction;
import com.loyalty.pojo.svc.user.Function;
import com.loyalty.pojo.svc.user.User;
import com.loyalty.pojo.svc.workflow.ApproveUser;
import com.loyalty.pojo.svc.workflow.Flow;
import com.loyalty.pojo.svc.workflow.HistRequest;
import com.loyalty.pojo.svc.workflow.InfoRequest;
import com.loyalty.pojo.svc.workflow.TableApprovers;
import com.loyalty.pojo.svc.workflow.UserPartner;
import com.loyalty.utils.ResponseCode;
import com.loyalty.utils.ResponseMsg;

@SuppressWarnings("unchecked")
@Service("FormProcess")
public class FormProcess implements IFormProcess<Form>{

	private IFieldData<Form> form;
	private Environment env;
	private ApplicationContext context;
    private Logger log;
	
    @org.springframework.beans.factory.annotation.Value("${log-activator.activate}")
	String logFlag;

    @org.springframework.beans.factory.annotation.Value("${config.not-apply}")
	String notApply;
    
    
    
	public FormProcess(
			@Qualifier("BeanDataField") IFieldData<Form> form,
			Environment env,
			ApplicationContext context) {
		this.form = form;
		this.env = env;
		this.context = context;

		this.log = LoggerFactory.getLogger("com.loyalty.logger");
	}

	public Status processForm(Form formPojo, Object...params){
		Status status = new Status();
		boolean res = true;
		if(formPojo != null) {
			//obtener values para los campos
			if(formPojo.getSections() != null && !formPojo.getSections().isEmpty()){
				for(Section s: formPojo.getSections()){
					if(s.getFields() != null && !s.getFields().isEmpty()){
						for(Field<Value> f: s.getFields()){
							if(context.containsBean(f.getId())){
								ValueBuilder<Value> builder = (ValueBuilder<Value>) context.getBean(f.getId());
								
								Field<Value> field = builder.build(f, params);
								if(field == null){
									status.setCode(ResponseCode.RENDER_ERROR);
									status.setResult(ResponseMsg.RENDER_ERROR);
									res = false;
									break;
								}
							}
							if("Y".equals(f.getRequired()) && f.getLabel() != null) {
								f.setLabel(f.getLabel() + " *");
							}
						}
					}
					else{
						res = false;
						status.setCode(ResponseCode.NO_FIELDS);
						status.setResult(ResponseMsg.NO_FIELDS);
						log.error("processForm field. Message:" + ResponseMsg.NO_FIELDS);
					}
				}
			}
			else{
				res = false;
				status.setCode(ResponseCode.NO_SECTIONS);
				status.setResult(ResponseMsg.NO_SECTIONS);
				log.error("processForm. Message:" + ResponseMsg.NO_SECTIONS);
			}

			if(res){
				status.setCode(ResponseCode.SUCCESS);
				status.setResult(ResponseMsg.SUCCESS);
			}
			else{
				formPojo.setSections(null);
				formPojo.setMessages(null);
			}
		}
		else{
			status.setCode(ResponseCode.RENDER_ERROR);
			status.setResult(ResponseMsg.RENDER_ERROR);
			log.error("processForm. NO FORM. Message:" + ResponseMsg.RENDER_ERROR);
		}

		return status;
	}
	
	public Form getFields(String formName, HeaderRequest header){
		return form.retrieveFormFields(formName, header.getUser());
	}
/*
	@Override
	public Envelope<Status, Form> retrievePartnerForm(HeaderRequest header) {
 		Form formPojo = null;
		Status status = new Status();
		PrePurchaseList prepurchases = null;
		PartnerDetail<?> partnerDet;
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Partner Form");
		}

		if(header != null){
			String partnerCode = header.getPartnerCode();
			String userType = header.getUserType();
			String userCode = header.getUser();
			
			 //se llama a servicio de usuarios
			// si es tipo aliado llamar partnerRetail o partnerMcv porque se muestra el formulario completo
			if(userPa.equals(userType)){
				partnerDet = partner.retrievePartnerDetail(partnerCode);
				
				//validando si vienen campos nulos
				if(partnerDet == null) {
					status.setCode(ResponseCode.NULL_DATA);
					status.setResult(ResponseMsg.NULL_DATA);
				}
				else{
				
					if(env.getProperty("config.endpoints.partner.form-types.retail").equals(partnerDet.getConfType()))
						formPojo = getFields(env.getProperty("config.form-names.partner-retail"), header);
					else if(env.getProperty("config.endpoints.partner.form-types.miles-conv").equals(partnerDet.getConfType())){
						formPojo = getFields(env.getProperty("config.form-names.partner-mcv"), header);
						//quitando llamado a pre compras
					}
					else{
						formPojo = getFields(env.getProperty("config.form-names.partner-grl"), header);
					}
					status = processForm(formPojo, partnerCode, partnerDet, prepurchases,userCode, userType);
				}
			}
			else{
				
				 * Partner 1 será:
				 * * Para usuarios LM: combobox aliado y boton ver info
				 * * Para usuarios Grupo: comobox aliado y boton ver info
				 * * Para comercio: no existe
				 * 
				formPojo = getFields(env.getProperty("config.form-names.partner-detail"), header); // header:S
				status = processForm(formPojo, partnerCode,null,"",userCode, userType);
			}
		}
		else{
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve Partner Info Error. Message:" + status.getResult());
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve Partner Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrievePartnerDetailForm(HeaderRequest header, String partnerCode) {
		Form formPojo = null;
		Status status = new Status();
		PrePurchaseList prepurchases = null;
		PartnerDetail<?> partnerDet;
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Partner Detail Form");
		}
		
		if(header != null){

			//String userType = form.retrieveUserType(partnerUser); //se llama a servicio de usuarios
			partnerDet = partner.retrievePartnerDetail(partnerCode);
			
			//validando si vienen campos nulos
			if(partnerDet == null) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			if(env.getProperty("config.endpoints.partner.form-types.retail").equals(partnerDet.getConfType()))
				formPojo = getFields(env.getProperty("config.form-names.partner-retail"), header);
			else if(env.getProperty("config.endpoints.partner.form-types.miles-conv").equals(partnerDet.getConfType())){
				formPojo = getFields(env.getProperty("config.form-names.partner-mcv"), header);
				//quitando llamado a pre compras
			}
			else
				formPojo = getFields(env.getProperty("config.form-names.partner-grl"), header);
			
			status = processForm(formPojo, partnerCode, partnerDet, prepurchases, 
					header.getUser(), header.getUserType());
			
		}
		else{
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve Partner Detail Error. Message:" + status.getResult());
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve Partner Detail Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveFirstStoreForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve First Store Form");
		}
		
		if(header != null){
			 //se llama a servicio de usuarios
			formPojo = getFields(env.getProperty("config.form-names.stores"), header);
			status = processForm(formPojo, header.getPartnerCode(),
					"","",
					header.getUser(), header.getUserType(),
					false);
		}
		else{
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve First Store Form Error.  Message:" + status.getResult());
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve First Store Form");
		}
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveStoreDetailFormData(HeaderRequest header, 
			String partnerCode,
			String storeCode) {
		Status status = new Status();
		Form formPojo = null;
		StoreDetail store ;
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Store Detail Form");
		}
		
		if(header != null){
			
			store = storeData.retrieveStoreDetails(partnerCode, storeCode);
			
			//validando si vienen campos nulos
			if(store == null || store.getPartnerCode().isEmpty()) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			formPojo = getFields(env.getProperty("config.form-names.store-detail"), header);
			
			status = processForm(formPojo,partnerCode,store,store.getConf(), header.getUserType());	
		}else{
			
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve Store Detail Form Error. Message:" + status.getResult());
			
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve Store Detail Form: Input Missing");
		}
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveStoresValues(HeaderRequest header, String partnerCode) {
		Form form1 = new Form();
		
		List<Section> sections = new ArrayList<>();
		Section sec = new Section();
		
		List<Field<Value>> fields = new ArrayList<>();
		Field<Value> f =  new Field<>();
		f.setId("ddlStore");
		fields.add(f);
		sec.setFields(fields);
		sections.add(sec);
		form1.setSections(sections);
		
		Status status = processForm(form1, partnerCode, null, null, null, header, true);
				
		return new Message<>(status, form1);
	}

	@Override
	public Envelope<Status, Form> retrieveHistoryPromotions(HeaderRequest header, String partnerCode) {
		Form formPojo = null;
		Status status = new Status();
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve History Promotions Form");
		}
		
		if(header != null){

			List<Promo> list = promo.retrievePromos(header.getUserType(), partnerCode, header.getUser());

			if(list != null && !list.isEmpty()){
				formPojo = getFields(env.getProperty("config.form-names.prom-hist"), header);
				status = processForm(formPojo, partnerCode, 
						header.getUserType(), header.getUser(),
						null, null, list);
			}
			else if(list == null){
				status.setCode(ResponseCode.NO_DATA);
				status.setResult(ResponseMsg.NO_DATA);
			}
			else if(list.isEmpty()){
				status.setCode(ResponseCode.NOT_FOUND);
				status.setResult(ResponseMsg.NOT_FOUND);
			}
		}
		else{
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve History Promotions  Message: header is mandatory");
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve History Promotions Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrievePartnerHisPromoForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		
		if("true".equals(logFlag)){
			log.info("Start retrievePartnerHisPromoForm");
		}
		
		if(header != null){
			
			
			if(userPa.equals(header.getUserType())){
				List<Promo> list = promo.retrievePromos(header.getUserType(), header.getPartnerCode(), header.getUser());
				
				if(list != null && !list.isEmpty()){
					formPojo = getFields(env.getProperty("config.form-names.prom-hist"), header);
					status = processForm(formPojo, header.getPartnerCode(), 
							header.getUserType(), header.getUser(),
							header.getUserType(), header.getUser(),
							list);
				}
				else if(list == null){
					status.setCode(ResponseCode.NO_DATA);
					status.setResult(ResponseMsg.NO_DATA);
				}
				else if(list.isEmpty()){
					status.setCode(ResponseCode.NOT_FOUND);
					status.setResult(ResponseMsg.NOT_FOUND);
				}
			}
			else{
				formPojo = getFields(env.getProperty("config.form-names.prom-partner"), header);

				status = processForm(formPojo, header.getPartnerCode(), 
						header.getUserType(), header.getUser(),
						header.getUserType(), header.getUser());
			}
			
			
		}
		else{
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("retrievePartnerHisPromoForm  Message: header is mandatory");
		}
		
		if("true".equals(logFlag)){
			log.info("End retrievePartnerHisPromoForm");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveAccPromotionForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Accrual Promotion Form");
		}
		
		
		if(header != null){
			 //se llama a servicio de usuarios
			formPojo = getFields(env.getProperty("config.form-names.prom-acc"), header);
			status = processForm(formPojo, header.getPartnerCode(), 
					new Promo(), env.getProperty("config.prom-types.accrual"),
					header.getUserType(), header.getUser());
		}
		else{
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve Accrual Promotion Error.  Message:" + status.getResult());
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve Accrual Promotion Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveInfoAccPromotionForm(HeaderRequest header, String partnerCode,
			String promoCode) {
		Form formPojo = null;
		Status status = new Status();
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Info Accrual Promotion Form");
		}
		
		if(header != null && promoCode != null && !promoCode.isEmpty()){

			Promo actualPromo = promo.retrievePromotion(partnerCode, promoCode);
			
			//validando si vienen campos nulos
			if(actualPromo == null || actualPromo.getPartnerCode().isEmpty()) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			String type = env.getProperty("config.prom-types.accrual");
			if(actualPromo.getPromoType().toString().equals(type)){
				formPojo = getFields(env.getProperty("config.form-names.info-prom-acc"), header);
				status = processForm(formPojo,header.getPartnerCode(),actualPromo,type,header.getUserType());
			}else{
				status.setCode(ResponseCode.INPUT_MISSING);
				status.setResult(ResponseMsg.INPUT_MISSING);	
				log.error("Retrieve Info Accrual Promotion Error. Promotion is not Accrual. Message: Promotion is not Accrual");
			}
			
			
		}else {
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);	
			log.error("Retrieve Info Accrual Promotion Error.  Message: header is mandatory");
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve Info Accrual Promotion Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveRedPromotionForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve Redemption Promotion Form");
		}
		
		
		if(header != null) {
			if(!userLm.equals(header.getUserType())){

				status.setCode(ResponseCode.NOT_ALLOWED);
				status.setResult(ResponseMsg.NOT_ALLOWED);
			}
			else{
				formPojo = getFields(env.getProperty("config.form-names.prom-ret"), header);
				status = processForm(formPojo, header.getPartnerCode(),
					new Promo(), env.getProperty("config.prom-types.redemption"), 
					header.getUserType(), header.getUser());
			}
		} else {
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve Redemption Promotion Error. Message: header is mandatory");
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve Redemption Promotion Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveInfoRedPromotionForm(HeaderRequest header, String partnerCode,
			String promoCode) {
		Form formPojo = null;
		Status status = new Status();	
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Info Redemption Promotion Form");
		}

		if(header != null && promoCode != null && !promoCode.isEmpty()){

			Promo actualPromo = promo.retrievePromotion(partnerCode, promoCode);
			
			//validando si vienen campos nulos
			if(actualPromo == null || actualPromo.getPartnerCode().isEmpty()) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			
			String type = env.getProperty("config.prom-types.redemption");
			if(actualPromo.getPromoType().toString().equals(type)){
				formPojo = getFields(env.getProperty("config.form-names.info-prom-red"), header);
				status = processForm(formPojo,partnerCode,actualPromo,type, header.getUserType());
			}else{
				status.setCode(ResponseCode.INPUT_MISSING);
				status.setResult(ResponseMsg.INPUT_MISSING);	
				log.error("Retrieve Info Redemption Promotion Error. Promotion is not Redemption. Message: Promotion is not Redemption");
			}
			
		}else {
			log.error("Retrieve Info Redemption Promotion Form: header is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);	
		}
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Info Redemption Promotion Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveAddMemberForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();

		if(header != null) {
			formPojo = getFields(env.getProperty("config.form-names.add-member"), header);
			status = processForm(formPojo);
		}
		else {
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve Add Member Error. Message: header is mandatory");
		}
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveMemberForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Member Form");
		}
		
		
		if(header != null){
			 //se llama a servicio de usuarios
			formPojo = getFields(env.getProperty("config.form-names.find-member"), header);
			status = processForm(formPojo, header.getPartnerCode());
		}
		else{
			
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve Member Form Error. Message:" + status.getResult());
		}
		if("true".equals(logFlag)){
			log.info("End Retrieve Member Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrievePosMemberTable(HeaderRequest header, MemberDetail input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive mun member table");
		
		Envelope<Status, List<MemberDetail>> response = member.retrieveMember(input);	
		try{
			if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {
				Form formPojo = getFields(env.getProperty("config.form-names.pos-member-table"), header);
				Status status = processForm(formPojo, response.getBody());
				
				return new Message<>(status, formPojo);
			} else {
				log.error("integrator retrive mun member table " + response.getHeader().getResult() + " " + response.getHeader().getCode() );			
			}
			
			if("true".equals(logFlag))
				log.info("End integrator retrive mun member table");

		}
		catch(Exception ex){
			log.error("Error integrator retrive mun member table: "+ ex.getMessage(), ex);
		}
		return new Message<>(response.getHeader(), null);					
	}

	@Override
	public Envelope<Status, Form> retrieveMcvMemberTable(HeaderRequest header, MemberDetail input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive acc member table");
		
		Envelope<Status, List<MemberDetail>> response = member.retrieveMember(input);	
		try{
			if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {	
				Form formPojo = getFields(env.getProperty("config.form-names.mcv-member-table"), header);
				Status status = processForm(formPojo, response.getBody());
				
				return new Message<>(status, formPojo);
			} else {
				log.error("integrator retrive acc member table " + response.getHeader().getResult() + " " + response.getHeader().getCode() );			
			}
			
			if("true".equals(logFlag))
				log.info("End integrator retrive acc member table");
		}
		catch(Exception ex){
			log.error("Error integrator retrive acc member table: "+ ex.getMessage(), ex);
		}
		return new Message<>(response.getHeader(), null);	
	}

	@Override
	public Envelope<Status, Form> retrieveMemberTable(HeaderRequest header, MemberDetail input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive member table");
		
		Envelope<Status, List<MemberDetail>> response = member.retrieveMember(input);	
		try{
			if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {

				Form formPojo = getFields(env.getProperty("config.form-names.member-table"), header);
				Status status = processForm(formPojo, response.getBody());
				
				return new Message<>(status, formPojo);
			} else {
				log.error("integrator retrive member table " + response.getHeader().getResult() + " " + response.getHeader().getCode() );			
			}
			
			if("true".equals(logFlag))
				log.info("End integrator retrive member table");

		}
		catch(Exception ex){
			log.error("Error integrator retrive member table: "+ ex.getMessage(), ex);
		}
		return new Message<>(response.getHeader(), null);
	}

	@Override
	public Envelope<Status, Form> retrieveAccMcvForm(HeaderRequest header, String memberNum) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive Acc Miles conversion form");
		
		Form formPojo = null;
		Status status = new Status();
		
		if(header != null) {
			
			MemberDetail memberDet =  member.retrieveMemberDet(memberNum);
			
			//validando si vienen campos nulos
			if(memberDet == null || memberDet.getMemberNum().isEmpty()) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}

			formPojo = getFields(env.getProperty("config.form-names.acc-mcv"), header);
			status = processForm(formPojo, header.getPartnerCode(), 
					memberDet,  header.getUserType(), header.getUser());
		} else {
			log.error("integrator retrive Acc Miles conversion form. Message: header is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrive Acc Miles conversion form");
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveAccMcvSearchForm(HeaderRequest header) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive Acc search form");
		
		Form formPojo = getFields(env.getProperty("config.form-names.acc-mcv-search"), header);
		Status status= processForm(formPojo);
		
		if("true".equals(logFlag))
			log.info("End integrator retrive Acc search form");
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrievePointTypesValues(HeaderRequest header, String partnerCode) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive point types post values");
		
		Form form1 = new Form();
		
		List<Section> sections = new ArrayList<>();
		Section sec = new Section();
		
		List<Field<Value>> fields = new ArrayList<>();
		Field<Value> f =  new Field<>();
		f.setId("ddlTipoTra");
		fields.add(f);
		sec.setFields(fields);
		sections.add(sec);
		form1.setSections(sections);

		Status status = processForm(form1, partnerCode,null, header.getUserType());
		
		if("true".equals(logFlag))
			log.info("End integrator retrive point types post values");
		
		return new Message<>(status, form1);
	}

	@Override
	public Envelope<Status, Form> retrieveAccPosWebForm(HeaderRequest header, String memberNum) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive acc pos web form");
		
		Form formPojo = null;
		Status status = new Status();
		
		if(header != null) {
			MemberDetail memberDet =  member.retrieveMemberDet(memberNum);
			
			//validando si vienen campos nulos
			if(memberDet == null || memberDet.getMemberNum().isEmpty()) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			formPojo = getFields(env.getProperty("config.form-names.acc-pos-web"), header);
			
			status = processForm(formPojo, header.getPartnerCode(), 
					memberDet, header.getUserType(), header.getUser(), false);
		} else {
			log.error("integrator retrive acc pos web form. Message: header is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrive acc pos web form");
		
		return new Message<>(status, formPojo);		
	}

	@Override
	public Envelope<Status, Form> retrieveAccRetSearchForm(HeaderRequest header) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive retail search form");
		
		Form formPojo = null;
		Status status = new Status();
		
		if(header != null) {
			
			formPojo = getFields(env.getProperty("config.form-names.acc-pos-search"), header);
			status = processForm(formPojo, header.getPartnerCode());
		} else {
			log.error("integrator retrive retail search form. Message: partnerCode is mandatory ");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrive retail search form");
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveStoresValuesPos(HeaderRequest header, String partnerCode) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive store values");
		
		Form form1 = new Form();
		Status status;
		
		List<Section> sections = new ArrayList<>();
		Section sec = new Section();
		
		List<Field<Value>> fields = new ArrayList<>();
		Field<Value> f =  new Field<>();
		f.setId("ddlSuc");
		fields.add(f);
		sec.setFields(fields);
		sections.add(sec);
		form1.setSections(sections);

		status = processForm(form1, partnerCode, null, "", null, true);
		
		if("true".equals(logFlag))
			log.info("End integrator retrive store values");
		
		return new Message<>(status, form1);
	}

	@Override
	public Envelope<Status, Form> retrieveRevTransForm(HeaderRequest header) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive RevTrans form");
		
		Form formPojo = null;
		Status status = new Status();
		if(header != null){
			
			formPojo = getFields(env.getProperty("config.form-names.rev-acc-form"),header);
			status = processForm(formPojo,header.getPartnerCode(),
					header.getUserType(),header.getUser());
		}else {
			log.error("integrator retrive RevTrans form. Message: partnerCode is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrive RevTrans form");
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveRevTransInfo(HeaderRequest header, String partnerCode, 
			String autNumber, String tranType) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive RevTrans info");
		
		Form formPojo = null;
		Status status = new Status();

		Envelope<Status,List<Transaction>> response = tran.retrieveTransactions(partnerCode, autNumber, tranType);
		
		if(response == null || response.getHeader() == null) {
			status.setCode(ResponseCode.NULL_DATA);
			status.setResult(ResponseMsg.NULL_DATA);
			return new Message<>(status, new Form());
		}
		
		if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())){
			List<Transaction> list = response.getBody();
			formPojo = getFields(env.getProperty("config.form-names.rev-acc-info"),header);
			status = processForm(formPojo,partnerCode,autNumber, new Transaction(), list);
		}else {
			log.error("integrator retrive RevTrans info " );
			status.setCode(response.getHeader().getCode());
			status.setResult(response.getHeader().getResult());
		}
		
		
		if("true".equals(logFlag))
			log.info("End integrator retrive RevTrans info");
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrievePrePurchaseForm(HeaderRequest header) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive pre purchase form");
		
		Form formPojo = null;
		Status status = new Status();
		if(header != null){
			formPojo = getFields(env.getProperty("config.form-names.pre-purchase-ppal"), header);
			status = processForm(formPojo, header.getPartnerCode(), 
					new PrePurchase(), header.getUserType(), header.getUser(),
					false);
		} else {
			log.error("integrator retrive pre purchase form " + ResponseCode.INPUT_MISSING);
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		
		if("true".equals(logFlag))
			log.info("End integrator retrive pre purchase form");
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveHistPreForm(HeaderRequest header) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive history pre purchase form");
		
		Form formPojo = null;
		Status status = new Status();
		if(header != null){
			formPojo = getFields(env.getProperty("config.form-names.hist-pre-purchase"),header);
			status = processForm(formPojo,header.getPartnerCode(),
					header.getUserType(),header.getUser(), false);
		}else{
			log.error("integrator retrive history pre purchase form. Message: partnerCode is mandatory" );
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrive history pre purchase form");
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrievePrePurchaseInfo(HeaderRequest header, 
			String partnerCode, String prepurCode, String pointType) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive pre purchase info");
		
		Form formPojo = null;
		Status status = new Status();
		if(header != null){
			
			PrePurchase prepur = prePur.retrievePrepurchase(partnerCode, prepurCode, pointType);
			
			//validando si vienen campos nulos
			if(prepur == null || prepur.getPartner().isEmpty()) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			formPojo = getFields(env.getProperty("config.form-names.pre-purchase-mod"), header);
			status = processForm(formPojo, partnerCode, prepur, header.getUserType(), header.getUser());
			
		} else {
			log.error("integrator retrive pre purchase info " + ResponseCode.NOT_FOUND);
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
			
		
		if("true".equals(logFlag))
			log.info("End integrator retrive pre purchase info");
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveHistPreSearch(HeaderRequest header, HistPrePurchase input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive history pre purchase");	
		Status status = new Status();
		Form formPojo ;
		
		Envelope<Status, List<PrePurchase>> response = prePur.histPrePurchase(input);
		
		//validando si vienen campos nulos
		if(response == null) {
			status.setCode(ResponseCode.NULL_DATA);
			status.setResult(ResponseMsg.NULL_DATA);
			return new Message<>(status, new Form());
		}
		
		if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {

			formPojo = getFields(env.getProperty("config.form-names.pre-purchase-table"), header);
			status = processForm(formPojo, response.getBody());
			
			return new Message<>(status, formPojo);
		}else if(ResponseCode.NOT_FOUND.equals(response.getHeader().getCode())){
			log.error("integrator retrive history pre purchase " + ResponseCode.NOT_FOUND);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);		
		} 
		
		if("true".equals(logFlag))
			log.info("End integrator retrive history pre purchase");
		
		return new Message<>(response.getHeader(), null);
	}
	@Override
	public Envelope<Status, Form> retrievePrepurchasesAdd(String partnerCode) {
		Form form1 = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve PrePurchase add List");
		}
		
		if(partnerCode != null && !partnerCode.isEmpty()){
			
			
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f =  new Field<>();
			f.setId("ddlPreCompras");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form1.setSections(sections);
			
			status = processForm(form1, partnerCode, null, "", null, true);
			
			log.info("Success Retrieve PrePurchase add List");
		}else{
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
			log.error("Retrieve PrePurchase List add Error: Input Missing");
			
		}
		if("true".equals(logFlag)){
			log.info("End Retrieve PrePurchase add List");
		}
		return new Message<>(status, form1);
	}

	@Override
	public Envelope<Status, Form> retrievePrepurchases(String partnerCode) {
		Form form1 = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve PrePurchase List");
		}
		
		if(partnerCode != null && !partnerCode.isEmpty()){
			
			
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f =  new Field<>();
			f.setId("ddlPreCompraHist");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			form1.setSections(sections);
			
			status = processForm(form1, partnerCode, "", "", true);
			
			log.info("Success Retrieve PrePurchase List");
		}else{
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
			log.error("Retrieve PrePurchase List Error: Input Missing");
			
		}
		if("true".equals(logFlag)){
			log.info("End Retrieve PrePurchase List");
		}
		return new Message<>(status, form1);
	}

	@Override
	public Envelope<Status, Form> retrieveGiftCardForm(HeaderRequest header) {

		if("true".equals(logFlag))
			log.info("Start integrator retrive gift card Form");	
		
		Form formPojo = null;
		Status status = new Status();
		if(header != null){
			
			formPojo = getFields(env.getProperty("config.form-names.gift-cards-act"),header);
			status = processForm(formPojo,header.getPartnerCode(),
					null,header.getUserType(),header.getUser());
		}else {
			log.error("integrator retrive gift card Form. Message: partnerCode is mandatory ");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrive gift card report ");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveGiftCardFormReport(HeaderRequest header) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive gift card report Form");	
		
		Form formPojo = null;
		Status status = new Status();
		if(header != null ) {
			
			formPojo = getFields(env.getProperty("config.form-names.gift-cards-report"), header);
			status = processForm(formPojo, header.getPartnerCode(), 
					null,"",header.getUserType(),header.getUser());
		} else {
			log.error("integrator retrive gift card report Form. Message: partnerCode is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrive gift card report form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveGifCardReport(HeaderRequest header,
			ReportGiftCard input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive gift card report");		
			
		Status s = new Status();
		Form formPojo = null;
		Envelope<Status, List<GiftCard>> response = report.retrieveGifCardReport(input);		
		//validando si vienen campos nulos
		if(response == null || response.getBody() == null || response.getHeader() == null) {
			s.setCode(ResponseCode.NULL_DATA);
			s.setResult(ResponseMsg.NULL_DATA);
		}
		else if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {

			formPojo = getFields(env.getProperty("config.form-names.gift-cards-table"), header);
			s = processForm(formPojo, response.getBody());
			
		}  else {
			s.setCode(response.getHeader().getCode());
			s.setResult(response.getHeader().getResult());
			log.info("integrator retrive gift card report " + response.getHeader().getCode() +" "+ response.getHeader().getResult());		
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrive gift card report");	
		
		return new Message<>(s, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveRedemptionReportForm(HeaderRequest header) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve Redemption Report Form");
		}
		if(header != null){
			
			formPojo = getFields(env.getProperty("config.form-names.red-report"), header);
			List<String> partners = new ArrayList<>();
			partners.add(header.getPartnerCode());
			status = processForm(formPojo, header.getPartnerCode(), true,partners, 
					header.getUserType(),header.getUser());
		}else{
			log.error("integrator Retrieve Redemption Report Form Error. Message: partnerCode is mandatory" );
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			
		}
		
		if("true".equals(logFlag))
			log.info("End integrator Retrieve Redemption Report Form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveRedemptionReport(HeaderRequest header,
			ReportRedemption input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive redemptions report");		
		

		Form formPojo = null;
		//llamar los partners cuando viene all
		Status s = new Status();
		if(partnersAll(header, input.getPartner(), s)){
			Envelope<Status, List<Redemption>> response = report.retrieveRedemptionReport(input);	

			//validando si vienen campos nulos
			if(response == null || response.getBody() == null || response.getHeader() == null) {
				s.setCode(ResponseCode.NULL_DATA);
				s.setResult(ResponseMsg.NULL_DATA);
			}
			else if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {

				formPojo = getFields(env.getProperty("config.form-names.red-table"), header);
				s = processForm(formPojo, response.getBody());
				
			}  else {
				s.setCode(response.getHeader().getCode());
				s.setResult(response.getHeader().getResult());
				log.info("integrator retrieve redemption report " + response.getHeader().getCode() +" "+ response.getHeader().getResult());		
			}
		}
		
		
		if("true".equals(logFlag))
			log.info("End integrator retrieve redemption report");	
		
		return new Message<>(s, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveCmbPointTypesxPartner(HeaderRequest header, List<String> partners) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve PoinType x Partner");
		}
		
		if(header != null){
			
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();
			
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f =  new Field<>();
			f.setId("slt_Tipo_Transacciones");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			formPojo.setSections(sections);

			status = processForm(formPojo, header.getPartnerCode(), false,partners, header.getUserType());
			
			log.info("Success Retrieve PoinType x Partner");
		}else{
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
			log.error("Retrieve Retrieve PoinType x Partner Error: Input Missing");
			
		}
		if("true".equals(logFlag)){
			log.info("End Retrieve PoinType x Partner");
		}
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveMCVReportForm(HeaderRequest header) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve MCV Report Form");
		}
		if(header != null){
			
			formPojo = getFields(env.getProperty("config.form-names.mcv-report"), header);
			List<String> partners = new ArrayList<>();
			partners.add(header.getPartnerCode());
			status = processForm(formPojo, header.getPartnerCode(), true,partners,
					header.getUserType(),header.getUser());
		}else{
			log.error("integrator Retrieve MCV Report Form Error. Message: partnerCode is mandatory" );
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			
		}
		
		if("true".equals(logFlag))
			log.info("End integrator Retrieve MCV Report Form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrievePpalTransactionReport(HeaderRequest header) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve Principal transaction Report Form");
		}
		if(header != null){

			if(header.getUserType().equals(userLm) ){
				formPojo = getFields(env.getProperty("config.form-names.ppal-tra-report"), header);
			}else if(header.getUserType().equals(userGr) || header.getUserType().equals(userPa) ){
				formPojo = getFields(env.getProperty("config.form-names.tra-cmr-report"), header);
			}
			
			List<String> partners = new ArrayList<>();
			partners.add(header.getPartnerCode());
			status = processForm(formPojo, header.getPartnerCode(), true, partners,
					header.getUserType(),header.getUser());
		}else{
			log.error("integrator Retrieve Principal transaction Report Form. Message: partnerCode is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			
		}
		
		if("true".equals(logFlag))
			log.info("End integrator Retrieve Principal transaction Report Form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveDetTraReport(HeaderRequest header, String filter) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve Det transaction Report Form");
		}
		if(header != null){
			
			String formName ="";
			if(env.getProperty("config.filter-rep-tra.partner").equals(filter))
				formName = env.getProperty("config.form-names.tra-cmr-report");
			else if(env.getProperty("config.filter-rep-tra.country").equals(filter))
					formName = env.getProperty("config.form-names.tra-cou-report");
			formPojo = getFields(formName, header);
			List<String> partners = new ArrayList<>();			
			status = processForm(formPojo, header.getPartnerCode(), true,partners,
					header.getUserType(),header.getUser());
		}else{
			log.error("integrator Retrieve Det transaction Report Form. Message: partnerCode is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		if("true".equals(logFlag))
			log.info("End integrator Retrieve Det transaction Report Form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveCashierReport(HeaderRequest header,
			ReportCashier input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive cashier report");		
		
		Form formPojo = null;
		//llamar los partners cuando viene all
		Status s = new Status();
		if(partnersAll(header, input.getPartners(), s)){
			Envelope<Status, List<Cashier>> response = report.retrieveCashierReport(input);

			//validando si vienen campos nulos
			if(response == null || response.getBody() == null || response.getHeader() == null) {
				s.setCode(ResponseCode.NULL_DATA);
				s.setResult(ResponseMsg.NULL_DATA);
			}
			else if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {

				formPojo = getFields(env.getProperty("config.form-names.cashier-table"), header);
				s = processForm(formPojo, response.getBody());
				
			}  else {
				s.setCode(response.getHeader().getCode());
				s.setResult(response.getHeader().getResult());
				log.info("integrator retrieve cashier report " + response.getHeader().getCode() +" "+ response.getHeader().getResult());		
			}
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrieve cashier report");	
		
		return new Message<>(s, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveCashierReportForm(HeaderRequest header) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve Cashier Report Form");
		}
		if(header != null){
			
			formPojo = getFields(env.getProperty("config.form-names.cashier-report"), header);
			List<String> partners = new ArrayList<>();
			partners.add(header.getPartnerCode());
			status = processForm(formPojo, header.getPartnerCode(), true, partners,
					header.getUserType(),header.getUser());
		}else{
			log.error("integrator Retrieve Cashier Report Form Error. Message: partnerCode is mandatory" );
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			
		}
		
		if("true".equals(logFlag))
			log.info("End integrator Retrieve Cashier Report Form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveMCVReport(HeaderRequest header,
			ReportMilesConv input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive Miles Conversion report");
		
		Form formPojo = null;
		//llamar los partners cuando viene all
		Status s = new Status();
		if(partnersAll(header, input.getPartnerCode(), s)){
			Envelope<Status, List<MilesConv>> response = report.retreiveMilesConvReport(input);

			//validando si vienen campos nulos
			if(response == null || response.getBody() == null || response.getHeader() == null) {
				s.setCode(ResponseCode.NULL_DATA);
				s.setResult(ResponseMsg.NULL_DATA);
			}
			else if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {

				formPojo = getFields(env.getProperty("config.form-names.mcv-table"), header);
				s = processForm(formPojo, response.getBody());
				
			}  else {
				s.setCode(response.getHeader().getCode());
				s.setResult(response.getHeader().getResult());
				log.info("integrator retrieve gift card  report " + response.getHeader().getCode() +" "+ response.getHeader().getResult());		
			}
		}
		
		
		if("true".equals(logFlag))
			log.info("End integrator retrive Miles Conversion report");	
		
		return new Message<>(s, formPojo);	
	}

	@Override
	public Envelope<Status, Form> retreiveCmbStoresxPartner(HeaderRequest header, List<String> partners) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve stores x Partner");
		}
		
		if(header != null){			
			
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();	
	
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f =  new Field<>();
			f.setId("slt_sucursales");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			formPojo.setSections(sections);

			status = processForm(formPojo, header.getPartnerCode(), false,
					partners, header.getUserType());

			if("true".equals(logFlag))
				log.info("Success Retrieve stores x Partner");
		}else{
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
			log.error("Retrieve stores x Partner Error: Input Missing");
			
		}
		if("true".equals(logFlag)){
			log.info("End Retrieve PoinType x Partner");
		}
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveTransactionReport(HeaderRequest header,
			ReportTransaction input) {
		if("true".equals(logFlag))
			log.info("Start integrator retrive transaction report");		
		
		Form formPojo = null;
		//llamar los partners cuando viene all
		Status s = new Status();
		if(partnersAll(header, input.getPartners(), s)){
			Envelope<Status, List<TransactionReport>> response = report.retrieveTransactionReport(input);

			//validando si vienen campos nulos
			if(response == null || response.getBody() == null || response.getHeader() == null) {
				s.setCode(ResponseCode.NULL_DATA);
				s.setResult(ResponseMsg.NULL_DATA);
			}
			else if(ResponseCode.SUCCESS.equals(response.getHeader().getCode())) {

				formPojo = getFields(env.getProperty("config.form-names.tra-table"), header);
				s = processForm(formPojo, response.getBody());
				
			}  else {
				s.setCode(response.getHeader().getCode());
				s.setResult(response.getHeader().getResult());
				log.info("integrator retrieve transaction report " + response.getHeader().getCode() +" "+ response.getHeader().getResult());		
			}
		}
		
		if("true".equals(logFlag))
			log.info("End integrator retrieve transaction report");	
		
		return new Message<>(s, formPojo);
	}

	public boolean  partnersAll(HeaderRequest header, List<String> partners, Status s){
		//llamar los partners cuando viene all
		if(partners != null && partners.get(0).equals(env.getProperty("config.all.partner")) &&
			header.getUserType().equals(userGr)){
			List<Partner> parList = partnerData.retrievePartners(header.getUserType(), header.getPartnerCode(), header.getUser());
			if(parList != null){
				partners.remove(0);
				parList.forEach(x->partners.add(x.getCode()));
				return true;
			}
			else{
				s.setCode(ResponseCode.NULL_DATA);
				s.setResult(ResponseMsg.NULL_DATA);
				return false;
			}
				
		}
		return true;
	}
	@Override
	public Envelope<Status, Form> retrieveInfoUserPpalForm(HeaderRequest header) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve Info User ppal Form");
		}
		if(header != null){
			formPojo = getFields(env.getProperty("config.form-names.info-user-ppal-form"), header);		
			status = processForm(formPojo, header.getPartnerCode(), 
					header.getUserType(),notApply,
					false,null, header.getUser());
		}else{
			log.error("integrator  Retrieve Info User ppal Form. Message: partnerCode is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		if("true".equals(logFlag))
			log.info("End integrator Retrieve Info User ppal Form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveCreationUserForm(HeaderRequest header) {
		Form formPojo = new Form();
		Status status = new Status();
		List<Function> lstFunction  = new ArrayList<>();
		if("true".equals(logFlag)){
			log.info("Start Retrieve Creation User Form");
		}
		if(header != null){
			formPojo = getFields(env.getProperty("config.form-names.creation-user"), header	);	
			if(!header.getUserType().equals("LM")){
				lstFunction = userData.retrieveFunctionsByCreateForm(header.getUserType(), header.getUser(), header.getUserType(), header.getLang());
				
			}
			
			status = processForm(formPojo, header.getPartnerCode(), 
					header.getUserType(), "",header.getLang(),
					null, header.getUser(),lstFunction);
		}else{
			log.error("integrator  Retrieve Creation User Form. Message: partnerCode is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		if("true".equals(logFlag))
			log.info("End integrator Retrieve Creation User Form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveUserForm(HeaderRequest header, String partnerCode) {
		Form formPojo = new Form();
		Status status ;
		if("true".equals(logFlag)){
			log.info("Start Integrator Retrieve Info User ajax Form");
		}
		
		List<Section> sections = new ArrayList<>();
		Section sec = new Section();		
		List<Field<Value>> fields = new ArrayList<>();
		Field<Value> f =  new Field<>();
		f.setStatus("visible");	
		fields.add(f);
		sec.setFields(fields);
		sections.add(sec);
		formPojo.setSections(sections);
		
		if(notApply.equals(partnerCode)) //cargar comercios
			f.setId("slt_commmerce");
		else //cargar usuario de grupo
			f.setId("slt_usuario");

		status = processForm(formPojo,header.getPartnerCode() ,header.getUserType(),partnerCode,true);
			
		if("true".equals(logFlag))
			log.info("End Integrator Retrieve Info User ajax Form");	
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retrievePartnerByGroup(HeaderRequest header, String groupCode) {
		Form formPojo = null;
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve PartnerByGroup");
		}
		if(groupCode != null && !groupCode.isEmpty()){
			if(!userLm.equals(header.getUserType())){

				status.setCode(ResponseCode.NOT_ALLOWED);
				status.setResult(ResponseMsg.NOT_ALLOWED);
			}
			else{
				formPojo = getFields(env.getProperty("config.form-names.partner-list"), header);		
				status = processForm(formPojo, header.getPartnerCode(), header.getUserType(), groupCode, header.getUserType());
				if(groupCode.equals(notApply)){
					formPojo.getSections().get(0).setDescription("");
				}
				if("true".equals(logFlag))
					log.info("Success Retrieve stores x Partner");
			}
		}else{
			log.error("integrator  Retrieve PartnerByGroup. Message: groupCode is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		
		if("true".equals(logFlag))
			log.info("End integrator Retrieve PartnerByGroup");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveInfoUserForm(HeaderRequest header, String userCode) {
		Form formPojo = null;
		Status status = new Status();
		List<Function> lstFunction = new ArrayList<>();
		boolean isApprover = false;
		
		
		if("true".equals(logFlag))
			log.info("Start integrator Retrieve Info User Form");
		
		if(userCode != null && !userCode.isEmpty()){
			String lng = header.getLang();
			User user = userData.retrieveInfoUser(userCode,lng);
			
			//validando si vienen campos nulos
			if(user == null) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			List<Flow> flowList = null;
			List<UserPartner> partnerWkf = null;
			ApproveUser app = null;
			String idForm="";
			lstFunction = userData.retrieveFunctionsByUser(header.getUser(), header.getUserType(), userCode, user.getUserType(), lng);
			if(user.getUserType().equals(env.getProperty("config.user-types.partner")) ){
				idForm =env.getProperty("config.form-names.info-user-partner");
				
			}else if(user.getUserType().equals(env.getProperty("config.user-types.group")) ){
				idForm =env.getProperty("config.form-names.info-user-group");
			}else if(user.getUserType().equals(userLm)){
				idForm =env.getProperty("config.form-names.info-user-partner");
				
				if(lstFunction != null && !lstFunction.isEmpty()){
					isApprover =lstFunction.stream()
							.filter(x->x.getFuncCode().equals(env.getProperty("config.approver-code")) && x.isAccess() )
							.findFirst().isPresent();
				}
				if(isApprover){
					app = wData.retrieveUserApprove(user.getUserName());
					
					//validando si vienen campos nulos
					if(app == null || app.getAreaCode().isEmpty()) {
						status.setCode(ResponseCode.NULL_DATA);
						status.setResult(ResponseMsg.NULL_DATA);
						return new Message<>(status, new Form());
					}
					
					//usuario lifemiles, verificar si el 
					if(app.getSegType()!=null){

							if( app.getSegType().equals(env.getProperty("config.flow-commerce.flow"))){
								flowList = wData.retreiveFlowByUser(app.getAreaCode(), user.getUserName(), lng);
								
								//validando si vienen campos nulos
								if(flowList == null) {
									status.setCode(ResponseCode.NULL_DATA);
									status.setResult(ResponseMsg.NULL_DATA);
									return new Message<>(status, new Form());
								}
								
								idForm = env.getProperty("config.form-names.info-user-approve-flow");
							}
							else{
								partnerWkf = wData.retrieveUserPartners(user.getUserName(), app.getAreaCode(), lng);
								idForm = env.getProperty("config.form-names.info-user-approve-partner");
								
								//validando si vienen campos nulos
								if(partnerWkf == null) {
									status.setCode(ResponseCode.NULL_DATA);
									status.setResult(ResponseMsg.NULL_DATA);
									return new Message<>(status, new Form());
								}
							}

					}
				}
			}
			
			formPojo = getFields(idForm, header);
		
			
			status = processForm(formPojo, 
					user.getCodPartner() != null ? user.getCodPartner() : "",
							user.getUserType(),
					user.getCodGroup() != null ? user.getCodGroup() : "",
							lng,user,lstFunction, isApprover,"","", app, 
							flowList, partnerWkf);

			status.setCode(ResponseCode.SUCCESS);
			status.setResult(ResponseMsg.SUCCESS);
			
		}else{
			log.error("Integrator Retrieve Info User Form Message: userCode is mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
			
			
		if("true".equals(logFlag))
			log.info("Start integrator Retrieve Info User Form");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retreiveAllFunctions(HeaderRequest header, String groupCode, String partnerCode) {
		Form formPojo = new Form();
		Status status = new Status();
		String userType;
		if("true".equals(logFlag)){
			log.info("Start Retrieve all user functions");
		}
		if (groupCode != null && partnerCode != null) {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();	
	
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f =  new Field<>();
			f.setId("slt_rol_create");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			formPojo.setSections(sections);
			
			if(!partnerCode.equals("null") && !partnerCode.equals("LM") ){
				userType = "PA"; 
			}else if(partnerCode.equals("LM")){
				userType = "LM";
			}else userType = "GR";
			
			
			List<Function> lstFunction = userData.retrieveFunctionsByCreateForm(header.getUserType(),header.getUser(),userType , "ES");
			status = processForm(formPojo,null,null,null,null,null,null,lstFunction);
		} else {
			log.error("integrator  Retrieve all user functions. Message: groupCode and partnercode are mandatory");
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		if("true".equals(logFlag))
			log.info("End Retrieve all user functions");	
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retreiveAllAreaApprovers(HeaderRequest header) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve all area approvers");
		}
		try {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();	
	
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f =  new Field<>();
			f.setId("ddlArea");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			formPojo.setSections(sections);

			status = processForm(formPojo, header.getLang(), false);	
			
		} catch (Exception e) {
			log.error("integrator  Retrieve all user functions. Message: groupCode and partnercode are mandatory", e);
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		if("true".equals(logFlag))
			log.info("End integrator Retrieve PartnerByGroup");	
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retreiveFunctionsPartnes(HeaderRequest header, String approverArea, String flowP,
			String partnerCode) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve flow-commerce process");
		}
		try {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();	
	
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f =  new Field<>();
			f.setId("slt_Aprb");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			formPojo.setSections(sections);

			status = processForm(formPojo, approverArea, flowP, header.getLang(), 
					header.getUserType(), partnerCode);	
			
		} catch (Exception e) {
			log.error("integrator flow-commerce process. Message: approver area and flow type are mandatory" ,e);
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		if("true".equals(logFlag))
			log.info("End Retrieve flow-commerce process");	
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retreiveSubstitutesList(String areaCode) {
		Form formPojo = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve subsitutes process");
		}
		try {
			List<Section> sections = new ArrayList<>();
			Section sec = new Section();	
	
			List<Field<Value>> fields = new ArrayList<>();
			Field<Value> f =  new Field<>();
			f.setId("ddlSuplente");
			fields.add(f);
			sec.setFields(fields);
			sections.add(sec);
			formPojo.setSections(sections);

			status = processForm(formPojo, areaCode);	
		} catch (Exception e) {
			log.error("integrator Retrieve subsitutes. Message: approver area and flow type are mandatory", e);
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		if("true".equals(logFlag))
			log.info("End Retrieve subsitutes process");	
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveNewPasswordForm(HeaderRequest header) {
		Form formPass = new Form();
		Status status = new Status();
		if("true".equals(logFlag)){
			log.info("Start Retrieve New Password Form");
		}
		try {
			
			formPass = getFields(env.getProperty("config.form-names.new-password"), header);	
			status = processForm(formPass, header.getUser());
			if("true".equals(logFlag))
				log.info("Success Retrieve new password form");
				
					
			
		} catch (Exception e) {			
			log.error("integrator Retrieve new password form. Message: Language is mandatory",e);
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
		}
		return new Message<>(status,formPass);
	}

	@Override
	public Envelope<Status, Form> retrieveAreaApprover(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try {
			if("true".equals(logFlag)){
				log.info("Start Retrieve section area approver for form user");
			}
			formPojo = getFields(env.getProperty("config.form-names.approver-area"), header);
			status = processForm(formPojo, header.getLang());	
			
		} catch (Exception e) {
			log.error("integrator Retrieve section area approver for form user cmb not found", e);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}			
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveResetPasswordForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		
		if("true".equals(logFlag)){
			log.info("Start Retrieve Password Reset Form");
		}

		if(header != null){
			formPojo = getFields(env.getProperty("config.form-names.password-reset"), header);
			status = processForm(formPojo, header.getPartnerCode(), header.getUserType(), "", false,"", header.getUser()); 
		}
		else{
			status.setCode(ResponseCode.INPUT_MISSING);
			status.setResult(ResponseMsg.INPUT_MISSING);
			log.error("Retrieve Password Reset Form Error. Message:" + status.getResult());
		}
		
		if("true".equals(logFlag)){
			log.info("End Retrieve Password Reset Form");
		}
		
		return new Message<>(status, formPojo);
	}

	@Override
	public Envelope<Status, Form> retreiveSubFForm(HeaderRequest header, 
			String user,  String areaCode, String flowP) {
		Form formPojo = null;
		Status status = new Status();
		try {
			if("true".equals(logFlag)){
				log.info("Start Retrieve PartnerByGroup");
			}
			if (flowP.equals(env.getProperty("config.flow-commerce.flow")))				
				formPojo = getFields(env.getProperty("config.form-names.sub-flow"), header);
			else
				formPojo = getFields(env.getProperty("config.form-names.area-flow"), header);
				
			status = processForm(formPojo, areaCode, flowP, header.getLang(), 
					header.getUserType(), header.getPartnerCode(), header.getUser(), user);	
		} catch (Exception e) {
			log.error("integrator Retrieve section  for form user cmb not found", e);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveAreaInfoApprover(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try {
			if("true".equals(logFlag)){
				log.info("Start Retrieve section area approver for form user info");
			}
			formPojo = getFields(env.getProperty("config.form-names.approver-area-info"), header);
			
			status = processForm(formPojo,"","","",header.getLang(),null,null,true,"","",null);
			
		} catch (Exception e) {
			log.error("integrator Retrieve section area approver for form user info  not found", e);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}			
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retriveAreaApproverDetail(HeaderRequest header, String functionCode, String flow,
			String userCode) {
		Form formPojo = null;
		Status status = new Status();
		String idForm="";
		List<UserPartner> partnerWkf = new ArrayList<>();
		List<Flow> flowList = new ArrayList<>();
		try {
			if("true".equals(logFlag)){
				log.info("Start Retrieve section area approver for form user info");
			}
			String lng = header.getLang();
			User user = userData.retrieveInfoUser(userCode, lng);
			
			//validando si vienen campos nulos
			if(user == null ) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			if(flow.equals(env.getProperty("config.flow-commerce.flow"))){
				idForm = env.getProperty("config.form-names.approver-flow");
				flowList = wData.retreiveFlowByUser(functionCode, user.getUserName(), lng);
				
				//validando si vienen campos nulos
				if(flowList == null) {
					status.setCode(ResponseCode.NULL_DATA);
					status.setResult(ResponseMsg.NULL_DATA);
					return new Message<>(status, new Form());
				}
			}else if(flow.equals(env.getProperty("config.flow-commerce.commerce"))){
				idForm = env.getProperty("config.form-names.approver-partner");
				partnerWkf = wData.retrieveUserPartners(user.getUserName(), functionCode, lng);
				
				//validando si vienen campos nulos
				if(partnerWkf == null) {
					status.setCode(ResponseCode.NULL_DATA);
					status.setResult(ResponseMsg.NULL_DATA);
					return new Message<>(status, new Form());
				}
			}
			formPojo = getFields(idForm, header);
			
			status = processForm(formPojo,"","","",lng,user,null,true,functionCode,flow,null,flowList,partnerWkf);
			
			
		} catch (Exception e) {
			log.error("integrator Retrieve section area approver for form user info  not found", e);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}			
		return new Message<>(status,formPojo);
	}*/

	@Override
	public Envelope<Status, Form> retrieveLoginForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag)){
				log.info("Start  Retrieve Login Form info");
			}
			formPojo = getFields(env.getProperty("config.form-names.login-form"), header);
			status = processForm(formPojo);
		}catch(Exception ex){
			
			log.error("integrator Retrieve Login Form error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.RENDER_ERROR);
			status.setResult(ResponseMsg.RENDER_ERROR);
		}
		return new Message<>(status,formPojo);
	}
/*
	@Override
	public Envelope<Status, Form> retrieveWorkflowHistRequest(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		List<HistRequest> list = new ArrayList<>();
		try{
			if("true".equals(logFlag)){
				log.info("Start  Retrieve WorkFlowRequest Form info");
			}
			formPojo = getFields(env.getProperty("config.form-names.hist-request"), header);
			list = wData.retrieveHistRequest(header.getUserType(), header.getPartnerCode(),
					header.getUser(),header.getLang()); 
			
			//validando si vienen campos nulos
			if(list == null) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			status = processForm(formPojo,list );
		}catch(Exception ex){
			log.error("integrator Retrieve WorkFlowRequest  Form error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveApproveRequest(HeaderRequest header, String reqCode) {
		Form formPojo = null;
		Status status = new Status();
		InfoRequest infoRequest = new InfoRequest();		
		TableApprovers table = new TableApprovers();
		try{
			if("true".equals(logFlag)){
				log.info("Start Retrieve Request Approve Form info");
			}
			infoRequest = wData.retrieveValuesRequest(reqCode);
			
			//validando si vienen campos nulos
			if(infoRequest == null || infoRequest.getRequest()== null || 
					infoRequest.getLstValueR() == null || infoRequest.getLstValueR().isEmpty()) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			table = wData.retrieveApproversHistory(reqCode, header.getLang());
			
			//validando si vienen campos nulos
			if(table == null || table.getBody() == null) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			if(env.getProperty("config.flowTypes.info-commerce").equals(infoRequest.getRequest().getCodeFlow())){
				formPojo = getFields(env.getProperty("config.form-names.partner-request"), header);
			}else 
				if(env.getProperty("config.flowTypes.add-promotion").equals(infoRequest.getRequest().getCodeFlow()) ||
					env.getProperty("config.flowTypes.info-promocion").equals(infoRequest.getRequest().getCodeFlow()) ||
					env.getProperty("config.flowTypes.add-promocionlm").equals(infoRequest.getRequest().getCodeFlow()) ||
					env.getProperty("config.flowTypes.info-promocionlm").equals(infoRequest.getRequest().getCodeFlow())
					){
				formPojo = getFields(env.getProperty("config.form-names.promo-acc-request"), header);
			}else if(env.getProperty("config.flowTypes.add-promocionre").equals(infoRequest.getRequest().getCodeFlow()) || 
					env.getProperty("config.flowTypes.info-promoconre").equals(infoRequest.getRequest().getCodeFlow())
					){
				formPojo = getFields(env.getProperty("config.form-names.promo-red-request"), header);
			}
			status = processForm(formPojo, infoRequest, table, header.getUser(), header.getUserType());
				
		}catch(Exception ex){
			log.error("integrator Retrieve Request Approve Form error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);		
	}

	@Override
	public Envelope<Status, Form> retrieveWorkflowMyRequest(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		List<HistRequest> list = new ArrayList<>();
		try{
			if("true".equals(logFlag)){
				log.info("Start  Retrieve WorkFlowMyRequest Form info");
			}
			formPojo = getFields(env.getProperty("config.form-names.my-request"), header);
			list = wData.retrieveMyRequest(header.getUserType(), header.getPartnerCode(),
					header.getUser(),header.getLang()); 
					
			//validando si vienen campos nulos
			if(list == null) {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
			
			status = processForm(formPojo,list );
		}catch(Exception ex){
			log.error("integrator Retrieve WorkFlowMyRequest  Form error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveAddCashierForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag))
				log.info("Start  Retrieve Add Cashier Form ");
			formPojo = getFields(env.getProperty("config.form-names.add-cashier"), header);
			status = processForm(formPojo,header.getPartnerCode(),"","",header.getUser(),header.getUserType());
		}catch(Exception ex){
			log.error("integrator Retrieve Add Cashier  Form error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveCashierInfoForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag))
				log.info("Start  Retrieve Info Cashier Form ");
			formPojo = getFields(env.getProperty("config.form-names.info-cashier"), header);
			status = processForm(formPojo,header.getPartnerCode(),"","",header.getUser(),header.getUserType());
		}catch(Exception ex){
			log.error("integrator Retrieve Info Cashier  Form error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);		
	}
	
	@Override
	public Envelope<Status, Form> retrieveDetailsCashierInfoForm(HeaderRequest header, CashierSearchType input) {
		Form formPojo = null;
		Status status = new Status();
		Envelope<Status, Cashier> cashier;
		try{
			if("true".equals(logFlag))
				log.info("Start  Retrieve Info Cashier Form ");			
			cashier = cData.retrieveCashierInfo(input);			
			if(ResponseCode.SUCCESS.equals(cashier.getHeader().getCode())) {
				formPojo = getFields(env.getProperty("config.form-names.data-cashier"), header);			
				status = processForm(formPojo,header.getPartnerCode(),cashier.getBody(),"",header.getUser(),header.getUserType());
			} else {
				status.setCode(ResponseCode.NOT_FOUND);
				status.setResult(ResponseMsg.NOT_FOUND);
			}
			
		}catch(Exception ex){
			log.error("integrator Retrieve Info Cashier  Form error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);		
	}

	@Override
	public Envelope<Status, Form> retrieveAddGroupForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag))
				log.info("Start retrieveAddGroupForm ");
			
			formPojo = getFields(env.getProperty("config.form-names.add-group"), header);
			status = processForm(formPojo, header);
		}catch(Exception ex){
			log.error("integrator retrieveAddGroupForm error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);	
	}

	@Override
	public Envelope<Status, Form> retrieveInfoGroupForm(HeaderRequest header, String partnerCode) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag))
				log.info("Start retrieveInfoGroupForm ");
			
			List<Partner> infoGrp = partnerData.retrievePartners(userPa, partnerCode, notApply);
			List<Partner> subPar =  partnerData.retrievePartners(userGr, partnerCode, notApply);
			
			if(infoGrp != null && !infoGrp.isEmpty()){
				formPojo = getFields(env.getProperty("config.form-names.info-group"), header);
				status = processForm(formPojo, header, infoGrp.get(0), subPar);
			}
			else{
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				return new Message<>(status, new Form());
			}
		}catch(Exception ex){
			log.error("integrator retrieveInfoGroupForm error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);	
	}
	@Override
	public Envelope<Status, Form> retrieveDetGroupForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag))
				log.info("Start retrieveDetGroupForm ");
			
			formPojo = getFields(env.getProperty("config.form-names.det-group"), header);
			status = processForm(formPojo, header);
		}catch(Exception ex){
			log.error("integrator retrieveDetGroupForm error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);	
	}
	
	@Override
	public Envelope<Status, Form> retrieveSenderInfoForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag))
				log.info("Start retrieveSenderInfoForm ");
			
			formPojo = getFields(env.getProperty("config.form-names.sender-info"), header);
			status = processForm(formPojo, header);
		}catch(Exception ex){
			log.error("integrator retrieveSenderInfoForm error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);		
	}

	@Override
	public Envelope<Status, Form> retrieveDetailSenderForm(HeaderRequest header, String senderCode) {
		Form formPojo = null;
		Status status = new Status();
		
		try {
			if("true".equals(logFlag))
				log.info("Start retrieve detail sender info form ");			
			Envelope<Status, SenderInfo> senderInfo = senderData.retrieveSenderInfo(senderCode);
			if(ResponseCode.SUCCESS.equals(senderInfo.getHeader().getCode())) {
				formPojo = getFields(env.getProperty("config.form-names.sender-info-form"), header);
				status = processForm(formPojo, header, senderCode, senderInfo.getBody());
			} else {
				status.setCode(ResponseCode.NULL_DATA);
				status.setResult(ResponseMsg.NULL_DATA);
				log.info("Sender has not data configurated {}", senderCode);				
				return new Message<>(status, new Form());
			}
			
		} catch (Exception e) {
			log.error("integrator retrieve detail sender info form error: " +e.getMessage(),e);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		
		return new Message<>(status,formPojo);
	}

	@Override
	public Envelope<Status, Form> retrieveAddSenderForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag))
				log.info("Start retrieveAddSenderForm ");
			
			formPojo = getFields(env.getProperty("config.form-names.add-sender"), header);
			status = processForm(formPojo, header, null, null, null);
		}catch(Exception ex){
			log.error("integrator retrieveAddSenderForm error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.NOT_FOUND);
			status.setResult(ResponseMsg.NOT_FOUND);
		}
		return new Message<>(status,formPojo);
	}
*/

	@Override
	public Envelope<Status, Form> retrieveMenuForm(HeaderRequest header) {
		Form formPojo = null;
		Status status = new Status();
		try{
			if("true".equals(logFlag)){
				log.info("Start  Retrieve Menu Form info");
			}
			formPojo = getFields(env.getProperty("config.form-names.menu-form"), header);
			status = processForm(formPojo);
		}catch(Exception ex){
			
			log.error("integrator Retrieve Menu Form error: " +ex.getMessage(),ex);
			status.setCode(ResponseCode.RENDER_ERROR);
			status.setResult(ResponseMsg.RENDER_ERROR);
		}
		return new Message<>(status,formPojo);
	}
	

	
}
