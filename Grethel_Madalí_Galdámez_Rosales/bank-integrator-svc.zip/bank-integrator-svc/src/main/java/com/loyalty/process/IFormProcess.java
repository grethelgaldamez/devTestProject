package com.loyalty.process;

import java.util.List;

import com.loyalty.pojo.HeaderRequest;
import com.loyalty.pojo.envelope.Envelope;
import com.loyalty.pojo.envelope.Status;

public interface IFormProcess<O> {
	
	//form login
	public Envelope<Status,O> retrieveLoginForm(HeaderRequest header);
	
	//form menú
	public Envelope<Status, O> retrieveMenuForm(HeaderRequest header);

}
