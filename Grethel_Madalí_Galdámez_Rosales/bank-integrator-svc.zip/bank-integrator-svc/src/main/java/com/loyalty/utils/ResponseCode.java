package com.loyalty.utils;

public class ResponseCode {
	public static final String SUCCESS="000";
	public static final String INPUT_MISSING="100";
	public static final String NO_FORM="101";

	public static final String RENDER_ERROR="400";
	
	public static final String NO_SECTIONS="102";
	public static final String NO_FIELDS="103";
	public static final String NOT_FOUND="404";
	public static final String NO_DATA="406";
	public static final String NULL_DATA="413";
	public static final String APPROVERS_EXISTS = "200";
	public static final String USR_EXISTS="300";
	public static final String USR_NOT_EXISTS="301";
	public static final String PARTIAL_SAVE="112";	
	public static final String NOT_ALLOWED="123";	
}
