package com.loyalty.utils;

public class ResponseMsg {
	public static final String SUCCESS="Success";
	public static final String INPUT_MISSING="An input parameter is missing {0}";
	public static final String NO_FORM="Form does not have configuration";
	
	public static final String RENDER_ERROR="Error retrieving form";
	
	public static final String NO_SECTIONS="There are no sections configure in the form";
	public static final String NO_FIELDS="There are no fields configure in the section";
	public static final String NOT_FOUND="Not Found";
	public static final String NO_DATA="Error to call data layer";
	public static final String NULL_DATA="Null data returned";
	public static final String USR_EXISTS="The user exists alredy";
	public static final String USR_NOT_EXISTS="The user you want to modify does not exists";
	public static final String PARTIAL_SAVE="Partial Save. User created successful, but {0} did not";	
	public static final String NOT_ALLOWED="You do not have permission to this information";	
	public static final String APPROVERS_EXISTS="Approver Already exists for this area ";
}
