package com.loyalty.utils;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

public class SoapClient extends WebServiceGatewaySupport {
	
	public SoapClient(String pojoLocation){
		loadConfiguration(pojoLocation);
	}
	
	public <T, U> U soapCall(String serviceUrl, String callbackUrl, T input, Class<U> outputType)
		throws ClassCastException {
		return outputType.cast(
			getWebServiceTemplate().marshalSendAndReceive(
				serviceUrl,
				input,
				new SoapActionCallback(callbackUrl)));
	}
	
	private void loadConfiguration(String pojoLocation){
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		
		marshaller.setContextPath(pojoLocation);
		
		this.setMarshaller(marshaller);
		this.setUnmarshaller(marshaller);
	}
}