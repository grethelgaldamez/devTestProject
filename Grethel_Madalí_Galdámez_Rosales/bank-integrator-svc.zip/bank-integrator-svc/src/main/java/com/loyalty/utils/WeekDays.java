package com.loyalty.utils;

public class WeekDays {
	public static final String SUN = "SUN";
	public static final String MON = "MON";
	public static final String TUE = "TUE";
	public static final String WED = "WED";	
	public static final String THU = "THU";
	public static final String FRI = "FRI";
	public static final String SAT = "SAT";
	
	public static final String DOM = "D";
	public static final String LUN = "L";
	public static final String MAR = "M";
	public static final String MIE = "M";	
	public static final String JUE = "J";
	public static final String VIE = "V";
	public static final String SAB = "S";
}
