package com.loyalty.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.loyalty.pojo.envelope.Envelope;
import com.loyalty.pojo.envelope.Status;
import com.loyalty.pojo.operations.Transfers;
import com.loyalty.pojo.recipient.AddRecipient;
import com.loyalty.pojo.svc.UserSvc;
import com.loyalty.pojo.svc.options.ProdMenu;
import com.loyalty.pojo.svc.products.BankAccount;
import com.loyalty.pojo.svc.products.CreditCard;
import com.loyalty.pojo.svc.products.Loan;
import com.loyalty.process.IUserProcess;

@RestController
public class LoginController {
	private IUserProcess process;
	
	public LoginController(@Qualifier("BeanProcessUser") IUserProcess process){
		this.process = process;
	}

	@PostMapping("${config.endpoints.user.validate}")
	public Envelope<Status, UserSvc> validateUser(
			@RequestBody UserSvc user){
		return process.validate(user.getUsername(), user.getPassword());
	}
	
	@GetMapping("${config.endpoints.user.all-products}")
	public Envelope<Status, ProdMenu> getAllProducts(
			@PathVariable("usrCode") String userCode){
		return process.allProducts(userCode);
	}

	
	@GetMapping(value = "${config.endpoints.user.all-transactions-account}", params = {"start", "end"})
	@ResponseBody
	public Envelope<Status, BankAccount> getAllTransactionsAccount(
		@RequestHeader("userCode") String user,
		@PathVariable("accountID") String prd,
		@RequestParam("start") Date start,
		@RequestParam("end") Date end) {
		return process.allTransactionsAccount(prd, start, end, user);
	}
	
	@GetMapping(value = "${config.endpoints.user.all-transactions-loan}", params = {"start", "end"})
	@ResponseBody
	public Envelope<Status, Loan> getAllTransactionsLoan(
		@RequestHeader("userCode") String user,
		@PathVariable("accountID") String prd,
		@RequestParam("start") Date start,
		@RequestParam("end") Date end) {
		return process.allTransactionsLoan(prd, start, end, user);
	}
	
	@GetMapping(value = "${config.endpoints.user.all-transactions-card}", params = {"start", "end"})
	@ResponseBody
	public Envelope<Status, CreditCard> getAllTransactionsCard(
		@RequestHeader("userCode") String user,
		@PathVariable("accountID") String prd,
		@RequestParam("start") String start,
		@RequestParam("end") String end) throws ParseException {
		SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date1 = myFormat.parse(start);
	    Date date2 = myFormat.parse(end);
		return process.allTransactionsCard(prd, date1, date2, user);
	}
	
	@PostMapping("${config.endpoints.user.add-recipient}")
	public Envelope<Status, Boolean> addRecipient(
			@RequestBody AddRecipient user){
		return process.addRecipient(user);
	}
	
	@PostMapping("${config.endpoints.user.account-transfer}")
	public Envelope<Status, Boolean> accountTransfer(
			@RequestBody Transfers trans){
		return process.transferAccount(trans);
	}
	
	@PostMapping("${config.endpoints.user.card-payment}")
	public Envelope<Status, Boolean> cardPayment(
			@RequestBody Transfers trans){
		return process.cardPayment(trans);
	}
	
	@PostMapping("${config.endpoints.user.loan-payment}")
	public Envelope<Status, Boolean> loanPayment(
			@RequestBody Transfers trans){
		return process.loanPayment(trans);
	}

}
