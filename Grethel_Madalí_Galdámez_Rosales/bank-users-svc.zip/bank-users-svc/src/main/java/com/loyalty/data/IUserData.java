package com.loyalty.data;

import java.util.List;

import com.loyalty.entity.PrdProduct;
import com.loyalty.entity.RecRecipient;
import com.loyalty.pojo.operations.Transfers;
import com.loyalty.pojo.recipient.AddRecipient;
import com.loyalty.pojo.svc.User;
import com.loyalty.pojo.svc.options.ProdMenu;
import com.loyalty.pojo.svc.products.Transaction;

public interface IUserData<T> {	
	public boolean exists(String user);
	public boolean addTries(String user);
	public T retrieveUserByPwd(String user, String pwd);
	boolean update(User input);
	public T retrieveUser(String user);
	public ProdMenu allProducts(String userCode);
	List<Transaction> allTransactions(String prod);
	public PrdProduct getProdInfo(String prod);
	public int addRecipient(AddRecipient ben);
	public int transfer(Transfers transfer);
	public int transferCard(Transfers transfer);
	public int transferLoan(Transfers transfer);
}
