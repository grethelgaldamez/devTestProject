package com.loyalty.data;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.loyalty.entity.UsrUser;
import com.loyalty.entity.PrdProduct;
import com.loyalty.entity.RecRecipient;
import com.loyalty.entity.RecRecipientId;
import com.loyalty.entity.TraTransaction;
import com.loyalty.entity.TraTransactionId;
import com.loyalty.pojo.operations.Transfers;
import com.loyalty.pojo.recipient.AddRecipient;
import com.loyalty.pojo.svc.User;
import com.loyalty.pojo.svc.options.ProdItem;
import com.loyalty.pojo.svc.options.ProdMenu;
import com.loyalty.pojo.svc.options.ProdMin;
import com.loyalty.pojo.svc.products.Transaction;
import com.loyalty.repository.ProductRepository;
import com.loyalty.repository.RecipientRepository;
import com.loyalty.repository.TransactionRepository;
import com.loyalty.repository.UserRepository;

@Service("UserDataBase")
public class UserDataBase implements IUserData<User>{
	private UserRepository repo;
	private ProductRepository repoProd;
	private TransactionRepository repoTrans;
	private RecipientRepository repoRec;
	private Logger log;
	private Environment env;
	
	
	public UserDataBase(
			UserRepository repo,
			ProductRepository repoProd,
			TransactionRepository repoTrans,
			RecipientRepository repoRec,
			Environment env){
		this.repo = repo;
		this.env = env;
		this.repoProd = repoProd;
		this.repoTrans = repoTrans;
		this.repoRec = repoRec;
		this.log =  LoggerFactory.getLogger("com.loyalty.logger");
	}

	@Override
	public boolean exists(String user) {
		return repo.existsById(user);
	}

	@Override
	public User retrieveUserByPwd(String userCode, String pwd) {
		UsrUser userRepo = repo.findByUsrCodeAndUsrPassword(userCode, pwd);
		User user = null;
		
		if(userRepo!=null){
			user = new User();
			user.setUserName(userRepo.getUsrCode());
			user.setPassword(userRepo.getUsrPassword());
			user.setResetPwd(userRepo.getUsrResetPwd());
			user.setTries(Integer.parseInt(userRepo.getUsrLoginTries().toString()));
			user.setExpirePwd(userRepo.getUsrPwdUpdDate());
			
			if(userRepo.getUsrStatus()!=null){
				user.setUserStatus(userRepo.getUsrStatus().charAt(0));
			}
		}
		return user;
	}

	@Override
	public boolean addTries(String userCode) {
		try{
			UsrUser user = repo.findById(userCode).get();
			BigDecimal cont = user.getUsrLoginTries();
			cont = cont.add(new BigDecimal(1));
			user.setUsrLoginTries(cont);
			
			if(Integer.parseInt(cont.toString()) >= 5) {
				user.setUsrStatus("I");
			}
			
			repo.save(user);
			return true;
		}
		catch(Exception ex){
			log.error("Error in update user in database: {}",ex.getMessage(), ex);
		}
		return false;
	}

	@Override
	public boolean update(User input) {
		try{
			UsrUser user = repo.findById(input.getUserName()).get();
			
			user.setUsrStatus(String.valueOf(input.getUserStatus()));
			user.setUsrModifiedDate(new Date());
			user.setUsrModifiedBy(input.getCreatedOrModifyBy());
			user.setUsrLoginTries(new BigDecimal(input.getTries()));
			user.setUsrLastLoginDate(input.getLastLoginDate());
			repo.save(user);
			return true;
		}
		catch(Exception ex){
			log.error("Error in update user in database: {}",ex.getMessage(), ex);
		}
		return false;
	}

	@Override
	public User retrieveUser(String user) {
		UsrUser ubd = repo.findByUsrCode(user); 
		User ans = new User();
		
		ans.setTries(Integer.parseInt(ubd.getUsrLoginTries().toString()));
		ans.setUserStatus(ubd.getUsrStatus().charAt(0));
		
		return ans;
	}
	
	@Override
	public ProdMenu allProducts(String userCode) {
		List<PrdProduct> userRepo = repoProd.findByIdPrdCodusr(userCode);
		
		List<ProdMin> account = new ArrayList<>();
		List<ProdMin> loan = new ArrayList<>();
		List<ProdMin> creditCard = new ArrayList<>();
		
		ProdMenu menu = new ProdMenu();
		ProdMin obj;
		ProdItem pi = new ProdItem();
		
		if(userRepo!=null){
			for(PrdProduct pp : userRepo) {
				if(pp.getPrdCategory().equals(env.getProperty("config.product.type.credit"))) {
					obj = new ProdMin();
					obj.setId(pp.getId().getPrdCode());
					obj.setName(env.getProperty("config.product.name.credit"));
					creditCard.add(obj);
				}else if(pp.getPrdCategory().equals(env.getProperty("config.product.type.debit"))) {
					obj = new ProdMin();
					obj.setId(pp.getId().getPrdCode());
					obj.setName(env.getProperty("config.product.name.debit"));
					creditCard.add(obj);
				}else if(pp.getPrdCategory().equals(env.getProperty("config.product.type.account"))) {
					obj = new ProdMin();
					obj.setId(pp.getId().getPrdCode());
					obj.setName(env.getProperty("config.product.name.account"));
					account.add(obj);
				}else{
					obj = new ProdMin();
					obj.setId(pp.getId().getPrdCode());
					obj.setName(env.getProperty("config.product.name.loan"));
					loan.add(obj);
				}	
			}
		}
		
		pi.setLoan(loan);
		pi.setCreditCard(creditCard);
		pi.setPersonal(account);
		
		menu.setAccounts(pi);
		
		return menu;
	}
	
	@Override
	public List<Transaction> allTransactions(String prod) {
		List<Transaction> lista = new ArrayList<>();
		List<TraTransaction> trans = repoTrans.findByIdTraProductId(prod);
		
		for(TraTransaction tt : trans) {
			Transaction t = new Transaction();
			t.setId(tt.getId().getTraCode());
			t.setDescription(tt.getTraDescription());
			t.setDate(tt.getTraCreatedDate());
			t.setAmount(Double.parseDouble(tt.getTraAmount().toString()));
			lista.add(t);
		}
		
		return lista;
	}

	@Override
	public PrdProduct getProdInfo(String prod) {
		return repoProd.findByIdPrdCode(prod);
	}

	@Override
	public int addRecipient(AddRecipient ben) {
		RecRecipient rec = new RecRecipient();
		RecRecipientId id = new RecRecipientId();
		UsrUser user = repo.findByUsrCode(ben.getUsrCode());
		RecRecipient exist = repoRec.findByIdRecUsrcodeAndIdRecCode(ben.getUsrCode(), ben.getAccNumber());
		
		//validación que exista el usuario
		if(user == null) {
			return 404;
		}
		
		//validación que no esté registrado
		if(exist != null) {
			return 409;
		}
		
		//validación de correo
		String emailPattern = "^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@" +
			      "[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,4})$";
		Pattern pattern = Pattern.compile(emailPattern);
		String email = ben.getEmail();
		
		if (email != null) {
			Matcher matcher = pattern.matcher(email);
			if (!matcher.matches()) 
				return 400;
		}

		id.setRecUsrcode(ben.getUsrCode());
		id.setRecCode(ben.getAccNumber());
		rec.setId(id);
		
		rec.setRecAccountType(ben.getType());
		rec.setRecCreatedBy(ben.getUsrCode());
		rec.setRecCreatedDate(new Date());
		rec.setRecEmail(ben.getEmail());
		rec.setRecName(ben.getName());
		rec.setRecStatus("A");
		
		RecRecipient ans = repoRec.save(rec);
		
		//validación que se guardó
		if(ans != null) {
			return 201;
		}else {
			return 400;
		}
	}

	@Override
	public int transfer(Transfers transfer) {
		PrdProduct origen = repoProd.findByIdPrdCode(transfer.getOrigen());
		PrdProduct destino = repoProd.findByIdPrdCode(transfer.getDestino());
		
		if((origen.getId().getPrdCodusr() != destino.getId().getPrdCodusr()) 
				|| (origen.getPrdCategory() != env.getProperty("config.product.type.account"))
				|| (destino.getPrdCategory() != env.getProperty("config.product.type.account"))) {
			return 404;
		}
		
		if(Double.parseDouble(origen.getPrdAvailableDebt().toString()) > transfer.getAmount()) {
			return 409;
		}
		
		//primera transacción
		TraTransactionId id = new TraTransactionId();
		id.setTraCodusr(origen.getId().getPrdCodusr());
		id.setTraProductId(transfer.getOrigen());
		Date hora = new Date();
		String time = String.valueOf(hora.getHours()) + String.valueOf(hora.getMinutes()) + String.valueOf(hora.getSeconds()) +
				String.valueOf(hora.getMonth()) + String.valueOf(hora.getDay());
		id.setTraCode(time + transfer.getOrigen() + transfer.getDestino());
		
		TraTransaction ans = new TraTransaction();
		ans.setId(id);
		ans.setPrdProduct(origen);
		ans.setTraAmount(BigDecimal.valueOf(transfer.getAmount()*-1));
		ans.setTraCreatedDate(new Date());
		ans.setTraDescription("Account transfer");
		TraTransaction ans2 = repoTrans.save(ans);
		
		if(ans2 == null)
			return 500;
		
		//para que no tenga el mismo código
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		//segunda transacción
		id = new TraTransactionId();
		id.setTraCodusr(origen.getId().getPrdCodusr());
		id.setTraProductId(transfer.getOrigen());
		hora = new Date();
		time = String.valueOf(hora.getHours()) + String.valueOf(hora.getMinutes()) + String.valueOf(hora.getSeconds()) +
				String.valueOf(hora.getMonth()) + String.valueOf(hora.getDay());
		id.setTraCode(time + transfer.getOrigen() + transfer.getDestino());
		
		ans = new TraTransaction();
		ans.setId(id);
		ans.setPrdProduct(origen);
		ans.setTraAmount(BigDecimal.valueOf(transfer.getAmount()));
		ans.setTraCreatedDate(new Date());
		ans.setTraDescription("Account transfer");
		ans2 = repoTrans.save(ans);
		
		if(ans2 == null)
			return 500;
		
		origen.setPrdAvailableDebt(BigDecimal.valueOf((Double.parseDouble(origen.getPrdAvailableDebt().toString()) - transfer.getAmount())));
		PrdProduct origen2 = repoProd.save(origen);
		
		if(origen2 == null)
			return 500;
		
		destino.setPrdAvailableDebt(BigDecimal.valueOf((Double.parseDouble(destino.getPrdAvailableDebt().toString()) + transfer.getAmount())));
		PrdProduct destino2 = repoProd.save(origen);
		
		if(destino2 == null)
			return 500;

		//caso de éxito
		return 200;
	}

	@Override
	public int transferCard(Transfers transfer) {
		PrdProduct origen = repoProd.findByIdPrdCode(transfer.getOrigen());
		PrdProduct destino = repoProd.findByIdPrdCode(transfer.getDestino());
		
		if((origen.getId().getPrdCodusr() != destino.getId().getPrdCodusr()) 
				|| (origen.getPrdCategory() != env.getProperty("config.product.type.account"))
				|| (destino.getPrdCategory() != env.getProperty("config.product.type.credit"))) {
			return 400;
		}
		
		if(Double.parseDouble(origen.getPrdAvailableDebt().toString()) > transfer.getAmount()) {
			return 409;
		}
		
		//primera transacción
		TraTransactionId id = new TraTransactionId();
		id.setTraCodusr(origen.getId().getPrdCodusr());
		id.setTraProductId(transfer.getOrigen());
		Date hora = new Date();
		String time = String.valueOf(hora.getHours()) + String.valueOf(hora.getMinutes()) + String.valueOf(hora.getSeconds()) +
				String.valueOf(hora.getMonth()) + String.valueOf(hora.getDay());
		id.setTraCode(time + transfer.getOrigen() + transfer.getDestino());
		
		TraTransaction ans = new TraTransaction();
		ans.setId(id);
		ans.setPrdProduct(origen);
		ans.setTraAmount(BigDecimal.valueOf(transfer.getAmount()*-1));
		ans.setTraCreatedDate(new Date());
		ans.setTraDescription("Credit card payment");
		TraTransaction ans2 = repoTrans.save(ans);
		
		if(ans2 == null)
			return 500;
		
		//para que no tenga el mismo código
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		//segunda transacción
		id = new TraTransactionId();
		id.setTraCodusr(origen.getId().getPrdCodusr());
		id.setTraProductId(transfer.getOrigen());
		hora = new Date();
		time = String.valueOf(hora.getHours()) + String.valueOf(hora.getMinutes()) + String.valueOf(hora.getSeconds()) +
				String.valueOf(hora.getMonth()) + String.valueOf(hora.getDay());
		id.setTraCode(time + transfer.getOrigen() + transfer.getDestino());
		
		ans = new TraTransaction();
		ans.setId(id);
		ans.setPrdProduct(origen);
		ans.setTraAmount(BigDecimal.valueOf(transfer.getAmount()));
		ans.setTraCreatedDate(new Date());
		ans.setTraDescription("Credit card payment");
		ans2 = repoTrans.save(ans);
		
		if(ans2 == null)
			return 500;
		
		origen.setPrdAvailableDebt(BigDecimal.valueOf((Double.parseDouble(origen.getPrdAvailableDebt().toString()) - transfer.getAmount())));
		PrdProduct origen2 = repoProd.save(origen);
		
		if(origen2 == null)
			return 500;
		
		destino.setPrdAvailableDebt(BigDecimal.valueOf((Double.parseDouble(destino.getPrdAvailableDebt().toString()) + transfer.getAmount())));
		PrdProduct destino2 = repoProd.save(origen);
		
		if(destino2 == null)
			return 500;

		//caso de éxito
		return 200;
	}

	@Override
	public int transferLoan(Transfers transfer) {
		PrdProduct origen = repoProd.findByIdPrdCode(transfer.getOrigen());
		PrdProduct destino = repoProd.findByIdPrdCode(transfer.getDestino());
		
		if((origen.getId().getPrdCodusr() != destino.getId().getPrdCodusr()) 
				|| (origen.getPrdCategory() != env.getProperty("config.product.type.account"))
				|| (destino.getPrdCategory() != env.getProperty("config.product.type.loan"))) {
			return 400;
		}
		
		if(Double.parseDouble(origen.getPrdAvailableDebt().toString()) > transfer.getAmount()) {
			return 409;
		}
		
		//primera transacción
		TraTransactionId id = new TraTransactionId();
		id.setTraCodusr(origen.getId().getPrdCodusr());
		id.setTraProductId(transfer.getOrigen());
		Date hora = new Date();
		String time = String.valueOf(hora.getHours()) + String.valueOf(hora.getMinutes()) + String.valueOf(hora.getSeconds()) +
				String.valueOf(hora.getMonth()) + String.valueOf(hora.getDay());
		id.setTraCode(time + transfer.getOrigen() + transfer.getDestino());
		
		TraTransaction ans = new TraTransaction();
		ans.setId(id);
		ans.setPrdProduct(origen);
		ans.setTraAmount(BigDecimal.valueOf(transfer.getAmount()*-1));
		ans.setTraCreatedDate(new Date());
		ans.setTraDescription("Credit card payment");
		TraTransaction ans2 = repoTrans.save(ans);
		
		if(ans2 == null)
			return 500;
		
		//para que no tenga el mismo código
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		//segunda transacción
		id = new TraTransactionId();
		id.setTraCodusr(origen.getId().getPrdCodusr());
		id.setTraProductId(transfer.getOrigen());
		hora = new Date();
		time = String.valueOf(hora.getHours()) + String.valueOf(hora.getMinutes()) + String.valueOf(hora.getSeconds()) +
				String.valueOf(hora.getMonth()) + String.valueOf(hora.getDay());
		id.setTraCode(time + transfer.getOrigen() + transfer.getDestino());
		
		ans = new TraTransaction();
		ans.setId(id);
		ans.setPrdProduct(origen);
		ans.setTraAmount(BigDecimal.valueOf(transfer.getAmount()));
		ans.setTraCreatedDate(new Date());
		ans.setTraDescription("Credit card payment");
		ans2 = repoTrans.save(ans);
		
		if(ans2 == null)
			return 500;
		
		origen.setPrdAvailableDebt(BigDecimal.valueOf((Double.parseDouble(origen.getPrdAvailableDebt().toString()) - transfer.getAmount())));
		PrdProduct origen2 = repoProd.save(origen);
		
		if(origen2 == null)
			return 500;
		
		destino.setPrdAvailableDebt(BigDecimal.valueOf((Double.parseDouble(destino.getPrdAvailableDebt().toString()) - transfer.getAmount())));
		PrdProduct destino2 = repoProd.save(origen);
		
		if(destino2 == null)
			return 500;

		//caso de éxito
		return 200;
	}
}
