package com.loyalty.data;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.loyalty.entity.PrdProduct;
import com.loyalty.entity.RecRecipient;
import com.loyalty.pojo.operations.Transfers;
import com.loyalty.pojo.recipient.AddRecipient;
import com.loyalty.pojo.svc.User;
import com.loyalty.pojo.svc.options.ProdMenu;
import com.loyalty.pojo.svc.products.Transaction;



@Service("UserStatic")
public class UserStatic implements IUserData<User>{
	private List<User> users;	
	
	public UserStatic(Environment env){		
		users = new ArrayList<>();

		//inserts de users
		
		/*User user = new User();
		user.setUserName("LIPEREZ");
		user.setPassword("1233");
		user.setUserState('A');
		user.setTries(0);
		
		Calendar pwdUpd = Calendar.getInstance();
		pwdUpd.setTime(new Date());
		pwdUpd.add(Calendar.DAY_OF_YEAR, -150);
	
		user.setExpirePwd(pwdUpd.getTime());
		users.add(user);*/
	
		
	}

	@Override
	public boolean exists(String user) {
		return users.stream().filter(x->x.getUserName().equals(user)).findFirst().isPresent();
	}

	@Override
	public boolean update(User user) {
		return true;
	}

	@Override
	public User retrieveUserByPwd(String user, String pwd) {
		return users.stream().filter(x -> x.getUserName().equals(user) && x.getPassword().equals(pwd)).findFirst().orElse(null);
	}

	@Override
	public boolean addTries(String user) {
		return true;
	}

	@Override
	public User retrieveUser(String user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProdMenu allProducts(String userCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> allTransactions(String userCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PrdProduct getProdInfo(String prod) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addRecipient(AddRecipient ben) {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public int transfer(Transfers transfer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int transferCard(Transfers transfer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int transferLoan(Transfers transfer) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
