package com.loyalty.entity;
// Generated 05-08-2018 08:39:31 AM by Hibernate Tools 5.2.0.Beta1

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "prd_product")
public class PrdProduct implements java.io.Serializable {

	private PrdProductId id;
	private UsrUser usrUser;
	private String prdCategory;
	private BigDecimal prdTotalLimit;
	private BigDecimal prdAvailableDebt;
	private BigDecimal prdInterestRate;
	private BigDecimal prdInterestAmount;
	private BigDecimal prdMonthlyCut;
	private String prdCreatedBy;
	private Date prdCreatedDate;
	private String prdModifiedBy;
	private Date prdModifiedDate;
	private Set<TraTransaction> traTransaction = new HashSet<TraTransaction>(0);

	public PrdProduct() {
	}

	//PRODUCTO CUENTA BANCARIA
	public PrdProduct(PrdProductId id, UsrUser usrUser, String prdCategory, BigDecimal prdAvailableDebt,
			String prdCreatedBy, Date prdCreatedDate, String prdModifiedBy,	Date prdModifiedDate) {
		super();
		this.id = id;
		this.usrUser = usrUser;
		this.prdCategory = prdCategory;
		this.prdAvailableDebt = prdAvailableDebt;
		this.prdCreatedBy = prdCreatedBy;
		this.prdCreatedDate = prdCreatedDate;
		this.prdModifiedBy = prdModifiedBy;
		this.prdModifiedDate = prdModifiedDate;
	}

	//PRODUCTO TARJETA DE CRÉDITO / PRÉSTAMO (TODOS LOS CAMPOS)
	public PrdProduct(PrdProductId id, UsrUser usrUser, String prdCategory, BigDecimal prdTotalLimit,
			BigDecimal prdAvailableDebt, BigDecimal prdInterestRate, BigDecimal prdInterestAmount,
			BigDecimal prdMonthlyCut, String prdCreatedBy, Date prdCreatedDate, String prdModifiedBy,
			Date prdModifiedDate) {
		super();
		this.id = id;
		this.usrUser = usrUser;
		this.prdCategory = prdCategory;
		this.prdTotalLimit = prdTotalLimit;
		this.prdAvailableDebt = prdAvailableDebt;
		this.prdInterestRate = prdInterestRate;
		this.prdInterestAmount = prdInterestAmount;
		this.prdMonthlyCut = prdMonthlyCut;
		this.prdCreatedBy = prdCreatedBy;
		this.prdCreatedDate = prdCreatedDate;
		this.prdModifiedBy = prdModifiedBy;
		this.prdModifiedDate = prdModifiedDate;
	}
	
	//all fields
	public PrdProduct(PrdProductId id, UsrUser usrUser, String prdCategory, BigDecimal prdTotalLimit,
			BigDecimal prdAvailableDebt, BigDecimal prdInterestRate, BigDecimal prdInterestAmount,
			BigDecimal prdMonthlyCut, String prdCreatedBy, Date prdCreatedDate, String prdModifiedBy,
			Date prdModifiedDate, Set<TraTransaction> traTransaction) {
		super();
		this.id = id;
		this.usrUser = usrUser;
		this.prdCategory = prdCategory;
		this.prdTotalLimit = prdTotalLimit;
		this.prdAvailableDebt = prdAvailableDebt;
		this.prdInterestRate = prdInterestRate;
		this.prdInterestAmount = prdInterestAmount;
		this.prdMonthlyCut = prdMonthlyCut;
		this.prdCreatedBy = prdCreatedBy;
		this.prdCreatedDate = prdCreatedDate;
		this.prdModifiedBy = prdModifiedBy;
		this.prdModifiedDate = prdModifiedDate;
		this.traTransaction = traTransaction;
	}

	@EmbeddedId

	@AttributeOverrides({
			@AttributeOverride(name = "prdCodusr", column = @Column(name = "prd_codusr", nullable = false, length = 25)),
			@AttributeOverride(name = "prdCode", column = @Column(name = "prd_code", nullable = false, length = 25))})
	public PrdProductId getId() {
		return this.id;
	}

	public void setId(PrdProductId id) {
		this.id = id;
	}

	@Column(name = "prd_category", unique = true, nullable = false, length = 1)
	public String getPrdCategory() {
		return this.prdCategory;
	}

	public void setPrdCategory(String prdCategory) {
		this.prdCategory = prdCategory;
	}

	@Column(name = "prd_total_limit", precision = 131089, scale = 0)
	public BigDecimal getPrdTotalLimit() {
		return this.prdTotalLimit;
	}

	public void setPrdTotalLimit(BigDecimal prdTotalLimit) {
		this.prdTotalLimit = prdTotalLimit;
	}
	
	@Column(name = "prd_available_debt", precision = 131089, scale = 0)
	public BigDecimal getPrdAvailableDebt() {
		return this.prdAvailableDebt;
	}

	public void setPrdAvailableDebt(BigDecimal prdAvailableDebt) {
		this.prdAvailableDebt = prdAvailableDebt;
	}
	
	@Column(name = "prd_interest_rate", precision = 131089, scale = 0)
	public BigDecimal getPrdInterestRate() {
		return this.prdInterestRate;
	}

	public void setPrdInterestRate(BigDecimal prdInterestRate) {
		this.prdInterestRate = prdInterestRate;
	}
	
	@Column(name = "prd_interest_amount", precision = 131089, scale = 0)
	public BigDecimal getPrdInterestAmount() {
		return this.prdInterestAmount;
	}

	public void setPrdInterestAmount(BigDecimal prdInterestAmount) {
		this.prdInterestAmount = prdInterestAmount;
	}
	
	@Column(name = "prd_monthly_cut", precision = 131089, scale = 0)
	public BigDecimal getPrdMonthlyCut() {
		return this.prdMonthlyCut;
	}

	public void setPrdMonthlyCut(BigDecimal prdMonthlyCut) {
		this.prdMonthlyCut = prdMonthlyCut;
	}
	
	@Column(name = "prd_created_by", nullable = false, length = 25)
	public String getPrdCreatedBy() {
		return this.prdCreatedBy;
	}

	public void setPrdCreatedBy(String prdCreatedBy) {
		this.prdCreatedBy = prdCreatedBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "prd_created_date", nullable = false, length = 29)
	public Date getPrdCreatedDate() {
		return this.prdCreatedDate;
	}

	public void setPrdCreatedDate(Date prdCreatedDate) {
		this.prdCreatedDate = prdCreatedDate;
	}

	@Column(name = "prd_modified_by", length = 25)
	public String getPrdModifiedBy() {
		return this.prdModifiedBy;
	}

	public void setPrdModifiedBy(String prdModifiedBy) {
		this.prdModifiedBy = prdModifiedBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "prd_modified_date", length = 29)
	public Date getPrdModifiedDate() {
		return this.prdModifiedDate;
	}

	public void setPrdModifiedDate(Date prdModifiedDate) {
		this.prdModifiedDate = prdModifiedDate;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "prd_codusr", nullable = false, insertable = false, updatable = false)
	public UsrUser getUsrUser() {
		return this.usrUser;
	}

	public void setUsrUser(UsrUser usrUser) {
		this.usrUser = usrUser;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "prdProduct")
	public Set<TraTransaction> getTraTransaction() {
		return this.traTransaction;
	}

	public void setTraTransaction(Set<TraTransaction> traTransaction) {
		this.traTransaction = traTransaction;
	}


}
