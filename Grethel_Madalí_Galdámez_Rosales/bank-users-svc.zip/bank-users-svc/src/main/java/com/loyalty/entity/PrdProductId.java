package com.loyalty.entity;
// Generated 05-08-2018 08:39:31 AM by Hibernate Tools 5.2.0.Beta1

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PrdProductId implements java.io.Serializable {

	private String prdCodusr;
	private String prdCode;

	public PrdProductId() {
	}

	public PrdProductId(String prdCodusr, String prdCode) {
		this.prdCodusr = prdCodusr;
		this.prdCode = prdCode;
	}
	
	@Column(name = "prd_codusr", unique = true, nullable = false, length = 25)
	public String getPrdCodusr() {
		return this.prdCodusr;
	}

	public void setPrdCodusr(String prdCodusr) {
		this.prdCodusr = prdCodusr;
	}
	
	@Column(name = "prd_code", unique = true, nullable = false, length = 25)
	public String getPrdCode() {
		return this.prdCode;
	}

	public void setPrdCode(String prdCode) {
		this.prdCode = prdCode;
	}
	
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof PrdProductId))
			return false;
		PrdProductId castOther = (PrdProductId) other;

		return ((this.getPrdCode() == castOther.getPrdCode()) || (this.getPrdCode() != null
				&& castOther.getPrdCode() != null && this.getPrdCode().equals(castOther.getPrdCode())))
				&& ((this.getPrdCodusr() == castOther.getPrdCodusr())
						|| (this.getPrdCodusr() != null && castOther.getPrdCodusr() != null
								&& this.getPrdCodusr().equals(castOther.getPrdCodusr())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getPrdCode() == null ? 0 : this.getPrdCode().hashCode());
		result = 37 * result + (getPrdCodusr() == null ? 0 : this.getPrdCodusr().hashCode());
		return result;
	}

}
