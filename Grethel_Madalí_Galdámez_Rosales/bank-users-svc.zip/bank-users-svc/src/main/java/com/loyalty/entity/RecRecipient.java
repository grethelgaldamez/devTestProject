package com.loyalty.entity;
// Generated 05-08-2018 08:39:31 AM by Hibernate Tools 5.2.0.Beta1

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "rec_recipient")
public class RecRecipient implements java.io.Serializable {

	private RecRecipientId id;
	private UsrUser usrUser;
	
	private String recName;
	private String recEmail;
	private String recAccountType;
	private String recStatus;
	
	private String recCreatedBy;
	private Date recCreatedDate;
	private String recModifiedBy;
	private Date recModifiedDate;
	private Set<TraTransaction> traTransaction = new HashSet<TraTransaction>(0);

	public RecRecipient() {
	}

	//ALL FIELDS
	public RecRecipient(RecRecipientId id, UsrUser usrUser, String recName, String recEmail, String recAccountType,
			String recStatus, String recCreatedBy, Date recCreatedDate, String recModifiedBy, Date recModifiedDate,
			Set<TraTransaction> traTransaction) {
		super();
		this.id = id;
		this.usrUser = usrUser;
		this.recName = recName;
		this.recEmail = recEmail;
		this.recAccountType = recAccountType;
		this.recStatus = recStatus;
		this.recCreatedBy = recCreatedBy;
		this.recCreatedDate = recCreatedDate;
		this.recModifiedBy = recModifiedBy;
		this.recModifiedDate = recModifiedDate;
		this.traTransaction = traTransaction;
	}



	@EmbeddedId

	@AttributeOverrides({
			@AttributeOverride(name = "recUsrcode", column = @Column(name = "rec_usrcode", nullable = false, length = 25)),
			@AttributeOverride(name = "recCode", column = @Column(name = "rec_code", nullable = false, length = 25))})
	public RecRecipientId getId() {
		return this.id;
	}

	public void setId(RecRecipientId id) {
		this.id = id;
	}

	@Column(name = "rec_name", unique = true, nullable = false, length = 25)
	public String getRecName() {
		return this.recName;
	}

	public void setRecName(String recName) {
		this.recName = recName;
	}
	
	@Column(name = "rec_email", nullable = false, length = 25)
	public String getRecEmail() {
		return this.recEmail;
	}

	public void setRecEmail(String recEmail) {
		this.recEmail = recEmail;
	}

	@Column(name = "rec_account_type", nullable = false, length = 1)
	public String getRecAccountType() {
		return this.recAccountType;
	}

	public void setRecAccountType(String recAccountType) {
		this.recAccountType = recAccountType;
	}
	
	@Column(name = "rec_status", nullable = false, length = 1)
	public String getRecStatus() {
		return this.recStatus;
	}

	public void setRecStatus(String recStatus) {
		this.recStatus = recStatus;
	}

	@Column(name = "rec_created_by", length = 25, nullable = false)
	public String getRecCreatedBy() {
		return this.recCreatedBy;
	}

	public void setRecCreatedBy(String recCreatedBy) {
		this.recCreatedBy = recCreatedBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "rec_created_date", length = 29,  nullable = false)
	public Date getRecCreatedDate() {
		return this.recCreatedDate;
	}

	public void setRecCreatedDate(Date recCreatedDate) {
		this.recCreatedDate = recCreatedDate;
	}
	
	@Column(name = "rec_modified_by", length = 25)
	public String getRecModifiedBy() {
		return this.recModifiedBy;
	}

	public void setRecModifiedBy(String recModifiedBy) {
		this.recModifiedBy = recModifiedBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "rec_modified_date", length = 29)
	public Date getRecModifiedDate() {
		return this.recModifiedDate;
	}

	public void setRecModifiedDate(Date recModifiedDate) {
		this.recModifiedDate = recModifiedDate;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "rec_usrcode", nullable = false, insertable = false, updatable = false)
	public UsrUser getUsrUser() {
		return this.usrUser;
	}

	public void setUsrUser(UsrUser usrUser) {
		this.usrUser = usrUser;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "recRecipient")
	public Set<TraTransaction> getTraTransaction() {
		return this.traTransaction;
	}

	public void setTraTransaction(Set<TraTransaction> traTransaction) {
		this.traTransaction = traTransaction;
	}
	

}
