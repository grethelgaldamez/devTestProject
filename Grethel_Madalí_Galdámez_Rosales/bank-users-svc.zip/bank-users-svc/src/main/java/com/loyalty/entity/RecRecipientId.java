package com.loyalty.entity;
// Generated 05-08-2018 08:39:31 AM by Hibernate Tools 5.2.0.Beta1

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RecRecipientId implements java.io.Serializable {
	
	private String recUsrcode;
	private String recCode;

	public RecRecipientId() {
	}

	public RecRecipientId(String recUsrcode, String recCode) {
		this.recUsrcode = recUsrcode;
		this.recCode = recCode;
	}
	
	@Column(name = "rec_usrcode", unique = true, nullable = false, length = 25)
	public String getRecUsrcode() {
		return this.recUsrcode;
	}

	public void setRecUsrcode(String recUsrcode) {
		this.recUsrcode = recUsrcode;
	}
	
	@Column(name = "rec_code", unique = true, nullable = false, length = 25)
	public String getRecCode() {
		return this.recCode;
	}

	public void setRecCode(String recCode) {
		this.recCode = recCode;
	}
	
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof RecRecipientId))
			return false;
		RecRecipientId castOther = (RecRecipientId) other;

		return ((this.getRecCode() == castOther.getRecCode()) || (this.getRecCode() != null
				&& castOther.getRecCode() != null && this.getRecCode().equals(castOther.getRecCode())))
				&& ((this.getRecUsrcode() == castOther.getRecUsrcode())
						|| (this.getRecUsrcode() != null && castOther.getRecUsrcode() != null
								&& this.getRecUsrcode().equals(castOther.getRecUsrcode())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getRecCode() == null ? 0 : this.getRecCode().hashCode());
		result = 37 * result + (getRecUsrcode() == null ? 0 : this.getRecUsrcode().hashCode());
		return result;
	}

}
