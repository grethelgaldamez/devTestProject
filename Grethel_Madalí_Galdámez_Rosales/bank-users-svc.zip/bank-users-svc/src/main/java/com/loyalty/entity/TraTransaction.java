package com.loyalty.entity;
// Generated 05-08-2018 08:39:31 AM by Hibernate Tools 5.2.0.Beta1

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "tra_transaction")
public class TraTransaction implements java.io.Serializable {

	private TraTransactionId id;
	private PrdProduct prdProduct;
	private String traRecipientCode;
	private RecRecipient recRecipient;
	private String traDescription;
	private BigDecimal traAmount;
	private Date traCreatedDate;

	public TraTransaction() {
	}

	public TraTransaction(TraTransactionId id, PrdProduct prdProduct, 
			//RecRecipient recRecipient, 
			String traDescription,
			BigDecimal traAmount, Date traCreatedDate) {
		super();
		this.id = id;
		this.prdProduct = prdProduct;
		//this.recRecipient = recRecipient;
		this.traDescription = traDescription;
		this.traAmount = traAmount;
		this.traCreatedDate = traCreatedDate;
	}


	@EmbeddedId

	@AttributeOverrides({
			@AttributeOverride(name = "traProductId", column = @Column(name = "tra_product_id", nullable = false, length = 25)),
			@AttributeOverride(name = "traCodusr", column = @Column(name = "tra_codusr", nullable = false, length = 25)),
			@AttributeOverride(name = "traCode", column = @Column(name = "tra_code", nullable = false, length = 25))})
	public TraTransactionId getId() {
		return this.id;
	}

	public void setId(TraTransactionId id) {
		this.id = id;
	}

	@Column(name = "tra_description", unique = true, length = 64)
	public String getTraDescription() {
		return this.traDescription;
	}

	public void setTraDescription(String traDescription) {
		this.traDescription = traDescription;
	}
	
	@Column(name = "tra_recipient_code", unique = true, length = 64)
	public String getTraRecipientCode() {
		return this.traRecipientCode;
	}

	public void setTraRecipientCode(String traRecipientCode) {
		this.traRecipientCode = traRecipientCode;
	}

	@Column(name = "tra_amount", precision = 131089, nullable = false, scale = 0)
	public BigDecimal getTraAmount() {
		return this.traAmount;
	}

	public void setTraAmount(BigDecimal traAmount) {
		this.traAmount = traAmount;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "tra_created_date", nullable = false, length = 29)
	public Date getTraCreatedDate() {
		return this.traCreatedDate;
	}

	public void setTraCreatedDate(Date traCreatedDate) {
		this.traCreatedDate = traCreatedDate;
	}

	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name = "tra_product_id", nullable = false, insertable = false, updatable = false),
		@JoinColumn(name = "tra_codusr", nullable = false, insertable = false, updatable = false)})
	public PrdProduct getPrdProduct() {
		return this.prdProduct;
	}

	public void setPrdProduct(PrdProduct prdProduct) {
		this.prdProduct = prdProduct;
	}


	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name = "tra_recipient_code", insertable = false, updatable = false),
		@JoinColumn(name = "tra_codusr", insertable = false, updatable = false)})
	public RecRecipient getRecRecipient() {
		return this.recRecipient;
	}

	public void setRecRecipient(RecRecipient recRecipient) {
		this.recRecipient = recRecipient;
	}
}
