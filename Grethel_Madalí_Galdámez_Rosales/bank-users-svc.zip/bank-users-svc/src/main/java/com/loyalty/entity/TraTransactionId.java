package com.loyalty.entity;
// Generated 05-08-2018 08:39:31 AM by Hibernate Tools 5.2.0.Beta1

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class TraTransactionId implements java.io.Serializable {

	private String traProductId;
	private String traCodusr;
	private String traCode;
	
	public TraTransactionId() {
	}

	public TraTransactionId(String traProductId, String traCode, String traCodusr) {
		this.traProductId = traProductId;
		this.traCodusr = traCodusr;
		this.traCode = traCode;
	}

	@Column(name = "tra_product_id", unique = true, nullable = false, length = 25)
	public String getTraProductId() {
		return this.traProductId;
	}

	public void setTraProductId(String traProductId) {
		this.traProductId = traProductId;
	}
	
	@Column(name = "tra_codusr", unique = true, nullable = false, length = 25)
	public String getTraCodusr() {
		return this.traCodusr;
	}

	public void setTraCodusr(String traCodusr) {
		this.traCodusr = traCodusr;
	}
	
	@Column(name = "tra_code", unique = true, nullable = false, length = 25)
	public String getTraCode() {
		return this.traCode;
	}

	public void setTraCode(String traCode) {
		this.traCode = traCode;
	}

	
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TraTransactionId))
			return false;
		TraTransactionId castOther = (TraTransactionId) other;

		return ((this.getTraCode() == castOther.getTraCode()) || (this.getTraCode() != null
				&& castOther.getTraCode() != null && this.getTraCode().equals(castOther.getTraCode())))
				&& ((this.getTraProductId() == castOther.getTraProductId()) || (this.getTraProductId() != null
				&& castOther.getTraProductId() != null && this.getTraProductId().equals(castOther.getTraProductId())
				&& ((this.getTraCodusr() == castOther.getTraCodusr()) || (this.getTraCodusr() != null
				&& castOther.getTraCodusr() != null && this.getTraCodusr().equals(castOther.getTraCodusr())))));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getTraCode() == null ? 0 : this.getTraCode().hashCode());
		result = 37 * result + (getTraProductId() == null ? 0 : this.getTraProductId().hashCode());
		result = 37 * result + (getTraCodusr() == null ? 0 : this.getTraCodusr().hashCode());
		return result;
	}

}
