package com.loyalty.entity;
// Generated 05-08-2018 08:39:31 AM by Hibernate Tools 5.2.0.Beta1

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "usr_user")
public class UsrUser implements java.io.Serializable {

	private String usrCode;
	private String usrPassword;
	private String usrStatus;
	private Date usrPwdUpdDate;
	private BigDecimal usrLoginTries;
	private Boolean usrResetPwd;
	private Date usrLastLoginDate;
	private String usrCreatedBy;
	private Date usrCreatedDate;
	private String usrModifiedBy;
	private Date usrModifiedDate;
	private Set<PrdProduct> prdProduct = new HashSet<PrdProduct>(0);
	/*private Set<RecRecipient> recRecipient = new HashSet<RecRecipient>(0);*/

	public UsrUser() {
	}

	public UsrUser(String usrCode, String usrPassword, String usrStatus, String usrCreatedBy, Date usrCreatedDate) {
		this.usrCode = usrCode;
		this.usrPassword = usrPassword;
		this.usrStatus = usrStatus;
		this.usrCreatedBy = usrCreatedBy;
		this.usrCreatedDate = usrCreatedDate;
	}

	public UsrUser(String usrCode, String usrPassword, Date usrPwdUpdDate, BigDecimal usrLoginTries,
			Boolean usrResetPwd, Date usrLastLoginDate, String usrStatus, String usrCreatedBy, Date usrCreatedDate, 
			String usrModifiedBy, Date usrModifiedDate) {
		this.usrCode = usrCode;
		this.usrPassword = usrPassword;
		this.usrStatus = usrStatus;
		this.usrPwdUpdDate = usrPwdUpdDate;
		this.usrLoginTries = usrLoginTries;
		this.usrResetPwd = usrResetPwd;
		this.usrLastLoginDate = usrLastLoginDate;
		this.usrCreatedBy = usrCreatedBy;
		this.usrCreatedDate = usrCreatedDate;
		this.usrModifiedBy = usrModifiedBy;
		this.usrModifiedDate = usrModifiedDate;
	}
	
	//all fields
	public UsrUser(String usrCode, String usrPassword, String usrStatus, Date usrPwdUpdDate, BigDecimal usrLoginTries,
			Boolean usrResetPwd, Date usrLastLoginDate, String usrCreatedBy, Date usrCreatedDate, String usrModifiedBy,
			Date usrModifiedDate, Set<PrdProduct> prdProduct
			//, Set<RecRecipient> recRecipient
			) {
		super();
		this.usrCode = usrCode;
		this.usrPassword = usrPassword;
		this.usrStatus = usrStatus;
		this.usrPwdUpdDate = usrPwdUpdDate;
		this.usrLoginTries = usrLoginTries;
		this.usrResetPwd = usrResetPwd;
		this.prdProduct = prdProduct;
		this.usrLastLoginDate = usrLastLoginDate;
		this.usrCreatedBy = usrCreatedBy;
		this.usrCreatedDate = usrCreatedDate;
		this.usrModifiedBy = usrModifiedBy;
		this.usrModifiedDate = usrModifiedDate;
	}

	@Id

	@Column(name = "usr_code", unique = true, nullable = false, length = 25)
	public String getUsrCode() {
		return this.usrCode;
	}

	public void setUsrCode(String usrCode) {
		this.usrCode = usrCode;
	}


	@Column(name = "usr_password", nullable = false, length = 64)
	public String getUsrPassword() {
		return this.usrPassword;
	}

	public void setUsrPassword(String usrPassword) {
		this.usrPassword = usrPassword;
	}

	@Column(name = "usr_status", nullable = false, length = 1)
	public String getUsrStatus() {
		return this.usrStatus;
	}

	public void setUsrStatus(String usrStatus) {
		this.usrStatus = usrStatus;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "usr_pwd_upd_date", length = 13)
	public Date getUsrPwdUpdDate() {
		return this.usrPwdUpdDate;
	}

	public void setUsrPwdUpdDate(Date usrPwdUpdDate) {
		this.usrPwdUpdDate = usrPwdUpdDate;
	}

	@Column(name = "usr_login_tries", precision = 131089, scale = 0)
	public BigDecimal getUsrLoginTries() {
		return this.usrLoginTries;
	}

	public void setUsrLoginTries(BigDecimal usrLoginTries) {
		this.usrLoginTries = usrLoginTries;
	}

	@Column(name = "usr_reset_pwd")
	public Boolean getUsrResetPwd() {
		return this.usrResetPwd;
	}

	public void setUsrResetPwd(Boolean usrResetPwd) {
		this.usrResetPwd = usrResetPwd;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "usr_last_login_date", length = 13)
	public Date getUsrLastLoginDate() {
		return this.usrLastLoginDate;
	}

	public void setUsrLastLoginDate(Date usrLastLoginDate) {
		this.usrLastLoginDate = usrLastLoginDate;
	}

	@Column(name = "usr_created_by", nullable = false, length = 25)
	public String getUsrCreatedBy() {
		return this.usrCreatedBy;
	}

	public void setUsrCreatedBy(String usrCreatedBy) {
		this.usrCreatedBy = usrCreatedBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "usr_created_date", nullable = false, length = 29)
	public Date getUsrCreatedDate() {
		return this.usrCreatedDate;
	}

	public void setUsrCreatedDate(Date usrCreatedDate) {
		this.usrCreatedDate = usrCreatedDate;
	}

	@Column(name = "usr_modified_by", length = 25)
	public String getUsrModifiedBy() {
		return this.usrModifiedBy;
	}

	public void setUsrModifiedBy(String usrModifiedBy) {
		this.usrModifiedBy = usrModifiedBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "usr_modified_date", length = 29)
	public Date getUsrModifiedDate() {
		return this.usrModifiedDate;
	}

	public void setUsrModifiedDate(Date usrModifiedDate) {
		this.usrModifiedDate = usrModifiedDate;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "usrUser")
	public Set<PrdProduct> getPrdProduct() {
		return this.prdProduct;
	}

	public void setPrdProduct(Set<PrdProduct> prdProduct) {
		this.prdProduct = prdProduct;
	}
	
	/*@OneToMany(fetch = FetchType.LAZY, mappedBy = "usrUser")
	public Set<RecRecipient> getRecRecipient() {
		return this.recRecipient;
	}

	public void setRecRecipient(Set<RecRecipient> recRecipient) {
		this.recRecipient = recRecipient;
	}
	*/
}
