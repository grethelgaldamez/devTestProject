package com.loyalty.pojo.operations;

public class Transfers {
	
	private String origen;
	private String destino;
	private Double amount;

	public Transfers() {
		super();
	}
	
	public Transfers(String origen, String destino, Double amount) {
		super();
		this.origen = origen;
		this.destino = destino;
		this.amount = amount;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	
}
