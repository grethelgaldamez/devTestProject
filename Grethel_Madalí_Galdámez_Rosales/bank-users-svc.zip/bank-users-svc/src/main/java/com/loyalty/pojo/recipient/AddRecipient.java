package com.loyalty.pojo.recipient;

public class AddRecipient {

	private String usrCode;
	private String accNumber;
	private String name;
	private String type;
	private String email;
	
	public AddRecipient() {
		super();
	}

	public AddRecipient(String usrCode, String accNumber, String name, String type, String email) {
		super();
		this.usrCode = usrCode;
		this.accNumber = accNumber;
		this.name = name;
		this.type = type;
		this.email = email;
	}



	public String getUsrCode() {
		return usrCode;
	}

	public void setUsrCode(String usrCode) {
		this.usrCode = usrCode;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
