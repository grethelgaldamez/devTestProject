package com.loyalty.pojo.svc.options;

import java.util.List;

public class ProdItem {

	private List<ProdMin> loan;
	private List<ProdMin> creditCard;
	private List<ProdMin> personal;
	
	public ProdItem() {
		super();
	}

	public ProdItem(List<ProdMin> loan, List<ProdMin> creditCard, List<ProdMin> personal) {
		super();
		this.loan = loan;
		this.creditCard = creditCard;
		this.personal = personal;
	}

	public List<ProdMin> getLoan() {
		return loan;
	}

	public void setLoan(List<ProdMin> loan) {
		this.loan = loan;
	}

	public List<ProdMin> getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(List<ProdMin> creditCard) {
		this.creditCard = creditCard;
	}

	public List<ProdMin> getPersonal() {
		return personal;
	}

	public void setPersonal(List<ProdMin> personal) {
		this.personal = personal;
	}

}
