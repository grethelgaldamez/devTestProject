package com.loyalty.pojo.svc.options;

public class ProdMenu {

	private ProdItem accounts;
	
	public ProdMenu() {
		super();
	}

	public ProdItem getAccounts() {
		return accounts;
	}

	public void setAccounts(ProdItem accounts) {
		this.accounts = accounts;
	}

}
