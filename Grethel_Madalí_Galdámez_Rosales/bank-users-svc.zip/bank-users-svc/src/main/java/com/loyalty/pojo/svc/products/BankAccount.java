package com.loyalty.pojo.svc.products;

import java.util.Date;
import java.util.List;

public class BankAccount {

	private String id;
	private Date startDate;
	private Date endDate;
	private List<Transaction> transactions;
	
	public BankAccount() {
		super();
	}

	public BankAccount(String id, Date startDate, Date endDate, List<Transaction> transactions) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.transactions = transactions;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	
}
