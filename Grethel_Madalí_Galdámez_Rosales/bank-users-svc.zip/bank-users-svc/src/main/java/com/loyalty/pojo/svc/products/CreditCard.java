package com.loyalty.pojo.svc.products;

import java.util.Date;
import java.util.List;

public class CreditCard {

	private String id;
	private Date startDate;
	private Date endDay;
	private Double limit;
	private Double available;
	private Double interestRate;
	private Double interestAmount;
	private Integer MonthlyCut;
	private List<Transaction> transactions;
	
	public CreditCard() {
		super();
	}
	
	public CreditCard(String id, Date startDate, Date endDay, Double limit, Double available, Double interestRate,
			Double interestAmount, Integer monthlyCut, List<Transaction> transactions) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDay = endDay;
		this.limit = limit;
		this.available = available;
		this.interestRate = interestRate;
		this.interestAmount = interestAmount;
		MonthlyCut = monthlyCut;
		this.transactions = transactions;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDay() {
		return endDay;
	}

	public void setEndDay(Date endDay) {
		this.endDay = endDay;
	}

	public Double getLimit() {
		return limit;
	}

	public void setLimit(Double limit) {
		this.limit = limit;
	}

	public Double getAvailable() {
		return available;
	}

	public void setAvailable(Double available) {
		this.available = available;
	}

	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public Double getInterestAmount() {
		return interestAmount;
	}

	public void setInterestAmount(Double interestAmount) {
		this.interestAmount = interestAmount;
	}

	public Integer getMonthlyCut() {
		return MonthlyCut;
	}

	public void setMonthlyCut(Integer monthlyCut) {
		MonthlyCut = monthlyCut;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	
}
