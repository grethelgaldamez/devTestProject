package com.loyalty.pojo.svc.products;

import java.util.Date;
import java.util.List;

public class Loan {
	
	private String id;
	private Date startdate;
	private Date endDate;
	private Double total;
	private Double debt;
	private Double interestRate;
	private Double interestAmount;
	private List<Transaction> transactions;

	public Loan() {
		super();
	}
	
	public Loan(String id, Date startdate, Date endDate, Double total, Double debt, Double interestRate,
			Double interestAmount, List<Transaction> transactions) {
		super();
		this.id = id;
		this.startdate = startdate;
		this.endDate = endDate;
		this.total = total;
		this.debt = debt;
		this.interestRate = interestRate;
		this.interestAmount = interestAmount;
		this.transactions = transactions;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	public Double getDebt() {
		return debt;
	}

	public void setDebt(Double debt) {
		this.debt = debt;
	}

	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public Double getInterestAmount() {
		return interestAmount;
	}

	public void setInterestAmount(Double interestAmount) {
		this.interestAmount = interestAmount;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

}
