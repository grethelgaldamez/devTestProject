package com.loyalty.process;

import java.util.Date;

import com.loyalty.pojo.envelope.Envelope;
import com.loyalty.pojo.envelope.Status;
import com.loyalty.pojo.operations.Transfers;
import com.loyalty.pojo.recipient.AddRecipient;
import com.loyalty.pojo.svc.UserSvc;
import com.loyalty.pojo.svc.options.ProdMenu;
import com.loyalty.pojo.svc.products.BankAccount;
import com.loyalty.pojo.svc.products.CreditCard;
import com.loyalty.pojo.svc.products.Loan;

public interface IUserProcess {
	public Envelope<Status, UserSvc> validate(String userCode, String pwd);
	public Envelope<Status, ProdMenu> allProducts(String userCode);
	Envelope<Status, CreditCard> allTransactionsCard(String userCode, Date startDate, Date endDate, String user);
	Envelope<Status, Loan> allTransactionsLoan(String userCode, Date startDate, Date endDate, String user);
	Envelope<Status, BankAccount> allTransactionsAccount(String userCode, Date startDate, Date endDate, String user);
	Envelope<Status, Boolean> addRecipient(AddRecipient rec);
	Envelope<Status, Boolean> transferAccount(Transfers trans);
	Envelope<Status, Boolean> cardPayment(Transfers trans);
	Envelope<Status, Boolean> loanPayment(Transfers trans);
	
}
