package com.loyalty.process;

import java.net.Inet4Address;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.loyalty.data.IUserData;
import com.loyalty.entity.PrdProduct;
import com.loyalty.pojo.envelope.Envelope;
import com.loyalty.pojo.envelope.Message;
import com.loyalty.pojo.envelope.Status;
import com.loyalty.pojo.operations.Transfers;
import com.loyalty.pojo.recipient.AddRecipient;
import com.loyalty.pojo.svc.Detail;
import com.loyalty.pojo.svc.User;
import com.loyalty.pojo.svc.UserSvc;
import com.loyalty.pojo.svc.options.ProdMenu;
import com.loyalty.pojo.svc.products.BankAccount;
import com.loyalty.pojo.svc.products.CreditCard;
import com.loyalty.pojo.svc.products.Loan;
import com.loyalty.pojo.svc.products.Transaction;
import com.loyalty.process.token.ITokenProcess;
import com.loyalty.utils.ResponseCode;
import com.loyalty.utils.ResponseMsg;
import com.loyalty.utils.SHAHashing;

@Service("UserProcess")
public class UserProcess implements IUserProcess{
	private IUserData<User> data;
	private ITokenProcess token;
	private Environment env;
	private Logger log;
	private SHAHashing sha2;

    @Value("${config.settings.minlength-pass}")
	String minlength = "8";
    
    
	public UserProcess(
			@Qualifier("BeanDataUser") IUserData<User> data,
			ITokenProcess token,
			Environment env,
			SHAHashing sha2
			){
		this.data = data;
		this.env = env;
		this.token = token;
		this.sha2 = sha2;
		
	}
	
	@Override
	public Envelope<Status, UserSvc> validate(String userCod, String pwd) {
		Status s = new Status();
		UserSvc object = new UserSvc();
		Detail details = new Detail();
		
		try{
			String userCode = userCod.toUpperCase();
			
			if(!data.exists(userCode)){
				
				//HTTP 400
				s.setCode(ResponseCode.USR_NOT_EXISTS);
				s.setResult(ResponseMsg.USR_NOT_EXISTS);
			}
			else{
				String crypt = "";
				try {			
					crypt = sha2.encrypt(userCode+pwd);
				} catch (NoSuchAlgorithmException e) {
					log.error("Error in encrypt password:"+e.getMessage(), e);
				}
				
				
				//validando si el password es correcto
				User user = data.retrieveUserByPwd(userCode, crypt);
				
				if(user != null) { //password correcto			
					
					//creación de token
					String tkn = token.createJWT(userCode, Inet4Address.getLocalHost().getHostAddress());
					
					if(tkn.equals("") || tkn == null) {
						s.setCode(ResponseCode.NO_TOKEN);
						s.setResult(ResponseMsg.NO_TOKEN);
						return new Message<>(s, object);
					}
					
					object = new UserSvc();
					object.setUsername(userCode);
					object.setPassword(user.getPassword());
					details.setResetPwd(user.isResetPwd());
					details.setToken(tkn);
					object.setDetails(details);
					
					//inactivo
					if('I' == user.getUserStatus()){
						details.setDisabled(true);
					}else{
						//bloqueo
						if(user.getTries() >= Integer.parseInt(env.getProperty("config.settings.max-try-pwd"))){
							details.setLocked(true);
							user.setUserStatus('I');
							
							//HTTP 400
							s.setCode(ResponseCode.BLOCKED);
							s.setResult(ResponseMsg.BLOCKED);
							return new Message<>(s, object);
						}else {
							user.setTries(0);
							user.setCreatedDate(new Date().toString());
							user.setCreatedOrModifyBy("GGALDAMEZ");
							user.setLastLoginDate(new Date());
							data.update(user);
						}
					}
				
					//HTTP 200
					s.setCode(ResponseCode.SUCCESS);
					s.setResult(ResponseMsg.SUCCESS);
					return new Message<>(s, object);
				} else {
					//CONTRASEÑA INCORRECTA					
					details.setWrongPwd(true);
					object.setDetails(details);
					data.addTries(userCode);
					User us = data.retrieveUser(userCode);
					
					//VALIDANDO SI EL USUARIO ESTÁ BLOQUEADO
					if(us.getUserStatus() == 'I') {
						//HTTP 400
						s.setCode(ResponseCode.BLOCKED);
						s.setResult(ResponseMsg.BLOCKED);
						return new Message<>(s, object);
					}else {
						//HTTP 401
						s.setCode(ResponseCode.WRONG_PASS);
						s.setResult(ResponseMsg.WRONG_PASS);
						return new Message<>(s, object);
					}
					
				}
			}
		} catch (Exception e) {
			//HTTP 401
			s.setCode(ResponseCode.NO_TOKEN);
			s.setResult(ResponseMsg.NO_TOKEN);
		}
		return new Message<>(s, object);
		
	}

	@Override
	public Envelope<Status, ProdMenu> allProducts(String userCode) {
		ProdMenu ans = new ProdMenu();
		Status s = new Status();
		
		try {
			ans = data.allProducts(userCode.toUpperCase());
			if(ans != null) {
				s.setCode(ResponseCode.SUCCESS);
				s.setResult(ResponseMsg.SUCCESS);
			}else {
				s.setCode(ResponseCode.ERROR);
				s.setResult(ResponseMsg.ERROR);
			}
		}catch(Exception e) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
		}
		return new Message<>(s, ans);
	}

	@Override
	public Envelope<Status, CreditCard> allTransactionsCard(String prod, Date startDate, Date endDate, String user) {
		CreditCard ans = new CreditCard();
		Status s = new Status();
		
		if(startDate.compareTo(endDate) > 0) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
			return new Message<>(s, null);
		}

		long diff = startDate.getTime() - endDate.getTime();
		if((diff / (-1000*60*60*24)) > 90) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
			return new Message<>(s, null);
		}

		try {
			PrdProduct prdInf = data.getProdInfo(prod); 
			if(!prdInf.getId().getPrdCodusr().equals(user)) {
				s.setCode(ResponseCode.WRONG_ID);
				s.setResult(ResponseMsg.WRONG_ID);
				return new Message<>(s, null);
			}
			List<Transaction> lista = data.allTransactions(prod);
			
			if(lista == null) {
				s.setCode(ResponseCode.ERROR);
				s.setResult(ResponseMsg.ERROR);
				return new Message<>(s, null);
			}else {
				List<Transaction> lista2 = new ArrayList<>();
				lista2.addAll(lista.stream().filter(x->((x.getDate().compareTo(endDate) <= -1) && (x.getDate().compareTo(startDate) >= 1))).collect(Collectors.toList()));
				
				ans.setId(prod);
				ans.setStartDate(startDate);
				ans.setEndDay(endDate);
				ans.setLimit(Double.parseDouble(prdInf.getPrdTotalLimit().toString()));
				ans.setAvailable(Double.parseDouble(prdInf.getPrdAvailableDebt().toString()));
				ans.setInterestRate(Double.parseDouble(prdInf.getPrdInterestRate().toString()));
				ans.setInterestAmount(Double.parseDouble(prdInf.getPrdInterestAmount().toString()));
				ans.setMonthlyCut(Integer.parseInt(prdInf.getPrdMonthlyCut().toString()));
				ans.setTransactions(lista2);
				s.setCode(ResponseCode.SUCCESS);
				s.setResult(ResponseMsg.SUCCESS);
			}
		}catch(Exception e) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
		}
		return new Message<>(s, ans);
	}

	@Override
	public Envelope<Status, Loan> allTransactionsLoan(String prod, Date startDate, Date endDate, String user) {
		Loan ans = new Loan();
		Status s = new Status();
		
		if(startDate.compareTo(endDate) > 0) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
			return new Message<>(s, null);
		}

		long diff = startDate.getTime() - endDate.getTime();
		if((diff / (-1000*60*60*24)) > 90) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
			return new Message<>(s, null);
		}
		
		try {
			PrdProduct prdInf = data.getProdInfo(prod); 
			if(!prdInf.getId().getPrdCodusr().equals(user)) {
				s.setCode(ResponseCode.WRONG_ID);
				s.setResult(ResponseMsg.WRONG_ID);
				return new Message<>(s, null);
			}
			List<Transaction> lista = data.allTransactions(prod);
			
			if(lista == null) {
				s.setCode(ResponseCode.ERROR);
				s.setResult(ResponseMsg.ERROR);
				return new Message<>(s, null);
			}else {
				List<Transaction> lista2 = new ArrayList<>();
				lista2.addAll(lista.stream().filter(x->((x.getDate().compareTo(endDate) <= -1) && (x.getDate().compareTo(startDate) >= 1))).collect(Collectors.toList()));
				
				ans.setId(prod);
				ans.setStartdate(startDate);
				ans.setEndDate(endDate);
				ans.setTotal(Double.parseDouble(prdInf.getPrdTotalLimit().toString()));
				ans.setDebt(Double.parseDouble(prdInf.getPrdAvailableDebt().toString()));
				ans.setInterestRate(Double.parseDouble(prdInf.getPrdInterestRate().toString()));
				ans.setInterestAmount(Double.parseDouble(prdInf.getPrdInterestAmount().toString()));
				ans.setTransactions(lista2);
				s.setCode(ResponseCode.SUCCESS);
				s.setResult(ResponseMsg.SUCCESS);
			}
		}catch(Exception e) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
		}
		return new Message<>(s, ans);
	}

	@Override
	public Envelope<Status, BankAccount> allTransactionsAccount(String prod, Date startDate, Date endDate, String user) {
		BankAccount ans = new BankAccount();
		Status s = new Status();
		
		if(startDate.compareTo(endDate) > 0) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
			return new Message<>(s, null);
		}

		long diff = startDate.getTime() - endDate.getTime();
		if((diff / (-1000*60*60*24)) > 90) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
			return new Message<>(s, null);
		}
		
		try {
			PrdProduct prdInf = data.getProdInfo(prod); 
			if(!prdInf.getId().getPrdCodusr().equals(user)) {
				s.setCode(ResponseCode.WRONG_ID);
				s.setResult(ResponseMsg.WRONG_ID);
				return new Message<>(s, null);
			}
			List<Transaction> lista = data.allTransactions(prod);
			
			if(lista == null || lista.isEmpty()) {
				s.setCode(ResponseCode.ERROR);
				s.setResult(ResponseMsg.ERROR);
				return new Message<>(s, null);
			}else {
				List<Transaction> lista2 = new ArrayList<>();
				lista2.addAll(lista.stream().filter(x->((x.getDate().compareTo(endDate) <= -1) && (x.getDate().compareTo(startDate) >= 1))).collect(Collectors.toList()));
				
				ans.setId(prod);
				ans.setStartDate(startDate);
				ans.setEndDate(endDate);
				ans.setTransactions(lista2);
				s.setCode(ResponseCode.SUCCESS);
				s.setResult(ResponseMsg.SUCCESS);
			}
		}catch(Exception e) {
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
		}
		return new Message<>(s, ans);
	}

	@Override
	public Envelope<Status, Boolean> addRecipient(AddRecipient rec) {
		Status s = new Status();
		rec.setUsrCode(rec.getUsrCode().toUpperCase());
		int ans = data.addRecipient(rec);
		boolean b = false;
		
		switch(ans) {
		case 201:
			s.setCode(ResponseCode.SAVED);
			s.setResult(ResponseMsg.SAVED);
			b = true;
			break;
		case 409:
			s.setCode(ResponseCode.IN_BASE);
			s.setResult(ResponseMsg.IN_BASE);
			break;
		case 400: 
			s.setCode(ResponseCode.ERROR);
			s.setResult(ResponseMsg.ERROR);
			break;
		case 404:
			s.setCode(ResponseCode.NO_EXIST);
			s.setResult(ResponseMsg.NO_EXIST);
			break;
		default:
			break;
		}
		return new Message<>(s, b);
	}

	@Override
	public Envelope<Status, Boolean> transferAccount(Transfers trans) {
		Status s = new Status();
		int ans = data.transfer(trans);
		boolean b = false;
		
		switch(ans) {
		case 200:
			s.setCode(ResponseCode.SUCCESS);
			s.setResult(ResponseMsg.SUCCESS);
			b = true;
			break;
		case 500:
			s.setCode(ResponseCode.SAVE_ERROR);
			s.setResult(ResponseMsg.SAVE_ERROR);
			break;
		case 409: 
			s.setCode(ResponseCode.NO_MONEY);
			s.setResult(ResponseMsg.NO_MONEY);
			break;
		case 404:
			s.setCode(ResponseCode.ERROR_PRD);
			s.setResult(ResponseMsg.ERROR_PRD);
			break;
		default:
			break;
		}
		return new Message<>(s, b);
	}

	@Override
	public Envelope<Status, Boolean> cardPayment(Transfers trans) {
		Status s = new Status();
		int ans = data.transferCard(trans);
		boolean b = false;
		
		switch(ans) {
		case 200:
			s.setCode(ResponseCode.SUCCESS);
			s.setResult(ResponseMsg.SUCCESS);
			b = true;
			break;
		case 500:
			s.setCode(ResponseCode.SAVE_ERROR);
			s.setResult(ResponseMsg.SAVE_ERROR);
			break;
		case 409: 
			s.setCode(ResponseCode.NO_MONEY);
			s.setResult(ResponseMsg.NO_MONEY);
			break;
		case 400:
			s.setCode(ResponseCode.ERROR_PRD);
			s.setResult(ResponseMsg.ERROR_PRD);
			break;
		default:
			break;
		}
		return new Message<>(s, b);
	}

	@Override
	public Envelope<Status, Boolean> loanPayment(Transfers trans) {
		Status s = new Status();
		int ans = data.transferCard(trans);
		boolean b = false;
		
		switch(ans) {
		case 200:
			s.setCode(ResponseCode.SUCCESS);
			s.setResult(ResponseMsg.SUCCESS);
			b = true;
			break;
		case 500:
			s.setCode(ResponseCode.SAVE_ERROR);
			s.setResult(ResponseMsg.SAVE_ERROR);
			break;
		case 409: 
			s.setCode(ResponseCode.NO_MONEY);
			s.setResult(ResponseMsg.NO_MONEY);
			break;
		case 400:
			s.setCode(ResponseCode.ERROR_PRD);
			s.setResult(ResponseMsg.ERROR_PRD);
			break;
		default:
			break;
		}
		return new Message<>(s, b);
	}

}
