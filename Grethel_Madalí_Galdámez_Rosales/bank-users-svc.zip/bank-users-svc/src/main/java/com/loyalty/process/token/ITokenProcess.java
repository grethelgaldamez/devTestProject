package com.loyalty.process.token;

import io.jsonwebtoken.Claims;

public interface ITokenProcess {

	public String createJWT(String id, String ip);
	public Claims decodeJWT(String jwt);
}
