package com.loyalty.process.token;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.security.Key;
import io.jsonwebtoken.*;
import java.util.Date;
import io.jsonwebtoken.Jwts;

@Service("TokenProcess")
public class Token implements ITokenProcess{
	private Environment env;
	
	public Token(Environment env){
		this.env = env;
	}
	
	public String createJWT(String id, String ip) {
		  
	    SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

	    long nowMillis = System.currentTimeMillis();
	    Date now = new Date(nowMillis);
	    
	    byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(env.getProperty("config.token.key"));
	    Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

	    JwtBuilder builder = Jwts.builder().setId(id)
	            .setIssuedAt(now)
	            .setSubject(env.getProperty("config.token.name"))
	            //ip de sesión
	            .setIssuer(ip)
	            //.setClaims(claims)
	            .signWith(signatureAlgorithm, signingKey);
	  
	    //expiración de 30 minutos
	    long expMillis = nowMillis + Long.parseLong(env.getProperty("config.token.time"));
	    Date exp = new Date(expMillis);
	    builder.setExpiration(exp);
	 
	  
	    return builder.compact();
	}

	
	public Claims decodeJWT(String jwt) {		
	    return Jwts.parser()
	            .setSigningKey(DatatypeConverter.parseBase64Binary(env.getProperty("config.token.key")))
	            .parseClaimsJws(jwt).getBody();
	}
	
}
