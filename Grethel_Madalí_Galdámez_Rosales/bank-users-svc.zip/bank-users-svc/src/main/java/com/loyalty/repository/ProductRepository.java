package com.loyalty.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.loyalty.entity.PrdProduct;

public interface ProductRepository extends CrudRepository<PrdProduct, String>{
	
	public List<PrdProduct> findByIdPrdCodusr(String codUsr);
	public PrdProduct findByIdPrdCode(String prdCode);
}

