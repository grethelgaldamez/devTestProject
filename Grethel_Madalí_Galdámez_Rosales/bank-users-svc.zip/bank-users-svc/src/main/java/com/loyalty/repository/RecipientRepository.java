package com.loyalty.repository;

import org.springframework.data.repository.CrudRepository;

import com.loyalty.entity.RecRecipient;

public interface RecipientRepository extends CrudRepository<RecRecipient, String>{
	public RecRecipient findByIdRecUsrcodeAndIdRecCode(String recUsrcode, String recCode);
}

