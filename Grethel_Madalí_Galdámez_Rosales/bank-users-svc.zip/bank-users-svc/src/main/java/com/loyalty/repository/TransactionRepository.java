package com.loyalty.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.loyalty.entity.PrdProduct;
import com.loyalty.entity.TraTransaction;

public interface TransactionRepository extends CrudRepository<TraTransaction, String>{
	
	public List<TraTransaction> findByIdTraProductId(String traProductId);
}

