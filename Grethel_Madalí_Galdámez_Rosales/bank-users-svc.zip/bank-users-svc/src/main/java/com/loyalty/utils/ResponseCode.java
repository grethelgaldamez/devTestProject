package com.loyalty.utils;

public class ResponseCode {
	public static final String SUCCESS="200";
	public static final String BLOCKED="400";
	public static final String NO_TOKEN="401";
	public static final String WRONG_PASS="401";
	public static final String USR_NOT_EXISTS="400";
	public static final String ERROR="400";
	public static final String WRONG_ID="401";
	public static final String IN_BASE="409";
	public static final String NO_EXIST="404";
	public static final String SAVED="201";
	public static final String SAVE_ERROR="500";
	public static final String NO_MONEY="409";
	public static final String ERROR_PRD="404";
	
}
