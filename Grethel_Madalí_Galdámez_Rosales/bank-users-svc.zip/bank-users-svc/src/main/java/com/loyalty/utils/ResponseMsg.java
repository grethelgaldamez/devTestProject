package com.loyalty.utils;

public class ResponseMsg {
	public static final String SUCCESS="Operación exitosa";
	public static final String BLOCKED="Usuario bloqueado por password incorrecto";
	public static final String NO_TOKEN="Token no creado";
	public static final String WRONG_PASS="Contraseña incorrecta";
	public static final String USR_NOT_EXISTS="Usuario no existe";
	public static final String ERROR="Error retrieving data";
	public static final String WRONG_ID="Account number mismatch account user";	
	public static final String IN_BASE="Recipient already saved";
	public static final String NO_EXIST="User does nto exists";
	public static final String SAVED="Saved Recipient";
	public static final String SAVE_ERROR="Error saving";
	public static final String NO_MONEY="Not enough money";
	public static final String ERROR_PRD="Error in product";
	
}
